'use client';

// ОСКОЛОК — компоненты интерфейса (HTML/CSS поверх игрового поля)

import { useState } from 'react';
import { TOOL_INFO, WORK_CATS, TRAITS, RECIPES, RES_INFO, ITEM_STATS, WEAPON_STATS, type Tool } from '@/game/data/defs';
import type { Game, GameSettings } from '@/game/core/game';
import type { LogEntry } from '@/game/core/events';

type UiState = ReturnType<Game['uiSnapshot']>;
type PawnDetail = NonNullable<ReturnType<Game['pawnDetail']>>;

function fmtTime(day: number, hhmm: string): string {
  return `День ${day}, ${hhmm}`;
}

function Bar({ v, color, label }: { v: number; color: string; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="w-[52px] shrink-0 text-[10px] text-[#a8ad9a]">{label}</span>
      <div className="h-2 flex-1 overflow-hidden rounded-sm bg-black/40">
        <div className="h-full rounded-sm transition-all" style={{ width: `${Math.max(0, Math.min(100, v))}%`, background: color }} />
      </div>
      <span className="w-7 shrink-0 text-right text-[10px] text-[#c8cbb8]">{Math.round(v)}</span>
    </div>
  );
}

// ================= Верхняя панель =================
const SPEED_LIST: { v: 0 | 1 | 2 | 4 | 8 | 16; icon: string; name: string }[] = [
  { v: 1, icon: '▶', name: '×1' },
  { v: 2, icon: '▶▶', name: '×2' },
  { v: 4, icon: '▶▶▶', name: '×4' },
  { v: 8, icon: '▶▶▶▶', name: '×8' },
  { v: 16, icon: '≫', name: '×16' },
  { v: 0, icon: '⏸', name: 'Пауза' },
];

export function TopBar({
  ui,
  onSpeed,
  onJournal,
  onPauseMenu,
  onAdmin,
}: {
  ui: UiState;
  onSpeed: (s: 0 | 1 | 2 | 4 | 8 | 16) => void;
  onJournal: () => void;
  onPauseMenu: () => void;
  onAdmin: () => void;
}) {
  const [speedOpen, setSpeedOpen] = useState(false);
  return (
    <div className="relative z-20 flex h-12 shrink-0 items-center gap-1 border-b border-black/50 bg-[#1c2218] px-2 text-[13px]">
      <div className="flex items-center gap-2.5">
        <span title="Дерево">🪵 {ui.wood}</span>
        <span title="Камень">🪨 {ui.stone}</span>
        <span title="Еда" className={ui.food < 10 ? 'animate-pulse text-red-400' : ''}>🍖 {ui.food}</span>
        {ui.meals > 0 && <span title="Похлёбка">🍲 {ui.meals}</span>}
        {ui.iron > 0 && <span title="Железо">🔩 {ui.iron}</span>}
        {ui.silver > 0 && <span title="Серебро — валюта караванов">🪙 {ui.silver}</span>}
      </div>
      <div className="mx-auto flex items-center gap-2 whitespace-nowrap">
        <span className="text-[#d9b13f]">День {ui.day}</span>
        <span title={ui.season}>{ui.seasonIcon}</span>
        <span className={ui.night ? 'text-[#9aa7ff]' : ''}>{ui.hhmm}</span>
        {ui.rain && <span title="Дождь">🌧️</span>}
        {ui.blizzard && <span className="animate-pulse" title="Буран">🌨️</span>}
        {ui.alarm && <span className="animate-pulse text-red-400" title="Волки у стен!">⚠</span>}
      </div>
      <div className="flex items-center gap-0.5">
        {speedOpen && <div className="fixed inset-0 z-20" onClick={() => setSpeedOpen(false)} />}
        {/* Скорость: выпадающий список */}
        <button
          onClick={() => setSpeedOpen((o) => !o)}
          className={`h-8 min-w-[50px] rounded px-1.5 text-[11px] font-semibold ${
            ui.speed === 0 ? 'bg-[#d9b13f] text-black' : 'bg-black/30 text-[#c8cbb8]'
          }`}
          aria-label="Скорость игры"
        >
          {ui.speed === 0 ? '⏸' : `▶ ×${ui.speed}`}
        </button>
        {speedOpen && (
          <div className="absolute right-2 top-[46px] z-30 w-32 overflow-hidden rounded-md border border-black/60 bg-[#242c1e] py-1 shadow-xl">
            {SPEED_LIST.map((s) => (
              <button
                key={s.v}
                onClick={() => {
                  onSpeed(s.v);
                  setSpeedOpen(false);
                }}
                className={`flex w-full items-center justify-between px-3 py-2 text-left text-[12px] ${
                  ui.speed === s.v ? 'bg-[#d9b13f] text-black' : 'text-[#c8cbb8]'
                }`}
              >
                <span>{s.icon}</span>
                <span className="font-semibold">{s.name}</span>
              </button>
            ))}
          </div>
        )}
        {/* Пауза + меню игры (сохранить/загрузить/настройки) */}
        <button
          onClick={() => {
            setSpeedOpen(false);
            onPauseMenu();
          }}
          className="relative h-8 w-9 rounded bg-[#3a4530] text-[13px] text-[#f0dfae]"
          aria-label="Пауза и меню игры"
        >
          ⏸<span className="absolute -bottom-0.5 -right-0.5 text-[8px] leading-none">☰</span>
        </button>
        <button onClick={onJournal} className="h-8 w-8 rounded bg-black/30 text-[14px]" aria-label="Журнал">
          📜
        </button>
        <button onClick={onAdmin} className="h-8 w-8 rounded bg-[#4a4430] text-[13px]" aria-label="Админ-панель">
          🛠️
        </button>
      </div>
    </div>
  );
}

// ================= Список пешек (слева) =================
export function PawnStrip({ ui, onSelect }: { ui: UiState; onSelect: (id: number) => void }) {
  return (
    <div className="absolute left-2 top-2 z-10 flex w-[150px] flex-col gap-1">
      {ui.pawns.map((p) => (
        <button
          key={p.id}
          onClick={() => onSelect(p.id)}
          className={`rounded-md border border-black/40 bg-[#1c2218]/90 px-2 py-1.5 text-left backdrop-blur-sm ${
            p.dead ? 'opacity-40' : ''
          }`}
        >
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: p.color }} />
            <span className="text-[12px] font-semibold">{p.name}</span>
            {p.weapon && (
              <span
                title={`${p.weapon === 'spear' ? 'Копьё' : p.weapon === 'bow' ? 'Лук' : 'Меч'}: ${WEAPON_STATS[p.weapon].min}–${WEAPON_STATS[p.weapon].max} урона`}
              >
                {p.weapon === 'spear' ? '🔱' : p.weapon === 'bow' ? '🏹' : '⚔️'}
              </span>
            )}
            {p.sick && <span title="Болеет">🤒</span>}
            {p.breaking && <span title="Срыв">💢</span>}
          </div>
          <div className="mt-0.5 truncate text-[10px] text-[#a8ad9a]">{p.action}</div>
          {!p.dead && (
            <div className="mt-1 space-y-0.5">
              <MiniBar v={p.hp} color="#8fd05a" />
              <MiniBar v={p.food} color="#d9913f" />
              <MiniBar v={p.rest} color="#6aa88a" />
            </div>
          )}
        </button>
      ))}
    </div>
  );
}

function MiniBar({ v, color }: { v: number; color: string }) {
  return (
    <div className="h-1 w-full overflow-hidden rounded-full bg-black/50">
      <div className="h-full" style={{ width: `${Math.max(0, Math.min(100, v))}%`, background: color }} />
    </div>
  );
}

// ================= Мини-карта (справа) =================
export function MinimapPanel({ miniRef, onCenter }: { miniRef: React.RefObject<HTMLCanvasElement | null>; onCenter: () => void }) {
  return (
    <div className="absolute right-2 top-2 z-10 flex flex-col items-end gap-1">
      <canvas
        ref={miniRef}
        className="h-[128px] w-[128px] rounded-md border border-black/50 bg-[#0a0d0b]"
        style={{ imageRendering: 'pixelated' }}
      />
      <button
        onClick={onCenter}
        className="rounded bg-[#1c2218]/90 px-2 py-1 text-[11px] text-[#d9b13f] backdrop-blur-sm"
      >
        ⌂ К базе
      </button>
    </div>
  );
}

// ================= Подсказка инструмента =================
export function ToolHint({ tool }: { tool: Tool }) {
  if (tool === 'inspect') return null;
  const info = TOOL_INFO[tool];
  return (
    <div className="pointer-events-none absolute left-1/2 top-2 z-10 -translate-x-1/2 rounded bg-black/70 px-3 py-1 text-[11px] text-[#e8e6df]">
      {info.icon} {info.name}: {info.hint}
    </div>
  );
}

// ================= Тосты событий =================
export function Toasts({ toasts }: { toasts: (LogEntry & { rt: number })[] }) {
  const colorOf = (k: LogEntry['kind']) =>
    k === 'bad' ? 'border-red-500/60 text-red-200' : k === 'good' ? 'border-[#8fd05a]/60 text-[#c8e8a8]' : k === 'story' ? 'border-[#d9b13f]/60 text-[#f0dfae]' : 'border-white/30 text-[#e8e6df]';
  return (
    <div className="pointer-events-none absolute left-1/2 top-12 z-30 flex w-[86%] max-w-sm -translate-x-1/2 flex-col items-center gap-1">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`w-full rounded-md border bg-[#141a12]/95 px-3 py-1.5 text-center text-[12px] shadow-lg backdrop-blur-sm ${colorOf(t.kind)}`}
        >
          {t.text}
        </div>
      ))}
    </div>
  );
}

// ================= Инспектор объекта =================
export function InfoPopup({
  info,
  onClose,
  onCancel,
  onBury,
  onZoneSettings,
  onProduction,
  onExpedition,
  onTrade,
  onHunt,
}: {
  info: NonNullable<UiState['info']>;
  onClose: () => void;
  onCancel: () => void;
  onBury: (itemId: number) => void;
  onZoneSettings?: (zoneId: number) => void;
  onProduction?: (bId: number) => void;
  onExpedition?: (mineId: number) => void;
  onTrade?: () => void;
  onHunt?: (animalId: number) => void;
}) {
  return (
    <div className="absolute bottom-2 left-1/2 z-20 w-[80%] max-w-xs -translate-x-1/2 rounded-md border border-black/50 bg-[#1c2218]/95 px-3 py-2 text-[12px] backdrop-blur-sm">
      <div className="flex items-center justify-between">
        <span className="font-semibold text-[#d9b13f]">{info.title}</span>
        <button onClick={onClose} className="text-[#8a8f7e]" aria-label="Закрыть">
          ✕
        </button>
      </div>
      <div className="mt-1 space-y-0.5 text-[#c8cbb8]">
        {info.lines.map((l, i) => (
          <div key={i}>{l}</div>
        ))}
      </div>
      {info.canTrade && onTrade && (
        <button
          onClick={() => onTrade()}
          className="mr-1.5 mt-1.5 rounded bg-[#7a5a9a] px-2 py-1 text-[11px] text-[#f0e6fa]"
        >
          ⚖️ Торговать
        </button>
      )}
      {info.huntId !== undefined && onHunt && (
        <button
          onClick={() => onHunt(info.huntId!)}
          className={`mr-1.5 mt-1.5 rounded px-2 py-1 text-[11px] ${info.hunting ? 'bg-red-900/60 text-red-200' : 'bg-[#3a4530] text-[#f0dfae]'}`}
        >
          {info.hunting ? '✕ Снять с охоты' : '🎯 Охота'}
        </button>
      )}
      {info.prodBId !== undefined && onProduction && (
        <button
          onClick={() => onProduction(info.prodBId!)}
          className="mr-1.5 mt-1.5 rounded bg-[#3a4530] px-2 py-1 text-[11px] text-[#f0dfae]"
        >
          {info.prodKind === 'fire' ? '🍲 Готовка' : '🔨 Производство'}
        </button>
      )}
      {info.mineBId !== undefined && onExpedition && (
        <button
          onClick={() => onExpedition(info.mineBId!)}
          className="mr-1.5 mt-1.5 rounded bg-[#4a4030] px-2 py-1 text-[11px] text-[#f0dfae]"
        >
          ⛏ Экспедиция в шахту
        </button>
      )}
      {info.zoneId !== undefined && onZoneSettings && (
        <button
          onClick={() => onZoneSettings(info.zoneId!)}
          className="mr-1.5 mt-1.5 rounded bg-[#3a4530] px-2 py-1 text-[11px] text-[#f0dfae]"
        >
          ⚙️ Настройки зоны
        </button>
      )}
      {info.buryItemId !== undefined && (
        <button
          onClick={() => onBury(info.buryItemId!)}
          className="mt-1.5 mr-1.5 rounded bg-[#4a4030] px-2 py-1 text-[11px] text-[#f0dfae]"
        >
          ⚰️ Похоронить
        </button>
      )}
      {info.canCancel && (
        <button onClick={onCancel} className="mt-1.5 rounded bg-red-900/60 px-2 py-1 text-[11px] text-red-200">
          Отменить проект / приказ
        </button>
      )}
    </div>
  );
}

// ================= Настройки зоны: склад/ферма (RimWorld-стиль) =================
type ZoneSettings = NonNullable<ReturnType<Game['zoneSettings']>>;

export function ZoneSettingsModal({
  zone,
  onClose,
  onRename,
  onFilter,
  onDelete,
}: {
  zone: ZoneSettings;
  onClose: () => void;
  onRename: (id: number, name: string) => void;
  onFilter: (id: number, res: number, allowed: boolean) => void;
  onDelete: (id: number) => void;
}) {
  const [name, setName] = useState(zone.name);
  const [confirmDel, setConfirmDel] = useState(false);
  const isStock = zone.kind === 'stockpile';
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/50 sm:items-center" onClick={onClose}>
      <div
        className="max-h-[85vh] w-full max-w-sm overflow-y-auto rounded-t-xl border border-black/50 bg-[#1c2218] p-4 sm:rounded-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <span className="text-base font-bold text-[#d9b13f]">
            {isStock ? '📦' : '🌱'} {isStock ? 'Склад' : 'Ферма'} · настройки
          </span>
          <button onClick={onClose} className="text-[#8a8f7e]" aria-label="Закрыть">
            ✕
          </button>
        </div>

        <div className="mt-3">
          <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-[#8a8f7e]">Название</div>
          <div className="flex gap-1.5">
            <input
              value={name}
              maxLength={24}
              onChange={(e) => setName(e.target.value)}
              className="min-w-0 flex-1 rounded-md bg-black/40 px-2.5 py-2 text-[13px] text-[#e8e6df] outline-none ring-1 ring-black/40 focus:ring-[#d9b13f]/50"
              aria-label="Название зоны"
            />
            <button
              onClick={() => onRename(zone.id, name)}
              className="rounded-md bg-[#d9b13f] px-3 py-2 text-[12px] font-semibold text-black"
            >
              ОК
            </button>
          </div>
        </div>

        <div className="mt-2 text-[11px] text-[#8a8f7e]">
          Клеток: {zone.tiles}
          {isStock ? (zone.stored.length === 0 ? ' · пусто' : '') : ` · созрело грядок: ${zone.ready}`}
        </div>
        {isStock && zone.stored.length > 0 && (
          <div className="mt-1.5 flex flex-wrap gap-1">
            {zone.stored.map((s) => (
              <span key={s.name} className="rounded bg-black/30 px-1.5 py-0.5 text-[11px] text-[#c8cbb8]">
                {s.icon} {s.name} ×{s.qty}
              </span>
            ))}
          </div>
        )}

        {isStock ? (
          <div className="mt-3">
            <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-[#8a8f7e]">Что хранить</div>
            <div className="space-y-1">
              {zone.filters.map((f) => (
                <button
                  key={f.res}
                  onClick={() => onFilter(zone.id, f.res, !f.allowed)}
                  className={`flex w-full items-center justify-between rounded-md px-2.5 py-2 text-[13px] ${
                    f.allowed ? 'bg-[#3a4a2c] text-[#c8e8a8]' : 'bg-black/30 text-[#8a8f7e]'
                  }`}
                >
                  <span>
                    {f.icon} {f.name}
                  </span>
                  <span className={`text-[11px] ${f.allowed ? 'text-[#8fd05a]' : ''}`}>{f.allowed ? 'принимает' : 'нет'}</span>
                </button>
              ))}
            </div>
            <div className="mt-1.5 text-[10px] leading-snug text-[#8a8f7e]">
              Снятая галочка: новое сюда не понесут, а уже лежащее перенесут на другой склад.
            </div>
          </div>
        ) : (
          <div className="mt-3 text-[12px] leading-relaxed text-[#c8cbb8]">
            Пешки сами вспашут, посадят и соберут урожай. Под дождём растения растут быстрее — следите за 🌧️.
          </div>
        )}

        <div className="mt-4 flex gap-2">
          {!confirmDel ? (
            <button
              onClick={() => setConfirmDel(true)}
              className="rounded-md bg-red-900/50 px-3 py-2 text-[12px] text-red-200"
            >
              🗑 Удалить зону
            </button>
          ) : (
            <button onClick={() => onDelete(zone.id)} className="rounded-md bg-red-800 px-3 py-2 text-[12px] text-white">
              Точно удалить?
            </button>
          )}
          <div className="flex-1" />
          <button onClick={onClose} className="rounded-md bg-[#d9b13f] px-4 py-2 text-[13px] font-semibold text-black">
            Готово
          </button>
        </div>
      </div>
    </div>
  );
}

// ================= Производство: заказы на верстаке / варка на костре =================
type ProdPanel = NonNullable<UiState['prod']>;

const BILL_COUNTS = [1, 5, 10];

export function ProductionModal({
  prod,
  onClose,
  onAddBill,
  onRemoveBill,
  onMealTarget,
}: {
  prod: ProdPanel;
  onClose: () => void;
  onAddBill: (recipe: number, count: number) => void;
  onRemoveBill: (idx: number) => void;
  onMealTarget: (n: number) => void;
}) {
  const [pick, setPick] = useState<number | null>(null); // выбранный рецепт для выбора количества
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/50 sm:items-center" onClick={onClose}>
      <div
        className="max-h-[85vh] w-full max-w-sm overflow-y-auto rounded-t-xl border border-black/50 bg-[#1c2218] p-4 sm:rounded-xl"
        onClick={(e) => e.stopPropagation()}
      >
        {prod.kind === 'bench' ? (
          <>
            <div className="flex items-center justify-between">
              <span className="text-base font-bold text-[#d9b13f]">🔨 Верстак · заказы</span>
              <button onClick={onClose} className="text-[#8a8f7e]" aria-label="Закрыть">
                ✕
              </button>
            </div>
            <div className="mt-1 text-[11px] text-[#8a8f7e]">Что и сколько производить. Колонист сам принесёт материалы и смастерит.</div>

            <div className="mt-3">
              <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-[#8a8f7e]">Текущие заказы</div>
              {prod.bills.length === 0 && <div className="rounded bg-black/25 px-2.5 py-2 text-[12px] text-[#8a8f7e]">Заказов нет. Выберите изделие ниже.</div>}
              <div className="space-y-1">
                {prod.bills.map((b) => (
                  <div key={b.idx} className="flex items-center gap-2 rounded-md bg-black/30 px-2.5 py-2">
                    <span className="text-[16px]">{b.icon}</span>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[12px] font-semibold text-[#f0dfae]">{b.name}</div>
                      <div className="text-[10px] text-[#8a8f7e]">{b.cost}</div>
                      {b.stat && <div className="text-[10px] text-[#c9a84a]">{b.stat}</div>}
                    </div>
                    <span className={`text-[12px] font-bold ${b.done >= b.count ? 'text-[#8fd05a]' : 'text-[#d9b13f]'}`}>
                      {b.done}/{b.count}
                    </span>
                    <button onClick={() => onRemoveBill(b.idx)} className="h-7 w-7 rounded bg-red-900/50 text-[12px] text-red-200" aria-label="Убрать заказ">
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-3">
              <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-[#8a8f7e]">Заказать изделие</div>
              <div className="space-y-1">
                {RECIPES.map((rec, idx) => {
                  const info = RES_INFO[rec.res];
                  const cost = `${rec.wood > 0 ? `🪵${rec.wood} ` : ''}${rec.iron > 0 ? `🔩${rec.iron} ` : ''}${rec.hide > 0 ? `🟤${rec.hide}` : ''}`.trim();
                  const stat = ITEM_STATS[rec.res];
                  return (
                    <div key={idx} className="rounded-md bg-black/30">
                      <button
                        onClick={() => setPick(pick === idx ? null : idx)}
                        className="flex w-full items-center gap-2 px-2.5 py-2 text-left"
                      >
                        <span className="text-[16px]">{info.icon}</span>
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-[12px] font-semibold text-[#c8cbb8]">{rec.name}</div>
                          <div className="text-[10px] text-[#8a8f7e]">{cost} · работа {rec.work} мин</div>
                          {stat && <div className="text-[10px] text-[#c9a84a]">{stat}</div>}
                        </div>
                        <span className="text-[#8a8f7e]">{pick === idx ? '▾' : '▸'}</span>
                      </button>
                      {pick === idx && (
                        <div className="flex gap-1.5 px-2.5 pb-2">
                          {BILL_COUNTS.map((n) => (
                            <button
                              key={n}
                              onClick={() => {
                                onAddBill(idx, n);
                                setPick(null);
                              }}
                              className="flex-1 rounded bg-[#d9b13f] py-1.5 text-[12px] font-semibold text-black"
                            >
                              ×{n}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <span className="text-base font-bold text-[#d9b13f]">🍲 Костёр · готовка</span>
              <button onClick={onClose} className="text-[#8a8f7e]" aria-label="Закрыть">
                ✕
              </button>
            </div>
            <div className="mt-1 text-[11px] text-[#8a8f7e]">
              Похлёбка сытнее сырой еды. Колонисты варят её из сырой еды (по {4} порции за раз), пока запас меньше цели.
            </div>
            <div className="mt-3 rounded-md bg-black/30 px-2.5 py-2 text-[13px] text-[#c8cbb8]">
              Сейчас похлёбки в колонии: <span className="font-bold text-[#d9b13f]">{prod.meals}</span> порций
            </div>
            <div className="mt-3">
              <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-[#8a8f7e]">Держать запас (порций)</div>
              <div className="grid grid-cols-3 gap-1.5">
                {[0, 4, 8, 12, 16, 24].map((n) => (
                  <button
                    key={n}
                    onClick={() => onMealTarget(n)}
                    className={`rounded-md py-2 text-[13px] font-semibold ${
                      prod.target === n ? 'bg-[#d9b13f] text-black' : 'bg-black/30 text-[#c8cbb8]'
                    }`}
                  >
                    {n === 0 ? 'Не варить' : n}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
        <button onClick={onClose} className="mt-4 w-full rounded-md bg-[#d9b13f] py-2 text-[13px] font-semibold text-black">
          Готово
        </button>
      </div>
    </div>
  );
}

// ================= Шахта: экспедиции в глубины =================
export function ExpeditionModal({
  expeditions,
  onClose,
  onSend,
}: {
  expeditions: UiState['expeditions'];
  onClose: () => void;
  onSend: () => void;
}) {
  const list = expeditions ?? [];
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/50 sm:items-center" onClick={onClose}>
      <div
        className="max-h-[85vh] w-full max-w-sm overflow-y-auto rounded-t-xl border border-black/50 bg-[#1c2218] p-4 sm:rounded-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <span className="text-base font-bold text-[#d9b13f]">🕳️ Шахта · глубины</span>
          <button onClick={onClose} className="text-[#8a8f7e]" aria-label="Закрыть">
            ✕
          </button>
        </div>
        <div className="mt-1 text-[11px] leading-snug text-[#8a8f7e]">
          Отдельная локация под землёй: шахтёр бьёт жилу ~9 часов и приносит железо и камень. В глубинах случаются
          сюрпризы: богатые жилы, обвалы, пещерные звери, заброшенные тайники и серебро.
        </div>

        <div className="mt-3 space-y-2">
          {list.map((e) => (
            <div key={`${e.mineId}`} className="rounded-md border border-black/40 bg-black/30 px-2.5 py-2">
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full" style={{ background: e.pawnColor }} />
                <span className="text-[12px] font-semibold">{e.pawnName}</span>
                <span className="text-[11px] text-[#8a8f7e]">{e.stage === 0 ? 'идёт к шахте' : 'в глубинах'}</span>
                <span className="ml-auto text-[12px] font-bold text-[#d9b13f]">{Math.round(e.progress * 100)}%</span>
              </div>
              <div className="mt-1.5 h-2 overflow-hidden rounded-sm bg-black/50">
                <div className="h-full rounded-sm bg-[#d9b13f] transition-all" style={{ width: `${e.progress * 100}%` }} />
              </div>
              <div
                className={`mt-1.5 text-[11px] ${
                  e.lastKind === 'bad' ? 'text-red-300' : e.lastKind === 'good' ? 'text-[#c8e8a8]' : e.lastKind === 'story' ? 'text-[#f0dfae]' : 'text-[#a8ad9a]'
                }`}
              >
                {e.lastText}
              </div>
            </div>
          ))}
          {list.length === 0 && (
            <div className="rounded bg-black/25 px-2.5 py-2 text-[12px] text-[#8a8f7e]">Экспедиций нет. Глубины ждут смельчаков.</div>
          )}
          <button onClick={onSend} className="w-full rounded-md bg-[#d9b13f] py-2.5 text-[13px] font-semibold text-black">
            ⛏ Отправить шахтёра
          </button>
        </div>
      </div>
    </div>
  );
}

// ================= Караван: торговля =================
type TradePanel = NonNullable<UiState['trade']>;

export function TradeModal({
  trade,
  onClose,
  onBuy,
  onSell,
}: {
  trade: TradePanel;
  onClose: () => void;
  onBuy: (idx: number) => void;
  onSell: (res: number, qty: number) => void;
}) {
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/50 sm:items-center" onClick={onClose}>
      <div
        className="max-h-[85vh] w-full max-w-sm overflow-y-auto rounded-t-xl border border-black/50 bg-[#1c2218] p-4 sm:rounded-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <span className="text-base font-bold text-[#d9b13f]">⚖️ Торговый караван</span>
          <button onClick={onClose} className="text-[#8a8f7e]" aria-label="Закрыть">
            ✕
          </button>
        </div>
        <div className="mt-1 text-[12px] text-[#c8cbb8]">
          Серебро в казне: <span className="font-bold text-[#d9b13f]">🪙 {trade.silver}</span>
        </div>

        <div className="mt-3">
          <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-[#8a8f7e]">Товары торговца</div>
          <div className="space-y-1">
            {trade.goods.length === 0 && <div className="rounded bg-black/25 px-2.5 py-2 text-[12px] text-[#8a8f7e]">Товары разобрали.</div>}
            {trade.goods.map((g) => (
              <div key={g.idx} className="flex items-center gap-2 rounded-md bg-black/30 px-2.5 py-2">
                <span className="text-[16px]">{g.icon}</span>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[12px] font-semibold text-[#c8cbb8]">{g.name}</div>
                  <div className="text-[10px] text-[#8a8f7e]">в наличии: {g.qty}</div>
                  {g.stat && <div className="text-[10px] text-[#c9a84a]">{g.stat}</div>}
                </div>
                <span className="text-[12px] font-bold text-[#d9b13f]">🪙 {g.price}</span>
                <button
                  onClick={() => onBuy(g.idx)}
                  className="rounded bg-[#7a5a9a] px-2.5 py-1.5 text-[11px] font-semibold text-[#f0e6fa]"
                >
                  Купить
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-3">
          <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-[#8a8f7e]">Продать каравану</div>
          <div className="space-y-1">
            {trade.sellable.length === 0 && <div className="rounded bg-black/25 px-2.5 py-2 text-[12px] text-[#8a8f7e]">Продавать нечего — торговец вздыхает.</div>}
            {trade.sellable.map((s) => (
              <div key={s.res} className="flex items-center gap-2 rounded-md bg-black/30 px-2.5 py-2">
                <span className="text-[16px]">{s.icon}</span>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[12px] font-semibold text-[#c8cbb8]">{s.name}</div>
                  <div className="text-[10px] text-[#8a8f7e]">у колонии: {s.qty}</div>
                  {s.stat && <div className="text-[10px] text-[#c9a84a]">{s.stat}</div>}
                </div>
                <span className="text-[12px] font-bold text-[#d9b13f]">🪙 {s.price}</span>
                <button onClick={() => onSell(s.res, 1)} className="rounded bg-[#3a4530] px-2 py-1.5 text-[11px] text-[#f0dfae]">
                  ×1
                </button>
                <button onClick={() => onSell(s.res, 5)} className="rounded bg-[#3a4530] px-2 py-1.5 text-[11px] text-[#f0dfae]">
                  ×5
                </button>
              </div>
            ))}
          </div>
        </div>
        <div className="mt-2 text-[10px] leading-snug text-[#8a8f7e]">
          Серебро добывается из серебряных жил в горах, находится в шахтных глубинах и выручается за продажу находок.
        </div>
        <button onClick={onClose} className="mt-3 w-full rounded-md bg-[#d9b13f] py-2 text-[13px] font-semibold text-black">
          Достаточно
        </button>
      </div>
    </div>
  );
}

// ================= Нижняя панель: категории с выпадающим меню (RimWorld-стиль) =================
const TOOL_CATS: { id: string; name: string; icon: string; tools: Tool[] }[] = [
  { id: 'orders', name: 'Приказы', icon: '🪓', tools: ['chop', 'mine', 'harvest', 'hunt', 'attack'] },
  { id: 'build', name: 'Стройка', icon: '🧱', tools: ['wall', 'stonewall', 'door', 'bed', 'campfire', 'workbench', 'table', 'chair', 'torch', 'grave', 'mineshaft', 'trap', 'turret'] },
  { id: 'zones', name: 'Зоны', icon: '📦', tools: ['stockpile', 'farm'] },
];

export function ActionBar({ ui, onTool }: { ui: UiState; onTool: (t: Tool) => void }) {
  const [openCat, setOpenCat] = useState<string | null>(null);
  const activeCat = TOOL_CATS.find((c) => c.tools.includes(ui.tool));
  const cat = TOOL_CATS.find((c) => c.id === openCat) ?? null;
  const pick = (t: Tool) => {
    onTool(t);
    setOpenCat(null);
  };
  return (
    <div className="z-20 shrink-0 border-t border-black/50 bg-[#1c2218]">
      {cat && (
        <div className="border-b border-black/40 bg-[#242c1e] px-2 pb-2 pt-1.5">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase tracking-wide text-[#d9b13f]">
              {cat.icon} {cat.name}
            </span>
            <button
              onClick={() => setOpenCat(null)}
              className="h-6 w-8 rounded bg-black/30 text-[11px] text-[#c8cbb8]"
              aria-label="Свернуть"
            >
              ▾
            </button>
          </div>
          <div
            className="grid gap-1.5"
            style={{ gridTemplateColumns: `repeat(${Math.min(cat.tools.length, 4)}, minmax(0, 1fr))` }}
          >
            {cat.tools.map((t) => {
              const info = TOOL_INFO[t];
              const active = ui.tool === t;
              return (
                <button
                  key={t}
                  onClick={() => pick(t)}
                  className={`flex flex-col items-center justify-center gap-0.5 rounded-md px-1 py-2 text-[10px] leading-tight ${
                    active ? 'bg-[#d9b13f] text-black' : 'bg-black/30 text-[#c8cbb8]'
                  }`}
                >
                  <span className="text-[17px]">{info.icon}</span>
                  {info.name}
                </button>
              );
            })}
          </div>
          {cat.id === 'zones' && (
            <div className="mt-1.5 text-[10px] leading-snug text-[#8a8f7e]">
              В стороне — новая зона; вплотную к зоне того же типа — расширение её. Осмотр зоны → ⚙️ настройки: имя и ресурсы.
            </div>
          )}
        </div>
      )}
      <div className="flex gap-1 px-2 py-1.5">
        {TOOL_CATS.map((c) => {
          const isActive = activeCat?.id === c.id;
          return (
            <button
              key={c.id}
              onClick={() => setOpenCat(openCat === c.id ? null : c.id)}
              className={`flex h-[46px] min-w-0 flex-1 flex-col items-center justify-center gap-0.5 rounded-md px-1 text-[10px] leading-tight ${
                isActive
                  ? 'bg-[#d9b13f] text-black'
                  : openCat === c.id
                    ? 'bg-[#3a4530] text-[#f0dfae]'
                    : 'bg-black/30 text-[#c8cbb8]'
              }`}
              aria-label={`Категория ${c.name}`}
            >
              <span className="text-[16px]">{isActive ? TOOL_INFO[ui.tool].icon : c.icon}</span>
              <span className="max-w-full truncate">{isActive ? TOOL_INFO[ui.tool].name : c.name}</span>
            </button>
          );
        })}
        <button
          onClick={() => {
            setOpenCat(null);
            onTool('inspect');
          }}
          className="flex h-[46px] w-[64px] shrink-0 flex-col items-center justify-center gap-0.5 rounded-md bg-black/50 px-1 text-[10px] text-[#e8a0a0]"
        >
          <span className="text-[16px]">✖</span>
          Отмена
        </button>
      </div>
    </div>
  );
}

// ================= Карточка пешки =================
export function PawnCard({
  pawn,
  followId,
  onClose,
  onFollow,
  onReorder,
}: {
  pawn: PawnDetail;
  followId: number | null;
  onClose: () => void;
  onFollow: (id: number | null) => void;
  onReorder: (pawnId: number, index: number, dir: -1 | 1) => void;
}) {
  const traitNames = pawn.traits
    .map((t) => TRAITS.find((tr) => tr.id === t)?.name ?? t)
    .join(' · ');
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/50 sm:items-center" onClick={onClose}>
      <div
        className="max-h-[85vh] w-full max-w-sm overflow-y-auto rounded-t-xl border border-black/50 bg-[#1c2218] p-4 sm:rounded-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-full" style={{ background: pawn.color }} />
              <span className="text-base font-bold">
                {pawn.name} · {traitNames}
              </span>
            </div>
            <div className="mt-0.5 text-[12px] text-[#a8ad9a]">
              {pawn.action} · {pawn.gender === 'ж' ? 'женщина' : 'мужчина'}, {pawn.age}
              {pawn.carrying ? ' · несёт груз' : ''}
            </div>
            {pawn.weapon && (
              <div className="mt-0.5 text-[12px] text-[#d9b13f]">
                Оружие: {pawn.weaponName} {pawn.weaponIcon ?? ''} — {pawn.weaponStats}
              </div>
            )}
            {pawn.armor && (
              <div className="mt-0.5 text-[12px] text-[#8fb0d9]">
                Броня: {pawn.armorName} {pawn.armorIcon ?? ''} — {pawn.armorStats}
              </div>
            )}
            {pawn.cloth === 'coat' && (
              <div className="mt-0.5 text-[12px] text-[#a8c9d9]">🧥 Тёплая куртка — греет зимой · настроение +3 в мороз</div>
            )}
          </div>
          <button onClick={onClose} className="text-[#8a8f7e]" aria-label="Закрыть">
            ✕
          </button>
        </div>

        <div className="mt-3 space-y-1.5">
          <Bar v={pawn.hp} color="#8fd05a" label="Здоровье" />
          <Bar v={pawn.food} color="#d9913f" label="Сытость" />
          <Bar v={pawn.rest} color="#6aa88a" label="Бодрость" />
          <Bar v={pawn.mood} color="#d9b13f" label="Настроение" />
        </div>

        <div className="mt-3">
          <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-[#8a8f7e]">Настроение: причины</div>
          <div className="flex flex-wrap gap-1">
            {pawn.mods.length === 0 && <span className="text-[11px] text-[#8a8f7e]">Всё спокойно</span>}
            {pawn.mods.map((m, i) => (
              <span
                key={i}
                className={`rounded px-1.5 py-0.5 text-[10px] ${
                  m.delta >= 0 ? 'bg-[#3a4a2c] text-[#c8e8a8]' : 'bg-[#4a2c2c] text-red-200'
                }`}
              >
                {m.delta >= 0 ? '+' : ''}
                {m.delta} {m.label}
              </span>
            ))}
          </div>
        </div>

        <div className="mt-3">
          <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-[#8a8f7e]">Навыки</div>
          <div className="grid grid-cols-2 gap-x-3 gap-y-1">
            {pawn.skills.map((s) => (
              <div key={s.id} className="flex items-center justify-between text-[12px]">
                <span className="text-[#c8cbb8]">{s.name}</span>
                <span className="text-[#d9b13f]">{s.lvl}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-3">
          <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-[#8a8f7e]">Приоритеты работ</div>
          <div className="mb-1 text-[10px] leading-snug text-[#8a8f7e]">Первый номер — главное занятие: с ним пешка берёт задачи в первую очередь.</div>
          <div className="space-y-1">
            {pawn.priorities.map((catId, idx) => {
              const cat = WORK_CATS.find((c) => c.id === catId);
              return (
                <div key={catId} className="flex items-center gap-2">
                  <span className="w-4 text-center text-[11px] text-[#8a8f7e]">{idx + 1}</span>
                  <span className="flex-1 text-[12px]">{cat?.name ?? catId}</span>
                  <button
                    onClick={() => onReorder(pawn.id, idx, -1)}
                    className="h-6 w-7 rounded bg-black/30 text-[11px]"
                    aria-label="Выше"
                  >
                    ▲
                  </button>
                  <button
                    onClick={() => onReorder(pawn.id, idx, 1)}
                    className="h-6 w-7 rounded bg-black/30 text-[11px]"
                    aria-label="Ниже"
                  >
                    ▼
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {pawn.relations.length > 0 && (
          <div className="mt-3">
            <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-[#8a8f7e]">Отношения</div>
            {pawn.relations.map((r) => (
              <div key={r.name} className="flex items-center justify-between text-[12px]">
                <span>{r.name}</span>
                <span className={r.score >= 25 ? 'text-[#8fd05a]' : r.score < 0 ? 'text-red-300' : 'text-[#c8cbb8]'}>
                  {r.score >= 25 ? 'друг' : `${r.score > 0 ? '+' : ''}${r.score}`}
                </span>
              </div>
            ))}
          </div>
        )}

        <div className="mt-4 flex gap-2">
          <button
            onClick={() => onFollow(followId === pawn.id ? null : pawn.id)}
            className={`flex-1 rounded-md py-2 text-[13px] font-semibold ${
              followId === pawn.id ? 'bg-[#8fd05a] text-black' : 'bg-[#d9b13f] text-black'
            }`}
          >
            {followId === pawn.id ? 'Не следовать' : 'Следовать'}
          </button>
          <button onClick={onClose} className="rounded-md bg-black/40 px-4 py-2 text-[13px]">
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
}

// ================= Журнал =================
export function JournalModal({ events, onClose }: { events: LogEntry[]; onClose: () => void }) {
  const colorOf = (k: LogEntry['kind']) =>
    k === 'bad' ? 'text-red-300' : k === 'good' ? 'text-[#c8e8a8]' : k === 'story' ? 'text-[#f0dfae]' : 'text-[#c8cbb8]';
  const sorted = [...events].reverse();
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/50 sm:items-center" onClick={onClose}>
      <div
        className="flex max-h-[80vh] w-full max-w-md flex-col rounded-t-xl border border-black/50 bg-[#1c2218] p-4 sm:rounded-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-2 flex items-center justify-between">
          <span className="text-base font-bold text-[#d9b13f]">История колонии</span>
          <button onClick={onClose} className="text-[#8a8f7e]" aria-label="Закрыть">
            ✕
          </button>
        </div>
        <div className="min-h-0 flex-1 space-y-1.5 overflow-y-auto pr-1">
          {sorted.length === 0 && <div className="text-[12px] text-[#8a8f7e]">Пока ничего не случилось...</div>}
          {sorted.map((e) => {
            const day = Math.floor(e.t / 1440) + 1;
            const hh = Math.floor((e.t % 1440) / 60).toString().padStart(2, '0');
            const mm = Math.floor(e.t % 60).toString().padStart(2, '0');
            return (
              <div key={e.id} className="rounded bg-black/25 px-2.5 py-1.5">
                <div className="text-[10px] text-[#8a8f7e]">
                  День {day}, {hh}:{mm}
                </div>
                <div className={`text-[12px] ${colorOf(e.kind)}`}>{e.text}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ================= Диалог события (выбор игрока) =================
export function ChoiceModal({
  choice,
  onPick,
}: {
  choice: NonNullable<UiState['choice']>;
  onPick: (i: number) => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-5">
      <div className="w-full max-w-sm rounded-xl border border-[#d9b13f]/40 bg-[#1c2218] p-4 shadow-2xl">
        <div className="text-center text-lg font-bold text-[#d9b13f]">
          <span className="mr-1.5">{choice.icon}</span>
          {choice.title}
        </div>
        <div className="mt-2 text-center text-[13px] leading-relaxed text-[#c8cbb8]">{choice.text}</div>
        <div className="mt-4 space-y-2">
          {choice.options.map((o, i) => (
            <button
              key={i}
              onClick={() => onPick(i)}
              className="w-full rounded-md bg-black/40 px-3 py-2.5 text-left transition-colors active:bg-[#d9b13f]/20"
            >
              <div className="text-[13px] font-semibold text-[#f0dfae]">{o.label}</div>
              <div className="text-[11px] text-[#8a8f7e]">{o.hint}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ================= Меню паузы: сохранить / загрузить / настройки =================
type MenuView = 'main' | 'settings' | 'help';

function ToggleRow({ on, label, desc, onClick }: { on: boolean; label: string; desc: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center justify-between gap-3 rounded-md bg-black/30 px-3 py-2.5 text-left active:bg-black/50"
    >
      <span className="min-w-0">
        <span className="block text-[13px] font-semibold text-[#f0dfae]">{label}</span>
        <span className="mt-0.5 block text-[11px] leading-snug text-[#8a8f7e]">{desc}</span>
      </span>
      <span className={`h-6 w-10 shrink-0 rounded-full p-0.5 transition-colors ${on ? 'bg-[#8fd05a]' : 'bg-black/60'}`}>
        <span className={`block h-5 w-5 rounded-full bg-[#e8e6df] shadow transition-transform ${on ? 'translate-x-4' : ''}`} />
      </span>
    </button>
  );
}

export function MenuModal({
  seed,
  day,
  settings,
  onClose,
  onSave,
  onLoad,
  onNewGame,
  onSetting,
}: {
  seed: number;
  day: number;
  settings: GameSettings;
  onClose: () => void;
  onSave: () => void;
  onLoad: () => void;
  onNewGame: () => void;
  onSetting: (k: keyof GameSettings, v: boolean) => void;
}) {
  const [view, setView] = useState<MenuView>('main');
  const [confirmNew, setConfirmNew] = useState(false);
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/50" onClick={onClose}>
      <div
        className="max-h-[88vh] w-full max-w-xs overflow-y-auto rounded-xl border border-black/50 bg-[#1c2218] p-4"
        onClick={(e) => e.stopPropagation()}
      >
        {view === 'main' && (
          <>
            <div className="mb-0.5 text-center text-lg font-bold tracking-widest text-[#d9b13f]">ОСКОЛОК</div>
            <div className="mb-3 text-center text-[11px] text-[#8a8f7e]">Пауза · День {day} · Seed {seed}</div>
            <div className="space-y-2">
              <button onClick={onClose} className="w-full rounded-md bg-[#d9b13f] py-2 text-[13px] font-semibold text-black">
                Продолжить
              </button>
              <button onClick={onSave} className="w-full rounded-md bg-black/40 py-2 text-[13px]">
                💾 Сохранить игру
              </button>
              <button onClick={onLoad} className="w-full rounded-md bg-black/40 py-2 text-[13px]">
                📂 Загрузить игру
              </button>
              <button onClick={() => setView('settings')} className="w-full rounded-md bg-black/40 py-2 text-[13px]">
                ⚙️ Настройки игры
              </button>
              {!confirmNew ? (
                <button onClick={() => setConfirmNew(true)} className="w-full rounded-md bg-red-900/50 py-2 text-[13px] text-red-200">
                  Новая игра
                </button>
              ) : (
                <div className="rounded-md bg-red-950/60 p-2 text-center">
                  <div className="mb-2 text-[12px] text-red-200">Текущий прогресс будет потерян. Начать заново?</div>
                  <div className="flex gap-2">
                    <button onClick={() => setConfirmNew(false)} className="flex-1 rounded bg-black/40 py-1.5 text-[12px]">
                      Нет
                    </button>
                    <button onClick={onNewGame} className="flex-1 rounded bg-red-800 py-1.5 text-[12px] text-white">
                      Да, заново
                    </button>
                  </div>
                </div>
              )}
              <button onClick={() => setView('help')} className="w-full rounded-md bg-black/40 py-2 text-[13px]">
                Как играть?
              </button>
            </div>
          </>
        )}

        {view === 'settings' && (
          <>
            <div className="mb-3 flex items-center justify-between">
              <span className="text-base font-bold text-[#d9b13f]">⚙️ Настройки</span>
              <button onClick={() => setView('main')} className="text-[#8a8f7e]" aria-label="Назад">
                ✕
              </button>
            </div>
            <div className="space-y-2">
              <ToggleRow
                on={settings.autosave}
                label="Автосохранение"
                desc="Игра записывается сама во время игры и при сворачивании приложения. Выключите — сохранять только вручную."
                onClick={() => onSetting('autosave', !settings.autosave)}
              />
              <ToggleRow
                on={settings.autopauseEvents}
                label="Автопауза на события"
                desc="Происшествия с выбором (путники, тайники) останавливают время, пока вы решаете их судьбу."
                onClick={() => onSetting('autopauseEvents', !settings.autopauseEvents)}
              />
              <ToggleRow
                on={settings.autopauseAlarm}
                label="Автопауза на тревогу"
                desc="Когда стая волков идёт на штурм, время останавливается — успейте запереть двери и поднять колонию."
                onClick={() => onSetting('autopauseAlarm', !settings.autopauseAlarm)}
              />
            </div>
            <div className="mt-2 text-[10px] leading-snug text-[#8a8f7e]">Настройки хранятся вместе с игрой.</div>
            <button onClick={() => setView('main')} className="mt-3 w-full rounded-md bg-[#d9b13f] py-2 text-[13px] font-semibold text-black">
              Назад
            </button>
          </>
        )}

        {view === 'help' && (
          <div className="space-y-2 text-[12px] leading-relaxed text-[#c8cbb8]">
            <p>
              <b className="text-[#d9b13f]">1.</b> Отмечайте работу инструментами внизу: «Рубить» — деревья, «Копать» — камни, «Собрать» — ягоды.
            </p>
            <p>
              <b className="text-[#d9b13f]">2.</b> Колонисты сами выберут исполнителя: понесут ресурсы на склад, построят стены и кровати, посадят ферму.
            </p>
            <p>
              <b className="text-[#d9b13f]">3.</b> Не забывайте про еду (🍖) и кровати. Ночью появляются волки — стройте стены и двери.
            </p>
            <p>
              <b className="text-[#d9b13f]">4.</b> Один палец — работа/осмотр, два пальца — перемещение карты, щипок — масштаб. Двойной тап — приблизить.
            </p>
            <p>
              <b className="text-[#d9b13f]">5.</b> Нажмите на колониста, чтобы увидеть нужды, навыки и настроить приоритеты работ.
            </p>
            <p>
              <b className="text-[#d9b13f]">6.</b> В колонии будут случаться происшествия — путники, тайники, болезни. Решения скажутся на истории.
            </p>
            <p>
              <b className="text-[#d9b13f]">7.</b> Иногда к костру выйдет странник и попросит приюта. Новые руки ускорят работу, но и еды нужно больше.
            </p>
            <p>
              <b className="text-[#d9b13f]">8.</b> Следите за настроением! Если колонист долго голодает, ранен или горюет — он сорвётся: станет оскорблять всех, плакать или бродить в оцепенении. Накормите, вылечите и дайте выспаться.
            </p>
            <p>
              <b className="text-[#d9b13f]">9.</b> Оленей можно добыть инструментом «Атака» — из одного оленя выходит вдвое больше мяса, чем из кролика.
            </p>
            <p>
              <b className="text-[#d9b13f]">10.</b> С четвёртого дня волки ходят на штурм: стая идёт прямо к лагерю и грызёт стены и двери. При тревоге (⚠) смелые и опытные бойцы сами бегут на защиту. Деревянная стена — щит, но пролом придётся латать; каменная стена (🗿) вдвое крепче — волкам не по зубам.
            </p>
            <p>
              <b className="text-[#d9b13f]">11.</b> Костёр — это ещё и кухня: когда сырой еды достаточно, колонисты сами сварят похлёбку (🍲). Она сытнее сырой еды и поднимает настроение — голодные колонисты сами предпочтут её.
            </p>
            <p>
              <b className="text-[#d9b13f]">12.</b> Постройте верстак (🔨) — колонисты смастерят копья и луки, а из железа — мечи. Цифры урона видны прямо в меню производства и в карточке пешки: копьё бьёт на 8–12, лук — на 3–6, зато с расстояния 4 клеток, меч — самый сильный в ближнем бою (7–12) и бьёт чаще копья. Безоружный дерётся кулаками (2–4) и сам возьмёт оружие получше. Броня гасит урон зверей: кожаная — 30%, железная — 55%. Погибший роняет оружие — его подберёт другой.
            </p>
            <p>
              <b className="text-[#d9b13f]">13.</b> Инструменты внизу собраны в категории: «Приказы», «Стройка», «Зоны». Зон может быть несколько: нарисуйте склад/ферму в стороне — получится отдельная зона, вплотную к существующей — расширение. Тап по зоне инструментом «Осмотр» → кнопка «⚙️ Настройки зоны»: переименуйте её и укажите, какие ресурсы склад принимает.
            </p>
            <p>
              <b className="text-[#d9b13f]">14.</b> Год идёт по сезонам: ☀️ лето, 🍂 осень, ❄️ зима, 🌷 весна — по 6 дней каждый. Зимой трава и ягода не растут, олени уходят, снег замедляет шаг, а ночью на морозе колонисты мёрзнут и теряют силы — держите их у костра и в кроватях. Иногда налетает буран: работать почти невозможно. Готовьте запасы похлёбки с осени!
            </p>
            <p>
              <b className="text-[#d9b13f]">15.</b> Уют тоже важен: постройте стол (🍽️) и стулья (🪑) у него — колонисты будут есть за столом и получать радость. Факел (🕯️) освещает тропинки и вход в дом ночью, его хватит на пару деревяшек.
            </p>
            <p>
              <b className="text-[#d9b13f]">16.</b> Железо — опора колонии. В горах и лесу блестят рудные жилы: копайте их инструментом «Копать». Постройте шахту (🕳️, 4 дерева) на серой скале — и отправляйте экспедиции в глубины за железом, камнем и серебром. На верстаке из железа куют мечи. Проверяйте настройки склада: железо туда тоже носят.
            </p>
            <p>
              <b className="text-[#d9b13f]">17.</b> Смерть — не конец истории: постройте могилу (🪦, 2 камня), и погибшего похоронят с именем — над его могилой встанет надгробие. Зимой замёрзший колонист сам пойдёт греться к костру.
            </p>
            <p>
              <b className="text-[#d9b13f]">18.</b> Кнопка паузы (⏸) вверху останавливает время и открывает меню игры: сохранение, загрузка, настройки. Рядом — выпадающий список скорости: ×1, ×2, ×4, ×8 и ×16. Автосохранение и автопаузу на тревогу можно настроить в «⚙️ Настройках игры».
            </p>
            <p>
              <b className="text-[#d9b13f]">19.</b> Горы теперь сплошные, как в RimWorld: серый монолит не пройти — только вгрызться инструментом «Копать». Каждый выкопанный тайл — туннель с камнем, а иногда и железом. В толще прячутся железные жилы (ржавый блеск) и редкое серебро (белая искра).
            </p>
            <p>
              <b className="text-[#d9b13f]">20.</b> Шахта (🕳️) — вход в отдельную локацию: глубины с сюрпризами. Тап по шахте → «Экспедиция»: лучший шахтёр спустится на ~9 часов и вернётся с рудой. По пути — богатые жилы, обвалы, пещерные звери, тайники и серебро. Следите за прогрессом в окне шахты.
            </p>
            <p>
              <b className="text-[#d9b13f]">21.</b> Верстак и костёр работают по заказам. Тап по верстаку → «🔨 Производство»: выберите изделие и сколько сделать (×1/×5/×10). Тап по костру → «🍲 Готовка»: задайте, до скольких порций варить похлёбку. Колонисты сами выполнят заказы по порядку.
            </p>
            <p>
              <b className="text-[#d9b13f]">22.</b> Защитные сооружения: колья (🪤, 4 дерева) — ловушка на тропе, зверь напорется и получит тяжёлую рану; арбалетная башня (🏹, 5 железа) сама бьёт болтами по волкам в радиусе 5 клеток. Ставьте их на пути стаи и у ворот.
            </p>
            <p>
              <b className="text-[#d9b13f]">23.</b> Каждые несколько дней приходит торговый караван: тап по торговцу → «⚖️ Торговать». Покупайте товары за серебро (🪙), продавайте ресурсы и находки. Серебро добывают из жил в горах и находят в шахтных глубинах.
            </p>
            <p>
              <b className="text-[#d9b13f]">24.</b> Охота (🎯 в «Приказах»): тап по зверю — пометить его, рамкой — целое стадо. Охотник сам догонит дичь и принесёт мясо и шкуры. Олень и кролик убегают — им нужен стрелок с луком (сделайте на верстаке). Кабан, волк и медведь могут ответить — отправляйте на них вооружённых. Пометку снимают повторным тапом или кнопкой в окне зверя. Приоритеты работ (в карточке пешки) задают, кто за какую работу возьмётся первым.
            </p>
            <button onClick={() => setView('main')} className="mt-2 w-full rounded-md bg-[#d9b13f] py-2 text-[13px] font-semibold text-black">
              Понятно
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ================= Конец игры =================
export function GameOverOverlay({ days, onRestart }: { days: number; onRestart: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-6 text-center">
      <div>
        <div className="mb-2 text-5xl">🥀</div>
        <div className="mb-1 text-xl font-bold text-red-300">Колония пала</div>
        <div className="mb-6 text-[13px] text-[#a8ad9a]">Прожито дней: {days}. Их история окончена.</div>
        <button onClick={onRestart} className="rounded-md bg-[#d9b13f] px-6 py-2.5 text-[14px] font-semibold text-black">
          Начать новую историю
        </button>
      </div>
    </div>
  );
}

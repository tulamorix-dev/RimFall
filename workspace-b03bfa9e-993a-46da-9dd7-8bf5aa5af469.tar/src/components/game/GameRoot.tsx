'use client';

// ОСКОЛОК — корневой компонент: монтирует движок, канвас и весь интерфейс

import { useCallback, useEffect, useRef, useState } from 'react';
import { Game, type GameSettings } from '@/game/core/game';
import { Renderer } from '@/game/render/renderer';
import { Minimap } from '@/game/render/minimap';
import { loadGame, saveGame, clearSave } from '@/game/save';
import type { LogEntry } from '@/game/core/events';
import {
  TopBar,
  PawnStrip,
  MinimapPanel,
  ActionBar,
  PawnCard,
  InfoPopup,
  Toasts,
  JournalModal,
  MenuModal,
  GameOverOverlay,
  ChoiceModal,
  ToolHint,
  ZoneSettingsModal,
  ProductionModal,
  ExpeditionModal,
  TradeModal,
} from './GameUI';
import { AdminPanel } from './AdminPanel';

type UiState = ReturnType<Game['uiSnapshot']>;
type PawnDetail = NonNullable<ReturnType<Game['pawnDetail']>>;

export default function GameRoot() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const miniRef = useRef<HTMLCanvasElement | null>(null);
  const gameRef = useRef<Game | null>(null);
  const rendererRef = useRef<Renderer | null>(null);
  const [ui, setUi] = useState<UiState | null>(null);
  const [toasts, setToasts] = useState<(LogEntry & { rt: number })[]>([]);
  const [journal, setJournal] = useState<LogEntry[]>([]);
  const [journalOpen, setJournalOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [gameInst, setGameInst] = useState<Game | null>(null);
  const adminReturnSpeed = useRef<0 | 1 | 2 | 4 | 8 | 16>(1);
  const [tradeOpen, setTradeOpen] = useState(false);
  const [expMineId, setExpMineId] = useState<number | null>(null);
  const [ready, setReady] = useState(false);
  const [bootError, setBootError] = useState<string | null>(null);

  const pushToast = useCallback((e: LogEntry) => {
    setToasts((prev) => [...prev.slice(-3), { ...e, rt: Date.now() }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== e.id));
    }, 6000);
  }, []);

  const systemToast = useCallback((text: string) => {
    pushToast({ id: Math.floor(Math.random() * 1e9), t: 0, text, kind: 'info' });
  }, [pushToast]);

  useEffect(() => {
    let cancelled = false;
    let raf = 0;
    let uiTimer: ReturnType<typeof setInterval> | null = null;

    (async () => {
      try {
        const save = await loadGame();
        if (cancelled) return;
        const game = new Game();
        if (save) {
          try {
            game.applySave(save);
          } catch (err) {
            console.error('Save corrupt, starting new game', err);
            game.newGame();
          }
        }
        gameRef.current = game;
        setGameInst(game);
        // автосохранение — только когда включено в настройках игры
        game.autosaveHook = (g) => {
          if (g.gameSettings.autosave) void saveGame(g.serialize());
        };
        game.events.onEvent = (e) => {
          if (!cancelled) pushToast(e);
        };

        const canvas = canvasRef.current;
        const mini = miniRef.current;
        if (!canvas || !mini) return;
        const renderer = new Renderer(canvas, game);
        rendererRef.current = renderer;
        // отладочный доступ (dev)
        (window as unknown as Record<string, unknown>).__game = game;
        (window as unknown as Record<string, unknown>).__renderer = renderer;
        const base = game.centerBase();
        renderer.cam.x = base.x * 32;
        renderer.cam.y = base.y * 32;
        renderer.cam.clampToMap();
        const minimap = new Minimap(mini, game, renderer.cam);

        // игровой цикл
        let last = performance.now();
        let miniT = 0;
        const loop = (ts: number) => {
          const dt = Math.min((ts - last) / 1000, 0.1);
          last = ts;
          game.tick(dt);
          renderer.draw(dt);
          miniT -= dt;
          if (miniT <= 0) {
            miniT = 0.4;
            minimap.draw();
          }
          raf = requestAnimationFrame(loop);
        };
        raf = requestAnimationFrame(loop);

        // снимок UI
        uiTimer = setInterval(() => {
          setUi(game.uiSnapshot());
          setJournal([...game.events.entries]);
        }, 280);
        setUi(game.uiSnapshot());
        setJournal([...game.events.entries]);
        setReady(true);

        // PWA service worker
        if ('serviceWorker' in navigator) {
          navigator.serviceWorker.register('/sw.js').catch(() => {});
        }
      } catch (err) {
        console.error(err);
        setBootError(err instanceof Error ? err.message : 'Ошибка запуска');
      }
    })();

    const onVis = () => {
      if (document.hidden && gameRef.current && gameRef.current.gameSettings.autosave) {
        void saveGame(gameRef.current.serialize());
      }
    };
    document.addEventListener('visibilitychange', onVis);

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      if (uiTimer) clearInterval(uiTimer);
      document.removeEventListener('visibilitychange', onVis);
      if (gameRef.current && gameRef.current.gameSettings.autosave) void saveGame(gameRef.current.serialize());
    };
  }, [pushToast]);

  // ---------- Действия UI ----------
  const setTool = useCallback((tool: UiState['tool']) => {
    const g = gameRef.current;
    if (!g) return;
    g.tool = tool;
    g.clearSelection();
    setUi(g.uiSnapshot());
  }, []);

  const setSpeed = useCallback((s: 0 | 1 | 2 | 4 | 8 | 16) => {
    const g = gameRef.current;
    if (!g) return;
    g.setSpeed(s);
    setUi(g.uiSnapshot());
  }, []);

  // Кнопка паузы: остановить время и открыть меню игры (сохранить/загрузить/настройки)
  const pauseMenu = useCallback(() => {
    const g = gameRef.current;
    if (!g || g.gameOver) return;
    if (g.pendingChoice) return; // диалог события важнее
    g.setSpeed(0);
    setUi(g.uiSnapshot());
    setMenuOpen(true);
  }, []);

  // Админ-панель: пауза + запоминаем прежнюю скорость, чтобы вернуть при закрытии
  const openAdmin = useCallback(() => {
    const g = gameRef.current;
    if (!g || g.pendingChoice) return;
    adminReturnSpeed.current = g.clock.speed === 0 ? 1 : g.clock.speed;
    g.setSpeed(0);
    setUi(g.uiSnapshot());
    setAdminOpen(true);
  }, []);

  const closeAdmin = useCallback(() => {
    const g = gameRef.current;
    setAdminOpen(false);
    if (g) {
      g.setSpeed(adminReturnSpeed.current);
      setUi(g.uiSnapshot());
    }
  }, []);

  const setSetting = useCallback((k: keyof GameSettings, v: boolean) => {
    const g = gameRef.current;
    if (!g) return;
    g.gameSettings[k] = v;
    setUi(g.uiSnapshot());
  }, []);

  // Загрузка сохранения прямо в сессии (меню паузы → «Загрузить игру»)
  const loadNow = useCallback(async () => {
    const g = gameRef.current;
    const r = rendererRef.current;
    if (!g) return;
    const data = await loadGame();
    if (!data) {
      systemToast('Сохранение не найдено');
      return;
    }
    try {
      g.applySave(data);
    } catch (err) {
      console.error('Load failed', err);
      systemToast('Сейв повреждён');
      return;
    }
    g.setSpeed(0); // после загрузки — пауза: время не убегает, пока игрок осматривается
    if (r) {
      r.rebuildFull();
      const c = g.centerBase();
      r.cam.x = c.x * 32;
      r.cam.y = c.y * 32;
      r.cam.followId = null;
    }
    g.followId = null;
    setMenuOpen(false);
    setUi(g.uiSnapshot());
    systemToast(`Игра загружена: День ${Math.floor(data.totalMin / 1440) + 1}`);
  }, [systemToast]);

  const pickChoice = useCallback((i: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.resolveChoice(i);
    setUi(g.uiSnapshot());
  }, []);

  const followPawn = useCallback((id: number | null) => {
    const g = gameRef.current;
    const r = rendererRef.current;
    if (!g || !r) return;
    g.followId = id;
    r.cam.followId = id;
    setUi(g.uiSnapshot());
  }, []);

  const centerBase = useCallback(() => {
    const g = gameRef.current;
    const r = rendererRef.current;
    if (!g || !r) return;
    const c = g.centerBase();
    r.cam.x = c.x * 32;
    r.cam.y = c.y * 32;
    r.cam.followId = null;
    g.followId = null;
  }, []);

  const selectPawn = useCallback((id: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.selectedPawnId = id;
    g.selectedInfo = null;
    setUi(g.uiSnapshot());
  }, []);

  const closeInfo = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    g.clearSelection();
    setUi(g.uiSnapshot());
  }, []);

  const cancelBlueprint = useCallback(() => {
    const g = gameRef.current;
    if (!g || !g.selectedInfo || g.selectedInfo.tile < 0) return;
    const i = g.selectedInfo.tile;
    g.cancelAt((i % 64) + 0.5, Math.floor(i / 64) + 0.5);
    g.clearSelection();
    setUi(g.uiSnapshot());
  }, []);

  const buryCorpse = useCallback((itemId: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.orderBurial(itemId);
    g.clearSelection();
    setUi(g.uiSnapshot());
  }, []);

  const openZoneSettings = useCallback((zoneId: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.clearSelection();
    g.settingsZoneId = zoneId;
    setUi(g.uiSnapshot());
  }, []);

  const closeZoneSettings = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    g.settingsZoneId = null;
    setUi(g.uiSnapshot());
  }, []);

  const renameZone = useCallback((id: number, name: string) => {
    const g = gameRef.current;
    if (!g) return;
    g.renameZone(id, name);
    setUi(g.uiSnapshot());
  }, []);

  const filterZone = useCallback((id: number, res: number, allowed: boolean) => {
    const g = gameRef.current;
    if (!g) return;
    g.setZoneFilter(id, res, allowed);
    setUi(g.uiSnapshot());
  }, []);

  const deleteZone = useCallback((id: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.deleteZone(id);
    setUi(g.uiSnapshot());
  }, []);

  // ---------- Производство / шахта / торговля ----------
  const openProduction = useCallback((bId: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.clearSelection();
    g.prodOpenId = bId;
    setUi(g.uiSnapshot());
  }, []);

  const closeProduction = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    g.prodOpenId = null;
    setUi(g.uiSnapshot());
  }, []);

  const addBill = useCallback((recipe: number, count: number) => {
    const g = gameRef.current;
    if (!g || g.prodOpenId === null) return;
    g.addBill(g.prodOpenId, recipe, count);
    setUi(g.uiSnapshot());
  }, []);

  const removeBill = useCallback((idx: number) => {
    const g = gameRef.current;
    if (!g || g.prodOpenId === null) return;
    g.removeBill(g.prodOpenId, idx);
    setUi(g.uiSnapshot());
  }, []);

  const setMealTarget = useCallback((n: number) => {
    const g = gameRef.current;
    if (!g || g.prodOpenId === null) return;
    g.setMealTarget(g.prodOpenId, n);
    setUi(g.uiSnapshot());
  }, []);

  const openExpedition = useCallback((mineId: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.clearSelection();
    setExpMineId(mineId);
    setUi(g.uiSnapshot());
  }, []);

  const sendExpedition = useCallback(() => {
    const g = gameRef.current;
    if (!g || expMineId === null) return;
    const ok = g.startExpedition(expMineId);
    if (ok) systemToast('Шахтёр отправляется в глубины');
    setUi(g.uiSnapshot());
  }, [expMineId, systemToast]);

  const huntToggle = useCallback((animalId: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.toggleHunt(animalId);
    setUi(g.uiSnapshot());
  }, []);

  const openTrade = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    g.clearSelection();
    setTradeOpen(true);
    setUi(g.uiSnapshot());
  }, []);

  const buyGood = useCallback((idx: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.buyGood(idx);
    setUi(g.uiSnapshot());
  }, []);

  const sellRes = useCallback((res: number, qty: number) => {
    const g = gameRef.current;
    if (!g) return;
    g.sellRes(res, qty);
    setUi(g.uiSnapshot());
  }, []);

  const saveNow = useCallback(async () => {
    const g = gameRef.current;
    if (!g) return;
    await saveGame(g.serialize());
    systemToast('Игра сохранена');
  }, [systemToast]);

  const doNewGame = useCallback(async () => {
    const g = gameRef.current;
    const r = rendererRef.current;
    if (!g) return;
    await clearSave();
    g.newGame();
    if (r) {
      r.rebuildFull();
      const c = g.centerBase();
      r.cam.x = c.x * 32;
      r.cam.y = c.y * 32;
      r.cam.zoom = 1;
      r.cam.followId = null;
    }
    g.followId = null;
    setMenuOpen(false);
    setUi(g.uiSnapshot());
    systemToast('Основана новая колония');
  }, [systemToast]);

  const reorder = useCallback((pawnId: number, index: number, dir: -1 | 1) => {
    const g = gameRef.current;
    if (!g) return;
    g.reorderPriority(pawnId, index, dir);
    setUi(g.uiSnapshot());
  }, []);

  // ---------- Рендер ----------
  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden bg-[#12170f] text-[#e8e6df] select-none" style={{ touchAction: 'none' }}>
      {ui && (
        <TopBar
          ui={ui}
          onSpeed={setSpeed}
          onJournal={() => setJournalOpen(true)}
          onPauseMenu={pauseMenu}
          onAdmin={openAdmin}
        />
      )}
      <div className="relative flex-1 min-h-0">
        <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
        <MinimapPanel miniRef={miniRef} onCenter={centerBase} />
        {ui && (
          <>
            <PawnStrip ui={ui} onSelect={selectPawn} />
            <Toasts toasts={toasts} />
            <ToolHint tool={ui.tool} />
            {ui.info && (
              <InfoPopup
                info={ui.info}
                onClose={closeInfo}
                onCancel={cancelBlueprint}
                onBury={buryCorpse}
                onZoneSettings={openZoneSettings}
                onProduction={openProduction}
                onExpedition={openExpedition}
                onTrade={openTrade}
                onHunt={huntToggle}
              />
            )}
          </>
        )}
        {!ready && !bootError && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-[#12170f]">
            <div className="text-center">
              <div className="mb-3 text-4xl">🌲</div>
              <div className="animate-pulse text-lg tracking-widest text-[#d9b13f]">ОСКОЛОК</div>
              <div className="mt-2 text-xs text-[#8a8f7e]">Генерация мира...</div>
            </div>
          </div>
        )}
        {bootError && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-[#12170f] p-6 text-center text-sm text-red-300">
            Ошибка запуска: {bootError}
          </div>
        )}
      </div>
      {ui && <ActionBar ui={ui} onTool={setTool} />}
      {ui && ui.selected && (
        <PawnCard
          pawn={ui.selected as PawnDetail}
          followId={ui.followId}
          onClose={() => {
            const g = gameRef.current;
            if (g) {
              g.clearSelection();
              setUi(g.uiSnapshot());
            }
          }}
          onFollow={followPawn}
          onReorder={reorder}
        />
      )}
      {journalOpen && <JournalModal events={journal} onClose={() => setJournalOpen(false)} />}
      {ui && ui.zoneSettings && (
        <ZoneSettingsModal
          key={`${ui.zoneSettings.id}:${ui.zoneSettings.name}`}
          zone={ui.zoneSettings}
          onClose={closeZoneSettings}
          onRename={renameZone}
          onFilter={filterZone}
          onDelete={deleteZone}
        />
      )}
      {ui && ui.prod && (
        <ProductionModal
          prod={ui.prod}
          onClose={closeProduction}
          onAddBill={addBill}
          onRemoveBill={removeBill}
          onMealTarget={setMealTarget}
        />
      )}
      {ui && expMineId !== null && (
        <ExpeditionModal expeditions={ui.expeditions} onClose={() => setExpMineId(null)} onSend={sendExpedition} />
      )}
      {ui && tradeOpen && ui.trade && <TradeModal trade={ui.trade} onClose={() => setTradeOpen(false)} onBuy={buyGood} onSell={sellRes} />}
      {ui && ui.choice && <ChoiceModal choice={ui.choice} onPick={pickChoice} />}
      {menuOpen && (
        <MenuModal
          seed={ui?.seed ?? 0}
          day={ui?.day ?? 1}
          settings={ui?.settings ?? { autosave: true, autopauseEvents: true, autopauseAlarm: false }}
          onClose={() => setMenuOpen(false)}
          onSave={saveNow}
          onLoad={loadNow}
          onNewGame={doNewGame}
          onSetting={setSetting}
        />
      )}
      {ui && ui.gameOver && <GameOverOverlay days={ui.day} onRestart={doNewGame} />}
      {adminOpen && gameInst && <AdminPanel game={gameInst} onClose={closeAdmin} />}
    </div>
  );
}

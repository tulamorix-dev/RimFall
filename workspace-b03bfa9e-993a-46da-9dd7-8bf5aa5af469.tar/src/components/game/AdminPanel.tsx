'use client';

// ОСКОЛОК — админ-панель: песочница над живой симуляцией.
// Вкладки: Колония (ресурсы/время/погода/события), Пешки, Звери, Мир, Рецепты.
// Читает состояние игры напрямую (опрос 400мс), правки применяются мгновенно.

import { useEffect, useState } from 'react';
import type { Game } from '@/game/core/game';
import { AdminAPI } from '@/game/admin';
import {
  RECIPES, RES_INFO, SKILLS, TRAITS, BType, MAP, Res, Terrain, Obj, ITEM_STATS, WEAPON_STATS,
  type RecipeDef, type SkillId, type WeaponKind, type ArmorKind,
} from '@/game/data/defs';
import { moodList } from '@/game/ai/pawnAI';

type Tab = 'colony' | 'pawns' | 'animals' | 'world' | 'recipes';

const TABS: { id: Tab; icon: string; name: string }[] = [
  { id: 'colony', icon: '🏰', name: 'Колония' },
  { id: 'pawns', icon: '👥', name: 'Пешки' },
  { id: 'animals', icon: '🐾', name: 'Звери' },
  { id: 'world', icon: '🏔️', name: 'Мир' },
  { id: 'recipes', icon: '📜', name: 'Рецепты' },
];

const B_ICON: Record<number, string> = {
  [BType.Wall]: '🧱', [BType.Door]: '🚪', [BType.Bed]: '🛏️', [BType.Campfire]: '🔥',
  [BType.Workbench]: '🔨', [BType.Table]: '🍽️', [BType.Chair]: '🪑', [BType.Torch]: '🕯️',
  [BType.StoneWall]: '🗿', [BType.Grave]: '🪦', [BType.Mine]: '🕳️', [BType.Trap]: '🪤',
  [BType.Turret]: '🏹',
};

const A_ICON: Record<string, string> = { wolf: '🐺', rabbit: '🐇', deer: '🦌', boar: '🐗', bear: '🐻', trader: '🧭' };
const A_STATE: Record<string, string> = {
  wander: 'бродит', hunt: 'охотится', attackWall: 'грызёт стену', flee: 'убегает',
  siege: 'идёт на штурм', arrive: 'приближается', wait: 'ждёт', leave: 'уходит',
};

// Все ресурсы для выпадающих списков
const ALL_RES: Res[] = Object.keys(Res)
  .filter((k) => !Number.isNaN(Number(k)))
  .map((k) => Number(k) as Res);

const RES_LIST = [
  { res: Res.Wood, name: 'Дерево' },
  { res: Res.Stone, name: 'Камень' },
  { res: Res.Food, name: 'Еда' },
  { res: Res.Meal, name: 'Похлёбка' },
  { res: Res.Iron, name: 'Железо' },
  { res: Res.Silver, name: 'Серебро' },
];

// ---------- Мелкие контролы ----------

function Section({ title, children, note }: { title: string; children: React.ReactNode; note?: string }) {
  return (
    <div className="rounded-lg border border-[#2c3526] bg-[#1a2016] p-2.5">
      <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-[#d9b13f]">{title}</div>
      <div className="space-y-2">{children}</div>
      {note && <div className="mt-2 text-[10px] leading-snug text-[#7a8070]">{note}</div>}
    </div>
  );
}

function Btn({ children, onClick, tone = 'normal', className = '' }: {
  children: React.ReactNode;
  onClick: () => void;
  tone?: 'normal' | 'gold' | 'danger' | 'ghost';
  className?: string;
}) {
  const tones = {
    normal: 'bg-[#31402c] text-[#dfe4d3] active:bg-[#3d5038]',
    gold: 'bg-[#d9b13f] text-black font-semibold active:bg-[#e6c25c]',
    danger: 'bg-[#5c2626] text-red-200 active:bg-[#743232]',
    ghost: 'bg-black/30 text-[#a8ad9a] active:bg-black/50',
  };
  return (
    <button onClick={onClick} className={`min-h-[34px] rounded px-2.5 py-1.5 text-[12px] ${tones[tone]} ${className}`}>
      {children}
    </button>
  );
}

// Числовой степпер: − value +
function Stepper({ label, value, min = 0, max = 9999, step = 1, onSet }: {
  label: string;
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onSet: (v: number) => void;
}) {
  const set = (v: number) => onSet(Math.min(max, Math.max(min, v)));
  return (
    <div className="flex items-center gap-1.5">
      <span className="min-w-[74px] shrink-0 text-[11px] text-[#a8ad9a]">{label}</span>
      <button onClick={() => set(value - step)} className="h-7 w-7 shrink-0 rounded bg-black/40 text-[13px] active:bg-black/60">−</button>
      <span className="min-w-[36px] text-center text-[12px] font-semibold text-[#e8e6df]">{Math.round(value)}</span>
      <button onClick={() => set(value + step)} className="h-7 w-7 shrink-0 rounded bg-[#31402c] text-[13px] active:bg-[#3d5038]">+</button>
    </div>
  );
}

// Текстовое/числовое поле с фиксацией по blur/Enter
function Field({ label, initial, onCommit, type = 'text', width = 'w-24' }: {
  label: string;
  initial: string | number;
  onCommit: (v: string) => void;
  type?: 'text' | 'number';
  width?: string;
}) {
  return (
    <label className="flex items-center gap-2 text-[11px] text-[#a8ad9a]">
      <span className="min-w-[74px] shrink-0">{label}</span>
      <input
        type={type}
        defaultValue={initial}
        onBlur={(e) => onCommit(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter') (e.target as HTMLInputElement).blur();
        }}
        className={`${width} rounded bg-black/40 px-2 py-1.5 text-[12px] text-[#e8e6df] outline-none ring-1 ring-[#2c3526] focus:ring-[#d9b13f]`}
      />
    </label>
  );
}

// Ползунок 0–100
function Slider({ label, value, color, onSet }: { label: string; value: number; color: string; onSet: (v: number) => void }) {
  return (
    <div>
      <div className="flex justify-between text-[11px]">
        <span className="text-[#a8ad9a]">{label}</span>
        <span className="font-semibold text-[#e8e6df]">{Math.round(value)}</span>
      </div>
      <input
        type="range"
        min={0}
        max={100}
        value={value}
        onChange={(e) => onSet(Number(e.target.value))}
        className="h-5 w-full accent-[#d9b13f]"
      />
      <div className="-mt-1 h-1.5 overflow-hidden rounded-sm bg-black/40">
        <div className="h-full" style={{ width: `${value}%`, background: color }} />
      </div>
    </div>
  );
}

// Выпадающий список
function Sel({ label, value, options, onChange }: {
  label: string;
  value: string | number;
  options: { v: string | number; label: string }[];
  onChange: (v: string) => void;
}) {
  return (
    <label className="flex items-center gap-2 text-[11px] text-[#a8ad9a]">
      <span className="min-w-[74px] shrink-0">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="flex-1 rounded bg-black/40 px-2 py-1.5 text-[12px] text-[#e8e6df] outline-none ring-1 ring-[#2c3526]"
      >
        {options.map((o) => (
          <option key={o.v} value={o.v} className="bg-[#1a2016]">
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}

// ================= Панель =================

export function AdminPanel({ game, onClose }: { game: Game; onClose: () => void }) {
  const api = new AdminAPI(game);
  const [, setTick] = useState(0);
  const [tab, setTab] = useState<Tab>('colony');
  const [pawnSel, setPawnSel] = useState<number | null>(null);
  const [killConfirm, setKillConfirm] = useState<number | null>(null);
  const [logText, setLogText] = useState('');
  const [tfRadius, setTfRadius] = useState(5);
  const [recipeOpen, setRecipeOpen] = useState<number | null>(null);
  const [delRecipe, setDelRecipe] = useState<number | null>(null);
  const [addOpen, setAddOpen] = useState(false);

  // живой опрос состояния
  useEffect(() => {
    const t = setInterval(() => setTick((n) => n + 1), 400);
    return () => clearInterval(t);
  }, []);

  const pawns = game.pawns;
  const alive = pawns.filter((p) => !p.dead);
  const dead = pawns.filter((p) => p.dead);
  const pawn = pawnSel !== null ? pawns.find((p) => p.id === pawnSel) ?? null : null;

  const desigCount = countDesig(game);

  return (
    <div className="fixed inset-0 z-[60] flex flex-col bg-[#151a12] text-[#e8e6df]" style={{ touchAction: 'pan-y' }}>
      {/* Шапка */}
      <div className="flex shrink-0 items-center justify-between border-b border-black/50 bg-[#1c2218] px-3 py-2">
        <div>
          <div className="text-[13px] font-bold tracking-wider text-[#d9b13f]">🛠️ АДМИН-ПАНЕЛЬ</div>
          <div className="text-[10px] text-[#7a8070]">
            День {game.clock.day}, {game.clock.hhmm} · {game.clock.seasonName} · игра на паузе
          </div>
        </div>
        <button onClick={onClose} className="h-9 w-9 rounded bg-[#d9b13f] text-[15px] font-bold text-black" aria-label="Закрыть">
          ✕
        </button>
      </div>

      {/* Вкладки */}
      <div className="flex shrink-0 border-b border-black/50 bg-[#1c2218]">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => {
              setTab(t.id);
              setPawnSel(null);
              setRecipeOpen(null);
              setDelRecipe(null);
            }}
            className={`flex flex-1 flex-col items-center gap-0.5 py-1.5 text-[9px] ${
              tab === t.id ? 'border-b-2 border-[#d9b13f] text-[#d9b13f]' : 'text-[#8a8f7e]'
            }`}
          >
            <span className="text-[15px]">{t.icon}</span>
            {t.name}
          </button>
        ))}
      </div>

      {/* Содержимое */}
      <div className="min-h-0 flex-1 overflow-y-auto p-2.5">
        {tab === 'colony' && (
          <ColonyTab game={game} api={api} logText={logText} setLogText={setLogText} />
        )}
        {tab === 'pawns' && (
          <PawnsTab
            game={game}
            api={api}
            alive={alive}
            dead={dead}
            pawn={pawn}
            pawnSel={pawnSel}
            setPawnSel={setPawnSel}
            killConfirm={killConfirm}
            setKillConfirm={setKillConfirm}
          />
        )}
        {tab === 'animals' && <AnimalsTab game={game} api={api} />}
        {tab === 'world' && <WorldTab game={game} api={api} tfRadius={tfRadius} setTfRadius={setTfRadius} desigCount={desigCount} />}
        {tab === 'recipes' && (
          <RecipesTab
            api={api}
            recipeOpen={recipeOpen}
            setRecipeOpen={setRecipeOpen}
            delRecipe={delRecipe}
            setDelRecipe={setDelRecipe}
            addOpen={addOpen}
            setAddOpen={setAddOpen}
          />
        )}
      </div>
    </div>
  );
}

// количество клеток с метками приказов (рубка/копать/собрать)
function countDesig(g: Game): number {
  let n = 0;
  for (let i = 0; i < g.desig.chop.length; i++) {
    if (g.desig.chop[i] || g.desig.mine[i] || g.desig.harvest[i]) n++;
  }
  return n;
}

// ================= Вкладка «Колония» =================

function ColonyTab({ game, api, logText, setLogText }: { game: Game; api: AdminAPI; logText: string; setLogText: (s: string) => void }) {
  const [confirmGo, setConfirmGo] = useState(false);
  return (
    <div className="space-y-2.5">
      <Section title="Ресурсы (в мире)">
        {RES_LIST.map((r) => (
          <Stepper
            key={r.res}
            label={`${RES_INFO[r.res].icon} ${r.name}`}
            value={game.world.countRes(r.res)}
            min={0}
            max={5000}
            onSet={(v) => api.setRes(r.res, v)}
          />
        ))}
        <div className="text-[10px] text-[#7a8070]">Изменение появляется у склада и переносится колонистами как обычные предметы.</div>
      </Section>

      <Section title="Время">
        <div className="flex flex-wrap gap-1.5">
          <Btn onClick={() => api.addTime(60)}>+1 ч</Btn>
          <Btn onClick={() => api.addTime(360)}>+6 ч</Btn>
          <Btn onClick={() => api.addTime(720)}>+12 ч</Btn>
          <Btn onClick={() => api.addTime(1440)}>+1 день</Btn>
        </div>
        <Field
          label="Точно"
          width="w-28"
          initial={`${game.clock.day} ${String(game.clock.hour).padStart(2, '0')}:${String(game.clock.minute).padStart(2, '0')}`}
          onCommit={(v) => {
            const m = v.trim().match(/^(\d+)\s+(\d{1,2}):(\d{1,2})$/);
            if (m) api.setTime(Number(m[1]), Number(m[2]), Number(m[3]));
          }}
        />
        <div className="text-[10px] text-[#7a8070]">Формат: день ЧЧ:ММ, например «3 14:30». Сейчас: День {game.clock.day}, {game.clock.hhmm}.</div>
      </Section>

      <Section title={`Сезон (сейчас: ${game.clock.seasonIcon} ${game.clock.seasonName})`}>
        <div className="flex flex-wrap gap-1.5">
          {['☀️ Лето', '🍂 Осень', '❄️ Зима', '🌷 Весна'].map((s, i) => (
            <Btn key={s} onClick={() => api.setSeason(i as 0 | 1 | 2 | 3)} tone={game.clock.seasonIdx === i ? 'gold' : 'normal'}>
              {s}
            </Btn>
          ))}
        </div>
      </Section>

      <Section title="Погода">
        <div className="flex flex-wrap gap-1.5">
          <Btn tone={game.weather.rain ? 'gold' : 'normal'} onClick={() => api.setWeather(!game.weather.rain, game.weather.blizzard)}>
            🌧️ Дождь {game.weather.rain ? 'вкл' : 'выкл'}
          </Btn>
          <Btn tone={game.weather.blizzard ? 'gold' : 'normal'} onClick={() => api.setWeather(game.weather.rain, !game.weather.blizzard)}>
            🌨️ Буран {game.weather.blizzard ? 'вкл' : 'выкл'}
          </Btn>
        </div>
      </Section>

      <Section title="События и действия">
        <div className="flex flex-wrap gap-1.5">
          <Btn onClick={() => api.forceCaravan()}>🧭 Караван</Btn>
          <Btn onClick={() => api.callWolves(2)}>🐺 Стая волков</Btn>
          <Btn onClick={() => api.addWanderer()}>🚶 Странник</Btn>
          <Btn onClick={() => api.makeSick()}>🤒 Болезнь</Btn>
          <Btn onClick={() => api.healAll()}>❤️ Исцелить всех</Btn>
          <Btn onClick={() => api.feedAll()}>🍖 Накормить всех</Btn>
          <Btn onClick={() => api.killAllWolves()}>🗡️ Убить волков</Btn>
          {game.alarmMin > 0 && <Btn tone="danger" onClick={() => api.resetAlarm()}>⚠️ Сбросить тревогу</Btn>}
          {game.gameOver && <Btn tone="danger" onClick={() => api.resetGameOver()}>♻️ Отменить Game Over</Btn>}
        </div>
      </Section>

      <Section title="Журнал: своя запись">
        <div className="flex gap-1.5">
          <input
            value={logText}
            onChange={(e) => setLogText(e.target.value)}
            placeholder="Текст в хронику колонии..."
            className="min-w-0 flex-1 rounded bg-black/40 px-2 py-2 text-[12px] outline-none ring-1 ring-[#2c3526] focus:ring-[#d9b13f]"
          />
          <Btn
            tone="gold"
            onClick={() => {
              api.writeLog(logText);
              setLogText('');
            }}
          >
            Записать
          </Btn>
        </div>
      </Section>
    </div>
  );
}

// ================= Вкладка «Пешки» =================

function PawnsTab({
  game,
  api,
  alive,
  dead,
  pawn,
  pawnSel,
  setPawnSel,
  killConfirm,
  setKillConfirm,
}: {
  game: Game;
  api: AdminAPI;
  alive: Game['pawns'];
  dead: Game['pawns'];
  pawn: Game['pawns'][number] | null;
  pawnSel: number | null;
  setPawnSel: (id: number | null) => void;
  killConfirm: number | null;
  setKillConfirm: (id: number | null) => void;
}) {
  if (pawn) {
    const mood = moodList(game, pawn).reduce((s, m) => s + m.delta, 50);
    const mods = moodList(game, pawn); // факторы настроения сейчас (label/delta, без id)
    const effects = pawn.mods; // реальные эффекты с id — их можно снять
    return (
      <div className="space-y-2.5">
        <div className="flex items-center gap-2">
          <button onClick={() => setPawnSel(null)} className="h-8 rounded bg-black/40 px-3 text-[12px]">
            ← Все
          </button>
          <span className="text-[14px] font-bold" style={{ color: pawn.color }}>
            {pawn.name}
          </span>
          {pawn.dead && <span className="text-[11px] text-red-300">🪦 погиб(ла)</span>}
        </div>

        {!pawn.dead && (
          <>
            <Section title="Состояние">
              <Slider label="❤️ Здоровье" value={pawn.hp} color="#c96f7e" onSet={(v) => api.setNeed(pawn.id, 'hp', v)} />
              <Slider label="🍖 Сытость" value={pawn.food} color="#b08f55" onSet={(v) => api.setNeed(pawn.id, 'food', v)} />
              <Slider label="😴 Бодрость" value={pawn.rest} color="#7fb2c9" onSet={(v) => api.setNeed(pawn.id, 'rest', v)} />
              <div className="text-[10px] text-[#7a8070]">Настроение: {Math.round(mood)} · состояние: {pawn.state}</div>
            </Section>

            <Section title="Навыки (0–20)">
              {SKILLS.map((s) => (
                <Stepper
                  key={s.id}
                  label={s.name}
                  value={pawn.skills[s.id as SkillId].lvl}
                  min={0}
                  max={20}
                  onSet={(v) => api.setSkill(pawn.id, s.id as SkillId, v)}
                />
              ))}
            </Section>

            <Section title="Снаряжение">
              <Sel
                label="⚔️ Оружие"
                value={pawn.weapon ?? 'none'}
                options={[
                  { v: 'none', label: '— нет —' },
                  { v: 'spear', label: `🔱 Копьё · урон ${WEAPON_STATS.spear.min}–${WEAPON_STATS.spear.max}` },
                  { v: 'bow', label: `🏹 Лук · ${WEAPON_STATS.bow.min}–${WEAPON_STATS.bow.max}, дальний` },
                  { v: 'sword', label: `⚔️ Меч · урон ${WEAPON_STATS.sword.min}–${WEAPON_STATS.sword.max}` },
                ]}
                onChange={(v) => api.setWeapon(pawn.id, v as WeaponKind | 'none')}
              />
              <Sel
                label="🧥 Куртка"
                value={pawn.cloth ?? 'none'}
                options={[
                  { v: 'none', label: '— нет —' },
                  { v: 'coat', label: '🧥 Тёплая куртка · зимнее тепло' },
                ]}
                onChange={(v) => api.setCloth(pawn.id, v as 'coat' | 'none')}
              />
              <Sel
                label="🛡️ Броня"
                value={pawn.armor ?? 'none'}
                options={[
                  { v: 'none', label: '— нет —' },
                  { v: 'leather', label: '🦺 Кожаная · −30% урона' },
                  { v: 'iron', label: '🛡️ Железная · −55% урона' },
                ]}
                onChange={(v) => api.setArmor(pawn.id, v as ArmorKind | 'none')}
              />
            </Section>

            <Section title="Черты характера">
              <div className="flex flex-wrap gap-1.5">
                {TRAITS.map((t) => {
                  const on = pawn.traits.includes(t.id);
                  return (
                    <button
                      key={t.id}
                      title={t.desc}
                      onClick={() =>
                        api.setPawnTraits(pawn.id, on ? pawn.traits.filter((x) => x !== t.id) : [...pawn.traits, t.id])
                      }
                      className={`rounded-full px-2.5 py-1 text-[11px] ${on ? 'bg-[#d9b13f] text-black' : 'bg-black/40 text-[#a8ad9a]'}`}
                    >
                      {t.name}
                    </button>
                  );
                })}
              </div>
            </Section>

            <Section title="Данные">
              <Field label="Имя" initial={pawn.name} onCommit={(v) => api.setPawnName(pawn.id, v)} />
              <Sel
                label="Пол"
                value={pawn.gender}
                options={[
                  { v: 'м', label: 'мужской' },
                  { v: 'ж', label: 'женский' },
                ]}
                onChange={(v) => api.setPawnGender(pawn.id, v as 'м' | 'ж')}
              />
              <Field label="Возраст" type="number" initial={pawn.age} onCommit={(v) => api.setPawnAge(pawn.id, Number(v))} />
            </Section>

            {mods.length > 0 && (
              <Section title="Настроение: факторы сейчас" note="Крестиком снимаются только постоянные эффекты (травмы, память о событиях); текущие условия уходят сами.">
                {mods.map((m, i) => {
                  const removable = effects.find((e) => e.label === m.label);
                  return (
                    <div key={`${m.label}:${i}`} className="flex items-center justify-between text-[11px]">
                      <span className={m.delta >= 0 ? 'text-green-300' : 'text-red-300'}>
                        {m.delta >= 0 ? '+' : ''}
                        {m.delta} {m.label}
                      </span>
                      {removable && (
                        <button onClick={() => pawn.removeMod(removable.id)} className="text-[#8a8f7e]" aria-label="Убрать">
                          ✕
                        </button>
                      )}
                    </div>
                  );
                })}
              </Section>
            )}

            <Section title="Действия">
              <div className="flex flex-wrap gap-1.5">
                <Btn onClick={() => api.pawnAction(pawn.id, 'heal')}>❤️ Исцелить</Btn>
                <Btn onClick={() => api.pawnAction(pawn.id, 'wake')}>⏰ Разбудить</Btn>
                <Btn onClick={() => api.pawnAction(pawn.id, 'base')}>🏠 К складу</Btn>
                <Btn onClick={() => api.pawnAction(pawn.id, 'clearJob')}>🚫 Сбросить задачу</Btn>
                {killConfirm === pawn.id ? (
                  <Btn tone="danger" onClick={() => { api.killPawn(pawn.id); setKillConfirm(null); setPawnSel(null); }}>
                    ☠️ Точно убить?
                  </Btn>
                ) : (
                  <Btn tone="ghost" onClick={() => setKillConfirm(pawn.id)}>☠️ Убить</Btn>
                )}
              </div>
            </Section>
          </>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-2.5">
      <Section title={`Колонисты (${alive.length})`}>
        {alive.map((p) => (
          <button
            key={p.id}
            onClick={() => setPawnSel(p.id)}
            className="flex w-full items-center justify-between rounded bg-black/25 px-2.5 py-2 text-left active:bg-black/45"
          >
            <span className="text-[12px] font-semibold" style={{ color: p.color }}>
              {p.name}
            </span>
            <span className="text-[10px] text-[#8a8f7e]">
              ❤{Math.round(p.hp)} 🍖{Math.round(p.food)} 😴{Math.round(p.rest)}
            </span>
          </button>
        ))}
        <Btn tone="gold" onClick={() => { const p = api.addPawn(); if (p) setPawnSel(p.id); }} className="w-full">
          + Новая пешка
        </Btn>
      </Section>

      {dead.length > 0 && (
        <Section title={`Погибшие (${dead.length})`} note="«Убрать» — удалить пешку из колонии совсем (история останется в журнале).">
          {dead.map((p) => (
            <div key={p.id} className="flex items-center justify-between rounded bg-black/25 px-2.5 py-2">
              <span className="text-[12px] text-[#8a8f7e]">🪦 {p.name}</span>
              <div className="flex gap-1.5">
                <Btn onClick={() => { api.revivePawn(p.id); setPawnSel(p.id); }}>♻️ Оживить</Btn>
                <Btn tone="danger" onClick={() => api.purgePawn(p.id)}>Убрать</Btn>
              </div>
            </div>
          ))}
        </Section>
      )}
    </div>
  );
}

// ================= Вкладка «Звери» =================

function AnimalsTab({ game, api }: { game: Game; api: AdminAPI }) {
  const animals = game.animals;
  return (
    <div className="space-y-2.5">
      <Section title="Появление зверей у лагеря">
        <div className="flex flex-wrap gap-1.5">
          {(['wolf', 'deer', 'rabbit', 'boar', 'bear', 'trader'] as const).map((k) => (
            <Btn key={k} onClick={() => api.spawnAnimal(k)}>
              {A_ICON[k]} {{ wolf: 'Волк', deer: 'Олень', rabbit: 'Кролик', boar: 'Кабан', bear: 'Медведь', trader: 'Торговец' }[k]}
            </Btn>
          ))}
        </div>
      </Section>

      <Section title={`На карте: ${animals.length}`}>
        {animals.length === 0 && <div className="text-[11px] text-[#7a8070]">Пусто — ни одного зверя.</div>}
        {animals.map((a) => {
          const marked = game.huntList.has(a.id);
          return (
            <div key={a.id} className="rounded bg-black/25 px-2.5 py-2">
              <div className="flex items-center justify-between">
                <span className="text-[12px]">
                  {A_ICON[a.kind] ?? '🐾'} {a.name}{' '}
                  <span className="text-[10px] text-[#8a8f7e]">
                    ❤{Math.round(a.hp)}/{a.maxHp} · {A_STATE[a.state] ?? a.state} · {Math.round(a.x)}:{Math.round(a.y)}
                  </span>
                </span>
                <div className="flex gap-1.5">
                  <Btn tone="danger" onClick={() => api.killAnimal(a.id)}>☠️</Btn>
                  <Btn tone="ghost" onClick={() => api.despawnAnimal(a.id)}>✕</Btn>
                </div>
              </div>
              {marked && (
                <div className="mt-1 flex items-center justify-between text-[10px] text-[#d9b13f]">
                  🎯 помечен для охоты
                  <button onClick={() => game.huntList.delete(a.id)} className="text-[#8a8f7e]">
                    снять метку
                  </button>
                </div>
              )}
            </div>
          );
        })}
        {animals.some((a) => game.huntList.has(a.id)) && (
          <Btn tone="ghost" onClick={() => api.clearHuntMarks()} className="w-full">
            Снять все охотничьи метки
          </Btn>
        )}
      </Section>
    </div>
  );
}

// ================= Вкладка «Мир» =================

function WorldTab({ game, api, tfRadius, setTfRadius, desigCount }: {
  game: Game;
  api: AdminAPI;
  tfRadius: number;
  setTfRadius: (n: number) => void;
  desigCount: number;
}) {
  const blueprints = game.world.buildings.filter((b) => b.blueprint);
  const damaged = game.world.buildings.filter((b) => !b.blueprint && b.hp < b.maxHp);
  const [spawnB, setSpawnB] = useState(false);
  return (
    <div className="space-y-2.5">
      <Section
        title="Терраформ вокруг склада"
        note="Зоны, постройки и клетки с пешками не затрагиваются. Скалы и озеро непроходимы — не запирайте колонистов."
      >
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-[#a8ad9a]">Радиус:</span>
          {[3, 5, 8, 12].map((r) => (
            <button
              key={r}
              onClick={() => setTfRadius(r)}
              className={`h-8 w-10 rounded text-[12px] ${tfRadius === r ? 'bg-[#d9b13f] text-black font-semibold' : 'bg-black/40'}`}
            >
              {r}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-1.5">
          <Btn onClick={() => api.terraform('forest', tfRadius)}>🌳 Лес</Btn>
          <Btn onClick={() => api.terraform('berries', tfRadius)}>🌿 Ягоды</Btn>
          <Btn onClick={() => api.terraform('vein', tfRadius)}>🔩 Рудная жила</Btn>
          <Btn onClick={() => api.terraform('rock', tfRadius)}>🗿 Скалы</Btn>
          <Btn onClick={() => api.terraform('water', tfRadius)}>💧 Озеро</Btn>
          <Btn tone="ghost" onClick={() => api.terraform('clear', tfRadius)}>🧹 Расчистить</Btn>
        </div>
      </Section>

      <Section title="Постройки">
        <div className="flex flex-wrap gap-1.5">
          <Btn onClick={() => api.completeAllBlueprints()}>🔨 Достроить чертежи ({blueprints.length})</Btn>
          <Btn onClick={() => api.repairAll()}>🛠️ Починить всё ({damaged.length})</Btn>
          {blueprints.length > 0 && <Btn tone="danger" onClick={() => api.destroyBlueprints()}>🗑 Снести чертежи</Btn>}
          <Btn tone="gold" onClick={() => setSpawnB(!spawnB)}>
            + Построить здание
          </Btn>
        </div>
        {spawnB && (
          <div className="grid grid-cols-4 gap-1.5">
            {(Object.keys(B_TYPE_LIST) as string[]).map((t) => (
              <button
                key={t}
                onClick={() => api.grantBuilding(Number(t) as BType)}
                className="flex flex-col items-center gap-0.5 rounded bg-black/30 py-1.5 text-[9px] text-[#c8cbb8] active:bg-[#31402c]"
              >
                <span className="text-[15px]">{B_ICON[t]}</span>
                {B_TYPE_LIST[t]}
              </button>
            ))}
          </div>
        )}
      </Section>

      <Section title="Приказы и метки">
        <div className="flex flex-wrap gap-1.5">
          <Btn tone={desigCount > 0 ? 'normal' : 'ghost'} onClick={() => api.clearDesig()}>
            🧹 Снять метки приказов ({desigCount})
          </Btn>
          <Btn tone="ghost" onClick={() => api.clearHuntMarks()}>🎯 Снять метки охоты ({game.huntList.size})</Btn>
        </div>
      </Section>

      <Section title="Мир" note="Справка: карта 64×64 клетки. Терраформ меняет тайлы так же, как генератор мира.">
        <div className="grid grid-cols-2 gap-x-3 text-[10px] text-[#7a8070]">
          <span>Тайлов всего: {MAP * MAP}</span>
          <span>Деревьев: {countObj(game, Obj.Tree)}</span>
          <span>Валунов: {countObj(game, Obj.Rock)}</span>
          <span>Жил железа: {countObj(game, Obj.Ore)}</span>
          <span>Серебра: {countObj(game, Obj.SilverOre)}</span>
          <span>Скалы: {countTerrain(game, Terrain.Rock)}</span>
          <span>Вода: {countTerrain(game, Terrain.Water)}</span>
          <span>Предметов: {game.world.items.length}</span>
        </div>
      </Section>
    </div>
  );
}

const B_TYPE_LIST: Record<number, string> = {
  [BType.Wall]: 'Стена', [BType.Door]: 'Дверь', [BType.Bed]: 'Кровать', [BType.Campfire]: 'Костёр',
  [BType.Workbench]: 'Верстак', [BType.Table]: 'Стол', [BType.Chair]: 'Стул', [BType.Torch]: 'Факел',
  [BType.StoneWall]: 'Кам. стена', [BType.Grave]: 'Могила', [BType.Mine]: 'Шахта', [BType.Trap]: 'Колья',
  [BType.Turret]: 'Башня',
};

function countObj(g: Game, o: Obj): number {
  let n = 0;
  for (let i = 0; i < g.world.obj.length; i++) if (g.world.obj[i] === o) n++;
  return n;
}
function countTerrain(g: Game, t: Terrain): number {
  let n = 0;
  for (let i = 0; i < g.world.terrain.length; i++) if (g.world.terrain[i] === t) n++;
  return n;
}

// ================= Вкладка «Рецепты» =================

function costStr(r: RecipeDef): string {
  const parts: string[] = [];
  if (r.wood > 0) parts.push(`🪵${r.wood}`);
  if (r.iron > 0) parts.push(`🔩${r.iron}`);
  if (r.hide > 0) parts.push(`🟤${r.hide}`);
  return parts.length > 0 ? parts.join(' ') : '🪵0';
}

function RecipesTab({
  api,
  recipeOpen,
  setRecipeOpen,
  delRecipe,
  setDelRecipe,
  addOpen,
  setAddOpen,
}: {
  api: AdminAPI;
  recipeOpen: number | null;
  setRecipeOpen: (i: number | null) => void;
  delRecipe: number | null;
  setDelRecipe: (i: number | null) => void;
  addOpen: boolean;
  setAddOpen: (b: boolean) => void;
}) {
  return (
    <div className="space-y-2.5">
      <Section
        title={`Каталог верстака (${RECIPES.length})`}
        note="Правки применяются сразу и сохраняются в сейв. Заказы на верстаках ссылаются на рецепты по номеру — при удалении они переиндексируются автоматически."
      >
        {RECIPES.map((r, idx) => (
          <div key={r.id} className="rounded bg-black/25">
            <button onClick={() => { setRecipeOpen(recipeOpen === idx ? null : idx); setDelRecipe(null); }} className="flex w-full items-center justify-between px-2.5 py-2 text-left">
              <span className="text-[12px]">
                {RES_INFO[r.res].icon} <b>{r.name}</b>
              </span>
              <span className="text-[10px] text-[#8a8f7e]">
                {costStr(r)} · ⏱{r.work}
              </span>
            </button>
            {recipeOpen === idx && (
              <div className="space-y-2 border-t border-[#2c3526] px-2.5 py-2">
                {ITEM_STATS[r.res] && (
                  <div className="rounded bg-[#3a3426] px-2 py-1.5 text-[10px] text-[#e0c268]">{ITEM_STATS[r.res]}</div>
                )}
                <Field label="Название" initial={r.name} onCommit={(v) => api.updateRecipe(idx, { name: v })} />
                <Sel
                  label="Изделие"
                  value={r.res}
                  options={ALL_RES.map((rr) => ({ v: rr, label: `${RES_INFO[rr].icon} ${RES_INFO[rr].name}` }))}
                  onChange={(v) => api.updateRecipe(idx, { res: Number(v) })}
                />
                <Field label="Работа, мин" type="number" initial={r.work} onCommit={(v) => api.updateRecipe(idx, { work: Number(v) })} />
                <Field label="🪵 Дерево" type="number" initial={r.wood} onCommit={(v) => api.updateRecipe(idx, { wood: Number(v) })} />
                <Field label="🔩 Железо" type="number" initial={r.iron} onCommit={(v) => api.updateRecipe(idx, { iron: Number(v) })} />
                <Field label="🟤 Шкуры" type="number" initial={r.hide} onCommit={(v) => api.updateRecipe(idx, { hide: Number(v) })} />
                {delRecipe === idx ? (
                  <Btn tone="danger" onClick={() => { api.deleteRecipe(idx); setDelRecipe(null); setRecipeOpen(null); }}>
                    Удалить навсегда?
                  </Btn>
                ) : (
                  <Btn tone="ghost" onClick={() => setDelRecipe(idx)}>🗑 Удалить рецепт</Btn>
                )}
              </div>
            )}
          </div>
        ))}

        <Btn tone="gold" onClick={() => setAddOpen(!addOpen)} className="w-full">
          + Новый рецепт
        </Btn>
        {addOpen && <NewRecipeForm api={api} onDone={() => setAddOpen(false)} />}
      </Section>
    </div>
  );
}

function NewRecipeForm({ api, onDone }: { api: AdminAPI; onDone: () => void }) {
  const [res, setRes] = useState<Res>(Res.Spear);
  const [name, setName] = useState('');
  const [work, setWork] = useState(40);
  const [wood, setWood] = useState(4);
  const [iron, setIron] = useState(0);
  const [hide, setHide] = useState(0);
  return (
    <div className="space-y-2 rounded border border-[#d9b13f]/40 bg-black/30 p-2.5">
      <Field label="Название" initial="" onCommit={setName} />
      <Sel
        label="Изделие"
        value={res}
        options={ALL_RES.map((rr) => ({ v: rr, label: `${RES_INFO[rr].icon} ${RES_INFO[rr].name}` }))}
        onChange={(v) => setRes(Number(v))}
      />
      <div className="flex flex-wrap gap-x-4 gap-y-2">
        <Field label="Работа, мин" type="number" initial={work} onCommit={(v) => setWork(Number(v) || 40)} />
        <Field label="🪵 Дерево" type="number" initial={wood} onCommit={(v) => setWood(Number(v) || 0)} />
        <Field label="🔩 Железо" type="number" initial={iron} onCommit={(v) => setIron(Number(v) || 0)} />
        <Field label="🟤 Шкуры" type="number" initial={hide} onCommit={(v) => setHide(Number(v) || 0)} />
      </div>
      <Btn
        tone="gold"
        onClick={() => {
          api.addRecipe({ name: name || `${RES_INFO[res].name} (новый)`, res, work, wood, iron, hide });
          onDone();
        }}
      >
        Добавить на верстак
      </Btn>
    </div>
  );
}

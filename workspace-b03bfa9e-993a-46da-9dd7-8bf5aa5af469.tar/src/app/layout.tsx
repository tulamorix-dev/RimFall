import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ОСКОЛОК — карманная колония",
  description:
    "Мобильная браузерная survival/colony RPG: управьте группой выживших, добывайте ресурсы, стройте базу и создавайте историю своей колонии.",
  applicationName: "ОСКОЛОК",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "ОСКОЛОК",
  },
  icons: {
    icon: "/icons/icon-192.png",
    apple: "/icons/icon-192.png",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
  themeColor: "#12170f",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <body className="antialiased overscroll-none bg-[#12170f] text-[#e8e6df]">{children}</body>
    </html>
  );
}

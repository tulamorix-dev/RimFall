// ============================================================
// ОСКОЛОК — базовые определения и константы (MVP 0.1)
// ============================================================

export const MAP = 64; // размер карты в клетках (64x64)
export const TILE = 32; // размер клетки в игровых пикселях
export const MIN_PER_SEC = 3; // игровых минут за реальную секунду при скорости 1x

// --- Поверхности ---
export enum Terrain {
  Grass = 0,
  Dirt = 1,
  Water = 2,
  Stone = 3,
  Forest = 4,
  Rock = 5, // сплошная скала (как в RimWorld): непроходима, копается — вгрызаемся в гору
}

// --- Объекты на клетке ---
export enum Obj {
  None = 0,
  Tree = 1,
  Rock = 2,
  BerryBush = 3,
  RuinWall = 4,
  Ore = 5, // железная руда — жила с блеском
  SilverOre = 6, // серебряная жила — редкость, валюта караванов
}

// --- Типы ресурсов/предметов ---
export enum Res {
  Wood = 0,
  Stone = 1,
  Food = 2,
  Loot = 3,
  Corpse = 4,
  Meal = 5,
  Spear = 6,
  Bow = 7,
  Iron = 8, // железо (из руды)
  Sword = 9, // меч
  Hide = 10, // шкура — с добытых зверей
  Coat = 11, // тёплая куртка — шьётся из шкур
  LeatherArmor = 12, // кожаная броня
  IronArmor = 13, // железная броня
  Silver = 14, // серебро — валюта караванов
}

// --- Постройки (одноклеточные) ---
export enum BType {
  Wall = 0,
  Door = 1,
  Bed = 2,
  Campfire = 3,
  Workbench = 4,
  Table = 5, // стол — еда за ним радует
  Chair = 6, // стул — место у стола
  Torch = 7, // факел — свет ночью
  StoneWall = 8, // каменная стена — вдвое крепче деревянной
  Grave = 9, // могила — память о погибшем
  Mine = 10, // шахта — вход в подземные выработки (экспедиции с сюрпризами)
  Trap = 11, // колья — ловушка на зверей, ломается при срабатывании
  Turret = 12, // арбалетная башня — сама стреляет по врагам
}

// --- Зоны ---
export enum Zone {
  None = 0,
  Stockpile = 1,
  Farm = 2,
}

// --- Зоны с настройками (по мотивам RimWorld: имя, фильтры хранения) ---
export type ZoneKind = 'stockpile' | 'farm';

export interface ZoneDef {
  id: number;
  kind: ZoneKind;
  name: string;
  filters: boolean[]; // индекс = Res: принимать ли ресурс на склад (у фермы не используется)
}

// Ресурсы, которые игрок может включать/выключать в настройках склада
export const STOCKPILE_RES: Res[] = [Res.Wood, Res.Stone, Res.Food, Res.Loot, Res.Meal, Res.Iron, Res.Hide, Res.Coat, Res.LeatherArmor, Res.IronArmor, Res.Silver];
// Длина массива фильтров зоны (запас под новые ресурсы)
export const FILTER_LEN = 16;
export const ZONE_KIND_NAMES: Record<ZoneKind, string> = { stockpile: 'Склад', farm: 'Ферма' };
export const ZONE_KIND_ICONS: Record<ZoneKind, string> = { stockpile: '📦', farm: '🌱' };
export const MAX_ZONE_ID = 250; // предел номера зоны (zoneId хранится в Uint8Array)

export enum FarmStage {
  None = 0,
  Tilled = 1,
  Planted = 2,
  Ready = 3,
}

export interface BDef {
  name: string;
  hp: number;
  mat: Res;
  matNeed: number;
  work: number; // игровых минут на строительство
  passPawn: boolean;
  passAnimal: boolean;
  light: number; // радиус света ночью (0 — нет)
}

export const BUILDINGS: Record<BType, BDef> = {
  [BType.Wall]: { name: 'Стена', hp: 300, mat: Res.Wood, matNeed: 3, work: 40, passPawn: false, passAnimal: false, light: 0 },
  [BType.Door]: { name: 'Дверь', hp: 160, mat: Res.Wood, matNeed: 4, work: 45, passPawn: true, passAnimal: false, light: 0 },
  [BType.Bed]: { name: 'Кровать', hp: 80, mat: Res.Wood, matNeed: 6, work: 55, passPawn: true, passAnimal: true, light: 0 },
  [BType.Campfire]: { name: 'Костёр', hp: 60, mat: Res.Wood, matNeed: 3, work: 25, passPawn: false, passAnimal: false, light: 5.5 },
  [BType.Workbench]: { name: 'Верстак', hp: 140, mat: Res.Wood, matNeed: 8, work: 60, passPawn: false, passAnimal: false, light: 0 },
  [BType.Table]: { name: 'Стол', hp: 90, mat: Res.Wood, matNeed: 7, work: 50, passPawn: false, passAnimal: false, light: 0 },
  [BType.Chair]: { name: 'Стул', hp: 50, mat: Res.Wood, matNeed: 3, work: 25, passPawn: true, passAnimal: false, light: 0 },
  [BType.Torch]: { name: 'Факел', hp: 30, mat: Res.Wood, matNeed: 2, work: 12, passPawn: false, passAnimal: false, light: 2.8 },
  [BType.StoneWall]: { name: 'Каменная стена', hp: 650, mat: Res.Stone, matNeed: 4, work: 60, passPawn: false, passAnimal: false, light: 0 },
  [BType.Grave]: { name: 'Могила', hp: 140, mat: Res.Stone, matNeed: 2, work: 25, passPawn: true, passAnimal: true, light: 0 },
  [BType.Mine]: { name: 'Шахта', hp: 220, mat: Res.Wood, matNeed: 4, work: 55, passPawn: false, passAnimal: false, light: 0 },
  [BType.Trap]: { name: 'Колья', hp: 50, mat: Res.Wood, matNeed: 4, work: 25, passPawn: true, passAnimal: true, light: 0 },
  [BType.Turret]: { name: 'Арбалетная башня', hp: 320, mat: Res.Iron, matNeed: 5, work: 90, passPawn: false, passAnimal: false, light: 0 },
};

export const RES_INFO: Record<Res, { name: string; icon: string; stack: number }> = {
  [Res.Wood]: { name: 'Дерево', icon: '🪵', stack: 30 },
  [Res.Stone]: { name: 'Камень', icon: '🪨', stack: 30 },
  [Res.Food]: { name: 'Еда', icon: '🍖', stack: 30 },
  [Res.Loot]: { name: 'Находка', icon: '🎒', stack: 1 },
  [Res.Corpse]: { name: 'Тело', icon: '⚰️', stack: 1 },
  [Res.Meal]: { name: 'Похлёбка', icon: '🍲', stack: 30 },
  [Res.Spear]: { name: 'Копьё', icon: '🔱', stack: 1 },
  [Res.Bow]: { name: 'Лук', icon: '🏹', stack: 1 },
  [Res.Iron]: { name: 'Железо', icon: '🔩', stack: 30 },
  [Res.Sword]: { name: 'Меч', icon: '⚔️', stack: 1 },
  [Res.Hide]: { name: 'Шкура', icon: '🟤', stack: 30 },
  [Res.Coat]: { name: 'Тёплая куртка', icon: '🧥', stack: 1 },
  [Res.LeatherArmor]: { name: 'Кожаная броня', icon: '🦺', stack: 1 },
  [Res.IronArmor]: { name: 'Железная броня', icon: '🛡️', stack: 1 },
  [Res.Silver]: { name: 'Серебро', icon: '🪙', stack: 30 },
};

// --- Черты характера ---
export interface TraitDef {
  id: string;
  name: string;
  desc: string;
}

export const TRAITS: TraitDef[] = [
  { id: 'hardworker', name: 'Трудяга', desc: 'Работает на 15% быстрее' },
  { id: 'sleeper', name: 'Соня', desc: 'Дольше бодрствует, лучше высыпается' },
  { id: 'fidget', name: 'Непоседа', desc: 'Быстро ходит, но хуже отдыхает во сне' },
  { id: 'greedy', name: 'Жадный', desc: 'Сильнее страдает от голода' },
  { id: 'brave', name: 'Смелый', desc: 'Сам бросается на врагов' },
  { id: 'coward', name: 'Трусливый', desc: 'Убегает при виде опасности' },
  { id: 'loner', name: 'Одиночка', desc: 'Мало нуждается в общении' },
];

// --- Навыки ---
export const SKILLS = [
  { id: 'build', name: 'Строительство' },
  { id: 'mine', name: 'Добыча' },
  { id: 'lumber', name: 'Лесоруб' },
  { id: 'farm', name: 'Фермерство' },
  { id: 'cook', name: 'Кулинария' },
  { id: 'medicine', name: 'Медицина' },
  { id: 'melee', name: 'Бой' },
  { id: 'ranged', name: 'Стрельба' },
] as const;

export type SkillId = (typeof SKILLS)[number]['id'];
export const SKILL_NAMES: Record<string, string> = Object.fromEntries(SKILLS.map((s) => [s.id, s.name]));

// --- Категории работ (приоритеты игрока) ---
export type WorkCat = 'build' | 'farm' | 'lumber' | 'mine' | 'haul' | 'cook' | 'hunt';

export const WORK_CATS: { id: WorkCat; name: string }[] = [
  { id: 'build', name: 'Строительство' },
  { id: 'farm', name: 'Фермерство' },
  { id: 'lumber', name: 'Рубка' },
  { id: 'mine', name: 'Добыча' },
  { id: 'cook', name: 'Готовка' },
  { id: 'hunt', name: 'Охота' },
  { id: 'haul', name: 'Переноска' },
];

// --- Охота ---
// Быстрая дичь (олень, кролик) убегает от пешки — добывается только луком.
// Опасная дичь (кабан, волк, медведь) может постоять за себя: без оружия
// охотник только зря рискнёт шкурой.
export type PreyKind = 'deer' | 'rabbit' | 'boar' | 'wolf' | 'bear';
export const HUNT_BOW_ONLY: readonly string[] = ['deer', 'rabbit'];
export const HUNT_DANGEROUS: readonly string[] = ['boar', 'wolf', 'bear'];
export const HUNT_MARKER = '#d9b13f'; // цвет метки «помечен для охоты»

// --- Баланс ---
export const WALK = 0.9; // клеток за игровую минуту
export const CARRY_CAP = 20;
export const EAT_QTY = 8;
export const EAT_SATIETY = 45;
export const HUNGER_RATE = 100 / 2880; // сытость 100 -> 0 за ~2 игровых дня
export const REST_RATE = 100 / 1080; // бодрость 100 -> 0 за ~18 часов
export const SLEEP_RATE = 100 / 390; // восстановление во сне за ~6.5 часов
export const WORK_TIME = { chop: 45, mine: 55, dig: 80, harvest: 12, till: 15, plant: 10, crop: 15, loot: 20, clear: 20, bury: 30, doctor: 40, cook: 50 };

// --- Готовка ---
export const MEAL_RAW = 4; // сырой еды на одну варку (порций похлёбки получится столько же)
export const MEAL_EAT_QTY = 4; // столько похлёбки съедается за раз
export const MEAL_SATIETY = 65; // сытость от похлёбки (сырая еда даёт 45 за 8 шт)
export const MEAL_TARGET = 8; // запас похлёбки, к которому колонисты стремятся
export const MIN_FOOD_TO_COOK = 8; // не варим, если сырой еды меньше (запас на чёрный день)

// --- Одежда и броня ---
export type ArmorKind = 'leather' | 'iron';
export const ARMOR_NAMES: Record<ArmorKind, string> = { leather: 'Кожаная броня', iron: 'Железная броня' };
export const ARMOR_ICONS: Record<ArmorKind, string> = { leather: '🦺', iron: '🛡️' };
export const LEATHER_ARMOR_MULT = 0.7; // кожа гасит 30% урона зверей
export const IRON_ARMOR_MULT = 0.45; // железо гасит 55% урона
export const COAT_WARM_MOOD = 3; // настроение «Тёплая куртка» зимой

// --- Оружие ---
export const SPEAR_DMG_BONUS = 4; // бонус урона копья в ближнем бою
export const BOW_RANGE = 4; // дальность стрельбы (клетки, расстояние Чебышёва)
export const SWORD_DMG = 7; // база урона меча
export const SWORD_DMG_RAND = 5; // разброс урона меча
export const SWORD_ATK_CD = 0.85; // меч бьёт чаще копья
export type WeaponKind = 'spear' | 'bow' | 'sword';
export const WEAPON_NAMES: Record<WeaponKind, string> = { spear: 'Копьё', bow: 'Лук', sword: 'Меч' };
export const WEAPON_ICONS: Record<WeaponKind, string> = { spear: '🔱', bow: '🏹', sword: '⚔️' };
// Какой предмет соответствует оружию (падает на землю при смерти владельца)
export const WEAPON_RES: Record<WeaponKind, Res> = { spear: Res.Spear, bow: Res.Bow, sword: Res.Sword };

// --- Статы оружия/брони (видны игроку в карточке пешки, верстаке, торговле) ---
// Цифры строго повторяют формулы удара в pawnAI.strikeAnimal и защиту в game.damagePawn
export interface WeaponStat {
  min: number; // урон без учёта навыка (мин)
  max: number; // урон без учёта навыка (макс)
  cd: number; // секунд между ударами
  range: number; // дальность в клетках (1 — ближний бой)
}
export const WEAPON_STATS: Record<WeaponKind | 'fists', WeaponStat> = {
  fists: { min: 2, max: 4, cd: 1.2, range: 1 },
  spear: { min: 4 + SPEAR_DMG_BONUS, max: 8 + SPEAR_DMG_BONUS, cd: 1.0, range: 1 },
  sword: { min: SWORD_DMG, max: SWORD_DMG + SWORD_DMG_RAND, cd: SWORD_ATK_CD, range: 1 },
  bow: { min: 3, max: 6, cd: 1.2, range: BOW_RANGE },
};
// Человекочитаемая строка урона: «Урон 8–12 · ближний бой» / «Урон 3–6 · бьёт на 4 клетки»
export function weaponStatLine(k: WeaponKind | 'fists'): string {
  const s = WEAPON_STATS[k];
  const place = s.range > 1 ? `бьёт на ${s.range} клетки` : 'ближний бой';
  const fast = k === 'sword' ? ' · бьёт чаще копья' : '';
  const skill = k === 'bow' ? ' · Стрельба усиливает' : k === 'fists' ? '' : ' · Бой усиливает';
  return `Урон ${s.min}–${s.max} · ${place}${fast}${skill}`;
}
// Защита: сколько процентов урона зверей гасит броня (см. damagePawn)
export const ARMOR_BLOCK_PCT: Record<ArmorKind, number> = {
  leather: Math.round((1 - LEATHER_ARMOR_MULT) * 100),
  iron: Math.round((1 - IRON_ARMOR_MULT) * 100),
};
export function armorStatLine(k: ArmorKind): string {
  return `гасит ${ARMOR_BLOCK_PCT[k]}% урона зверей`;
}
// Строка статов для ЛЮБОГО предмета (тап по предмету на земле, верстак, торговля)
export const ITEM_STATS: Partial<Record<Res, string>> = {
  [Res.Spear]: weaponStatLine('spear'),
  [Res.Bow]: weaponStatLine('bow'),
  [Res.Sword]: weaponStatLine('sword'),
  [Res.Coat]: 'Греет зимой · настроение +3 в мороз',
  [Res.LeatherArmor]: `Защита: ${armorStatLine('leather')}`,
  [Res.IronArmor]: `Защита: ${armorStatLine('iron')}`,
  [Res.Meal]: 'Сытость +65 за порцию',
  [Res.Food]: 'Сытость +45 за 8 шт · сварите похлёбку — сытнее',
};

// --- Сезоны года (4 сезона по 6 дней, год = 24 дня) ---
export const SEASON_DAYS = 6;
export const SEASONS = [
  { name: 'Лето', icon: '☀️' },
  { name: 'Осень', icon: '🍂' },
  { name: 'Зима', icon: '❄️' },
  { name: 'Весна', icon: '🌷' },
] as const;

// --- Холод и зима ---
export const FIRE_WARM_R = 3.2; // радиус тепла от костра (клетки)
export const COLD_MOOD = -9; // настроение «Мёрзнет» на зимнем морозе
export const COLD_HP_RATE = 0.015; // потеря HP в минуту без укрытия на морозе
export const AUTUMN_MOOD = -3; // осенняя промозглость ночью под открытым небом
export const WALK_WINTER = 0.85; // снег замедляет пешек
export const WALK_BLIZZARD = 0.7; // буран замедляет сильнее
export const BLIZZ_CHANCE = 0.3; // шанс бурана на каждый зимний день
export const WOLF_WINTER_MULT = 1.5; // зимой волки голоднее — шансы выше

// --- Шахта: экспедиции в подземелье (отдельная локация с сюрпризами) ---
export const EXP_TOTAL = 540; // полная выработка: игровых минут под землёй
// доли пути, в которых случаются происшествия (сюрпризы шахты)
export const EXP_CHECKPOINTS = [0.28, 0.58, 0.86];

// --- Защитные сооружения ---
export const TRAP_DMG = 22; // урон кольев зверю
export const TRAP_RAND = 12;
export const TURRET_RANGE = 5; // дальность башни (клетки, Чебышёв)
export const TURRET_CD = 2.6; // игровых минут между болтами
export const TURRET_DMG = 10;
export const TURRET_RAND = 6;

// --- Караваны и серебро ---
export const SILVER_START = 8; // серебро у основателей — на первый товар
// Товары каравана (продажа колонистам): разброс количества и базовая цена в серебре
export const TRADE_SELL: { res: Res; qty: [number, number]; price: number }[] = [
  { res: Res.Meal, qty: [4, 8], price: 3 },
  { res: Res.Food, qty: [6, 12], price: 2 },
  { res: Res.Iron, qty: [4, 8], price: 2 },
  { res: Res.Hide, qty: [3, 6], price: 3 },
  { res: Res.Coat, qty: [1, 2], price: 7 },
  { res: Res.LeatherArmor, qty: [1, 1], price: 10 },
  { res: Res.IronArmor, qty: [1, 1], price: 16 },
  { res: Res.Bow, qty: [1, 2], price: 8 },
  { res: Res.Sword, qty: [1, 1], price: 13 },
];
// Что караван покупает у колонии (базовые цены; итог с разбросом ±30%)
export const TRADE_BUY: Partial<Record<Res, number>> = {
  [Res.Food]: 1,
  [Res.Wood]: 1,
  [Res.Stone]: 1,
  [Res.Iron]: 2,
  [Res.Hide]: 2,
  [Res.Meal]: 2,
  [Res.Loot]: 6,
  [Res.Spear]: 3,
  [Res.Bow]: 4,
  [Res.Sword]: 6,
  [Res.Coat]: 4,
  [Res.LeatherArmor]: 5,
  [Res.IronArmor]: 8,
};

// --- Кабаны и медведи ---
export const BOAR_MAX = 3; // сколько кабанов держится в лесу
export const BOAR_SPAWN_CHANCE = 0.3; // шанс прихода новых за день
export const BEAR_SPAWN_CHANCE = 0.07; // медведь — редкий гость
export const BOAR_ATK = 7;
export const BOAR_ATK_RAND = 4;
export const BEAR_ATK = 10;
export const BEAR_ATK_RAND = 6;
export const BEAR_TERRITORY = 2.6; // медведь атакует тех, кто подошёл вплотную
// Удар хищников — виден в окне зверя (чтобы игрок знал, чем рискует)
export const PREDATOR_STATS: Partial<Record<string, string>> = {
  wolf: `Удар: 5–9 · приходит ночью`,
  boar: `Удар: ${BOAR_ATK}–${BOAR_ATK + BOAR_ATK_RAND} · дерётся в ответ`,
  bear: `Удар: ${BEAR_ATK}–${BEAR_ATK + BEAR_ATK_RAND} · очень опасен`,
};

// --- Рецепты верстака ---
export interface RecipeDef {
  id: number;
  res: Res;
  name: string;
  work: number; // игровых минут работы
  wood: number; // сколько дерева нужно принести
  iron: number; // сколько железа нужно принести (0 — не нужно)
  hide: number; // сколько шкур нужно принести (0 — не нужно)
}
// Материал рецепта: железо важнее шкур, шкуры важнее дерева
export function craftMat(rec: RecipeDef): Res {
  if (rec.iron > 0) return Res.Iron;
  if (rec.hide > 0) return Res.Hide;
  return Res.Wood;
}
export function craftNeed(rec: RecipeDef): number {
  if (rec.iron > 0) return rec.iron;
  if (rec.hide > 0) return rec.hide;
  return rec.wood;
}
export const RECIPES: RecipeDef[] = [
  { id: 0, res: Res.Spear, name: 'Копьё', work: 40, wood: 4, iron: 0, hide: 0 },
  { id: 1, res: Res.Bow, name: 'Лук', work: 50, wood: 6, iron: 0, hide: 0 },
  { id: 2, res: Res.Sword, name: 'Меч', work: 70, wood: 0, iron: 4, hide: 0 },
  { id: 3, res: Res.Coat, name: 'Тёплая куртка', work: 45, wood: 0, iron: 0, hide: 4 },
  { id: 4, res: Res.LeatherArmor, name: 'Кожаная броня', work: 60, wood: 0, iron: 0, hide: 6 },
  { id: 5, res: Res.IronArmor, name: 'Железная броня', work: 90, wood: 0, iron: 6, hide: 0 },
];
export const YIELDS = { tree: 14, rock: 12, ore: 8, silver: 3, dig: 12, berry: 10, crop: 8, rabbit: 4, wolf: 6, deer: 8, boar: 10, bear: 18, bush: 2 };
// Шкуры с добытых зверей (кроличья — маленькая, но тоже шкурка)
export const HIDE_YIELDS: Record<string, number> = { wolf: 2, deer: 2, boar: 3, bear: 6, rabbit: 1 };
// Трапеза за столом (RimWorld-стиль: стол + стул)
export const DINED_MOOD = 5; // настроение «Поел за столом»
export const DINED_MIN = 300; // длительность в игровых минутах
export const DINE_SEARCH_R = 10; // как далеко от пешки ищем стул у стола (еду несем к столу)
export const XP_PER_ACTION = 2;

// --- Время суток ---
export const DAWN_H = 5;
export const DAY_H = 7;
export const EVENING_H = 19;
export const NIGHT_H = 22;

export const PAWN_COLORS = ['#e0913f', '#9db85c', '#c96f7e', '#7fb2c9', '#b08fd0', '#c9b17f'];
export const PAWN_NAMES = ['Ася', 'Тихон', 'Груша'];
// имена для новых колонистов (событие «Странник просит приюта» и т.п.)
export const EXTRA_NAMES: { name: string; gender: 'м' | 'ж' }[] = [
  { name: 'Рада', gender: 'ж' },
  { name: 'Лука', gender: 'м' },
  { name: 'Мила', gender: 'ж' },
  { name: 'Захар', gender: 'м' },
  { name: 'Нюра', gender: 'ж' },
  { name: 'Сава', gender: 'м' },
];
export const MAX_COLONY = 6; // предел колонии в MVP

// --- Инструменты игрока ---
export type Tool =
  | 'inspect'
  | 'chop'
  | 'mine'
  | 'harvest'
  | 'hunt'
  | 'attack'
  | 'wall'
  | 'door'
  | 'bed'
  | 'campfire'
  | 'workbench'
  | 'table'
  | 'chair'
  | 'torch'
  | 'stonewall'
  | 'grave'
  | 'mineshaft'
  | 'trap'
  | 'turret'
  | 'stockpile'
  | 'farm';

// Инструмент -> тип постройки (для стройки)
export const TOOL_BTYPE: Partial<Record<Tool, BType>> = {
  wall: BType.Wall,
  door: BType.Door,
  bed: BType.Bed,
  campfire: BType.Campfire,
  workbench: BType.Workbench,
  table: BType.Table,
  chair: BType.Chair,
  torch: BType.Torch,
  stonewall: BType.StoneWall,
  grave: BType.Grave,
  mineshaft: BType.Mine,
  trap: BType.Trap,
  turret: BType.Turret,
};

export const TOOL_INFO: Record<Tool, { name: string; icon: string; hint: string }> = {
  inspect: { name: 'Осмотр', icon: '👆', hint: 'Нажимайте на пешек, зверей и постройки' },
  chop: { name: 'Рубить', icon: '🪓', hint: 'Деревья и кусты: тап или рамка пальцем' },
  mine: { name: 'Копать', icon: '⛏️', hint: 'Валуны, жилы и сплошная скала: тап или рамка. Вгрызайтесь в горы — внутри руда и серебро' },
  harvest: { name: 'Собрать', icon: '🌿', hint: 'Тап или рамка — собрать ягоды/урожай' },
  hunt: { name: 'Охота', icon: '🎯', hint: 'Тап по зверю — пометить для охоты (рамкой — целое стадо). Охотник сам добудет мясо и шкуры. Оленю нужен стрелок с луком' },
  attack: { name: 'Атака', icon: '⚔️', hint: 'Нажмите на зверя, чтобы атаковать его' },
  wall: { name: 'Стена', icon: '🧱', hint: 'Тап или линия пальцем: 3 дерева за секцию' },
  door: { name: 'Дверь', icon: '🚪', hint: 'Пешки проходят, звери — нет' },
  bed: { name: 'Кровать', icon: '🛏️', hint: '6 дерева. Сон даёт лучший отдых' },
  campfire: { name: 'Костёр', icon: '🔥', hint: '3 дерева. Свет, уют и горячая еда' },
  workbench: { name: 'Верстак', icon: '🔨', hint: '8 дерева. Здесь сделают копья, луки и мечи' },
  table: { name: 'Стол', icon: '🍽️', hint: '7 дерева. Еда за столом радует колонистов' },
  chair: { name: 'Стул', icon: '🪑', hint: '3 дерева. Ставьте вплотную к столу — место для трапезы' },
  torch: { name: 'Факел', icon: '🕯️', hint: '2 дерева. Свет ночью — у тропинок, стен и входа' },
  stonewall: { name: 'Кам. стена', icon: '🗿', hint: '4 камня. Вдвое крепче деревянной — волкам не по зубам' },
  grave: { name: 'Могила', icon: '🪦', hint: '2 камня. Погибшего похоронят здесь — с именем и памятью' },
  mineshaft: { name: 'Шахта', icon: '🕳️', hint: '4 дерева на серой скале. Вход в глубины: экспедиции добывают железо, камень и серебро' },
  trap: { name: 'Колья', icon: '🪤', hint: '4 дерева. Ловушка на тропе: зверь напорется — и колья сломаются о него' },
  turret: { name: 'Башня', icon: '🏹', hint: '5 железа. Арбалетная башня сама бьёт по волкам в радиусе 5 клеток' },
  stockpile: { name: 'Склад', icon: '📦', hint: 'Тап/рамка — новый склад; вплотную к нему — расширение. Осмотр зоны → ⚙️ настройки' },
  farm: { name: 'Ферма', icon: '🌱', hint: 'Тап/рамка — новая ферма; вплотную — расширение. Осмотр зоны → ⚙️ настройки' },
};

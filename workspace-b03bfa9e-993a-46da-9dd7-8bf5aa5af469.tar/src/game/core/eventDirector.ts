// Режиссёр событий колонии: случайные происшествия с выбором игрока и последствиями.
// События — часть симуляции: не знают о рендере и React (правило архитектуры).

import { Res, MAX_COLONY, EXTRA_NAMES } from '../data/defs';
import type { Game } from './game';
import type { Pawn } from '../entities/pawn';

export interface ChoiceOption {
  label: string;
  hint: string;
}

// Диалог выбора: показывается в модалке, игра на паузе, исход применяется к симуляции
export interface PendingChoice {
  id: string;
  icon: string;
  title: string;
  text: string;
  options: ChoiceOption[];
  meta?: { name?: string; gender?: 'м' | 'ж' }; // например, гость, просящий приюта
}

export interface EvState {
  lastEventDay: number; // день последнего «события с выбором»
  wandererHelped: boolean; // поделились едой с путником
  helpDay: number; // день помощи
  giftDay: number; // день, когда подарок уже выдан (0 — не выдан)
  nextCaravanDay?: number; // день следующего каравана (старые сейвы — 4)
}

function moodAll(game: Game, id: string, label: string, delta: number, dur: number) {
  for (const p of game.pawns) {
    if (p.dead) continue;
    p.addMod(id, label, delta, dur, game.clock.totalMin);
  }
}

function takeFood(game: Game, qty: number): number {
  let need = qty;
  for (const it of [...game.world.items]) {
    if (it.type !== Res.Food || need <= 0) continue;
    const take = Math.min(it.qty, need);
    it.qty -= take;
    need -= take;
    if (it.qty <= 0) game.world.removeItem(it);
  }
  return qty - need;
}

function dropSpot(game: Game): { x: number; y: number } {
  const c = game.world.stockpileCenter();
  if (c) return { x: Math.floor(c.x), y: Math.floor(c.y) };
  const p = game.pawns.find((q) => !q.dead);
  return p ? { x: Math.floor(p.x), y: Math.floor(p.y) } : { x: game.spawnX, y: game.spawnY };
}

export class EventDirector {
  state: EvState = { lastEventDay: 0, wandererHelped: false, helpDay: 0, giftDay: 0, nextCaravanDay: 4 };
  private acc = 0; // аккумулятор игровых минут между проверками
  private choicePrevSpeed: 0 | 1 | 2 | 4 | 8 | 16 = 1;

  reset() {
    this.state = { lastEventDay: 0, wandererHelped: false, helpDay: 0, giftDay: 0, nextCaravanDay: 4 };
    this.acc = 0;
  }

  update(game: Game, dtG: number) {
    if (game.gameOver || game.pendingChoice) return;
    this.tryGift(game); // цепочка последствий помощи путнику
    this.tryCaravan(game); // караваны приходят по расписанию
    this.acc += dtG;
    if (this.acc < 30) return; // проверка раз в ~30 игровых минут
    this.acc = 0;
    const day = game.clock.day;
    const h = game.clock.hour;
    if (h < 6 || h >= 21) return; // события днём и под вечер

    // одно «событие с выбором» в день (со 2-го дня)
    if (day >= 2 && day !== this.state.lastEventDay && game.rng.chance(0.55)) {
      this.state.lastEventDay = day;
      this.fireChoice(game, day);
      return;
    }
    // малые автоматические события
    const r = game.rng.next();
    if (r < 0.03) this.evtCalm(game);
    else if (r < 0.05 && day >= 4) this.evtIllness(game);
    else if (r < 0.07 && day >= 2 && h >= 18) this.evtHowl(game);
    else if (r < 0.1) this.evtQuarrel(game);
  }

  // ---------- События с выбором ----------

  private fireChoice(game: Game, day: number) {
    const alive = game.pawns.filter((p) => !p.dead).length;
    const joinerAllowed = day >= 3 && alive < MAX_COLONY;
    const r = game.rng.next();
    if (joinerAllowed && r < 0.3) {
      this.evtJoiner(game);
    } else if (day >= 3 && r < 0.6) {
      this.evtCache(game);
    } else {
      this.evtWanderer(game);
    }
  }

  private ask(game: Game, choice: PendingChoice) {
    this.choicePrevSpeed = game.clock.speed || 1;
    if (game.gameSettings.autopauseEvents) game.clock.speed = 0; // пауза на время решения (отключается в настройках)
    game.pendingChoice = choice;
  }

  private evtWanderer(game: Game) {
    this.ask(game, {
      id: 'wanderer',
      icon: '🚶',
      title: 'Путник у костра',
      text: 'К краю лагеря выходит усталый путник. Он не называет имени и не объясняет, откуда идёт. Только просит немного еды.',
      options: [
        { label: 'Поделиться едой', hint: '−8 еды. Колония запомнит доброту' },
        { label: 'Отказать', hint: 'Путник уйдёт во тьму' },
      ],
    });
  }

  private evtCache(game: Game) {
    this.ask(game, {
      id: 'cache',
      icon: '✨',
      title: 'Блеск среди камней',
      text: 'Между валунами что-то поблёскивает. Похоже, кто-то спрятал припасы — давно и надёжно.',
      options: [
        { label: 'Раскопать тайник', hint: 'Может повезти, а может и нет' },
        { label: 'Пройти мимо', hint: 'Любопытство подождёт' },
      ],
    });
  }

  private evtJoiner(game: Game) {
    // имя: не совпадающее с живыми колонистами
    const used = new Set(game.pawns.filter((p) => !p.dead).map((p) => p.name));
    const pool = EXTRA_NAMES.filter((n) => !used.has(n.name));
    const who = pool.length > 0 ? game.rng.pick(pool) : { name: 'Странник', gender: 'м' as const };
    this.ask(game, {
      id: 'joiner',
      icon: '🧍',
      title: 'Странник просит приюта',
      text: `Из леса выходит измотанный человек — ${who.name}. Говорит, что шёл к свету костра со вчерашнего дня. Руки крепкие, глаза честные. Просит разрешения остаться.`,
      options: [
        { label: 'Принять в колонию', hint: '+1 колонист. Больше рук — но и ртов больше' },
        { label: 'Отказать', hint: 'У костра и так тесно' },
      ],
      meta: { name: who.name, gender: who.gender },
    });
  }

  // Применение выбора игрока (вызывается из game.resolveChoice)
  resolve(game: Game, idx: number) {
    const c = game.pendingChoice;
    if (!c) return;
    game.clock.speed = this.choicePrevSpeed;
    game.pendingChoice = null;
    switch (c.id) {
      case 'wanderer':
        if (idx === 0) {
          const got = takeFood(game, 8);
          if (got >= 6) {
            this.state.wandererHelped = true;
            this.state.helpDay = game.clock.day;
            moodAll(game, 'kind', 'Доброе дело', 6, 960);
            game.events.log('Колония поделилась едой с путником. Он молча кивнул и ушёл в туман.', 'story');
          } else {
            moodAll(game, 'noFood', 'Не смогли помочь', -2, 480);
            game.events.log('У колонии не нашлось еды для путника. Он понял и ушёл.', 'info');
          }
        } else {
          moodAll(game, 'refused', 'Прошли мимо чужой беды', -2, 480);
          game.events.log('Путник постоял у края света и растворился в темноте.', 'info');
        }
        break;
      case 'cache':
        if (idx === 0) {
          if (game.rng.chance(0.7)) {
            const s = dropSpot(game);
            game.world.addItem(Res.Food, 6, s.x, s.y);
            game.world.addItem(Res.Wood, 8, s.x, s.y);
            game.world.addItem(Res.Stone, 8, s.x, s.y);
            game.events.log('В тайнике оказались припасы! Кто-то сберёг их для нас.', 'good');
          } else {
            const victim = game.randomAlivePawn();
            if (victim) {
              game.damagePawn(victim, 14);
              game.events.log(`Под камнем пряталась гадюка! ${victim.name} укушен(а).`, 'bad');
            }
          }
        } else {
          game.events.log('Решили не трогать чужие тайны.', 'info');
        }
        break;
      case 'joiner': {
        const name = c.meta?.name ?? 'Странник';
        const gender = c.meta?.gender ?? 'м';
        if (idx === 0) {
          const p = game.addColonyMember(name, gender);
          if (!p) game.events.log(`${name} подошёл слишком поздно — места в колонии больше нет. Он ушёл, не оглянувшись.`, 'info');
        } else {
          const alive = game.pawns.filter((p) => !p.dead).length;
          game.events.log(`${name} постоял у края света и ушёл в лес. Колония остаётся в ${alive} человек(а)... пока может.`, 'info');
        }
        break;
      }
    }
  }

  // ---------- Цепочка последствий: благодарность путника ----------
  private tryGift(game: Game) {
    const st = this.state;
    if (!st.wandererHelped || st.giftDay !== 0) return;
    const day = game.clock.day;
    if (day !== st.helpDay + 1 || game.clock.hour < 7 || game.clock.hour >= 12) return;
    st.giftDay = day;
    const s = dropSpot(game);
    game.world.addItem(Res.Food, 10, s.x, s.y);
    game.world.addItem(Res.Loot, 1, s.x, s.y);
    moodAll(game, 'kindBack', 'Добро вернулось', 8, 960);
    game.events.log('Утром у склада нашли узелок: еда и старая находка. Путник вернулся отблагодарить.', 'story');
  }

  // ---------- Караваны: раз в 3–5 дней, днём, если торговца в лагере нет ----------
  private tryCaravan(game: Game) {
    const st = this.state;
    const next = st.nextCaravanDay ?? 4;
    const day = game.clock.day;
    if (day < next) return;
    const h = game.clock.hour;
    if (h < 9 || h >= 17) return; // караваны ходят при свете дня
    // назначаем следующий приход сразу, чтобы не проверять каждый тик
    st.nextCaravanDay = day + game.rng.int(3, 5);
    game.spawnCaravan();
  }

  // ---------- Автоматические события ----------

  private evtCalm(game: Game) {
    moodAll(game, 'calm', 'Тихий день', 3, 480);
    game.events.log('Сегодня спокойно. Птицы поют, ветер шумит в кронах.', 'good');
  }

  private evtIllness(game: Game) {
    const p = game.randomAlivePawn();
    if (!p || p.sickMin > 0) return;
    p.sickMin = 420;
    game.events.log(`${p.name} слёг(ла): жар и слабость. Нужны покой и сон.`, 'bad');
  }

  private evtHowl(game: Game) {
    if (game.animals.some((a) => a.kind === 'wolf')) return;
    game.wolfBonus = 1.6;
    game.events.log('Вой приближающейся стаи слышен со стороны леса. Ночь будет тревожной.', 'bad');
  }

  private evtQuarrel(game: Game) {
    const alive = game.pawns.filter((p) => !p.dead && p.food < 40);
    if (alive.length < 2) return;
    let worst: { a: Pawn; b: Pawn; s: number } | null = null;
    for (let i = 0; i < alive.length; i++) {
      for (let j = i + 1; j < alive.length; j++) {
        const pair = game.relationPairs(alive[i].id).find((r) => r.other === alive[j].id);
        const s = pair?.score ?? 0;
        if (!worst || s < worst.s) worst = { a: alive[i], b: alive[j], s };
      }
    }
    if (!worst || worst.s >= 25) return;
    game.addRelation(worst.a.id, worst.b.id, -8);
    worst.a.addMod('quarrel', 'Ссора', -5, 480, game.clock.totalMin);
    worst.b.addMod('quarrel', 'Ссора', -5, 480, game.clock.totalMin);
    game.events.log(`${worst.a.name} и ${worst.b.name} поругались из-за последних крох еды.`, 'bad');
  }
}

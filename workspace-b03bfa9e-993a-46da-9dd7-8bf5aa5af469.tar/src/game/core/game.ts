// Игра: оркестратор симуляции. Не зависит от рендера и React.

import { MAP, MIN_PER_SEC, Obj, Res, BType, Zone, FarmStage, BUILDINGS, PAWN_NAMES, PAWN_COLORS, RECIPES, Terrain, Tool, WorkCat, WORK_CATS, SKILLS, MAX_COLONY, YIELDS, HIDE_YIELDS, HUNT_DANGEROUS, WEAPON_NAMES, WEAPON_RES, WEAPON_ICONS, ARMOR_NAMES, ARMOR_ICONS, STOCKPILE_RES, RES_INFO, FILTER_LEN, FIRE_WARM_R, COLD_MOOD, COLD_HP_RATE, AUTUMN_MOOD, WALK_WINTER, WALK_BLIZZARD, BLIZZ_CHANCE, WOLF_WINTER_MULT, EXP_TOTAL, EXP_CHECKPOINTS, TURRET_RANGE, TURRET_CD, TURRET_DMG, TURRET_RAND, TRADE_SELL, TRADE_BUY, TOOL_BTYPE, LEATHER_ARMOR_MULT, IRON_ARMOR_MULT, COAT_WARM_MOOD, BOAR_MAX, BOAR_SPAWN_CHANCE, BEAR_SPAWN_CHANCE, ITEM_STATS, PREDATOR_STATS, weaponStatLine, armorStatLine, type ZoneKind, type WeaponKind, type ArmorKind, type RecipeDef } from '../data/defs';
import { Clock } from './clock';
import { EventLog } from './events';
import { RNG } from './rng';
import { World } from '../world/world';
import { generateWorld, placeStartCampfire } from '../world/mapgen';
import { Pawn } from '../entities/pawn';
import { Animal, type AnimalKind } from '../entities/animal';
import { updateAnimal } from '../entities/animalAI';
import { JobSystem, type JobExt } from '../ai/jobs';
import { decidePawn, updatePawn, moodList, activityOf, releaseBoardJob, nightWolfChance, startExpeditionWalk, resumeExpedition, freeSpotNear, startFlee, startFight } from '../ai/pawnAI';
import { createBlueprint, completeBuilding as completeBuildingInternal, resetBuildingIds, peekBuildingId, defaultBills, type Building } from '../buildings/buildings';
import { EventDirector, type EvState, type PendingChoice } from './eventDirector';
import { dist } from './util';

// 4 направления для BFS достижимости (диагонали не считаем связью — консервативно)
const REACH_DIRS = [
  [1, 0],
  [-1, 0],
  [0, 1],
  [0, -1],
] as const;

export interface SaveData {
  v: number;
  seed: number;
  totalMin: number;
  terrain: Uint8Array;
  obj: Uint8Array;
  objHp: Float32Array;
  zone: Uint8Array;
  zoneId?: Uint8Array; // номера зон (старые сейвы — миграция)
  zoneDefs?: { id: number; kind: string; name: string; filters: boolean[] }[];
  farmStage: Uint8Array;
  farmGrowth: Float32Array;
  berryRegrow: Float32Array;
  explored: Uint8Array;
  items: { id: number; type: number; qty: number; x: number; y: number; decay?: number; name?: string }[];
  buildings: Building[];
  pawns: Record<string, unknown>[];
  animals: { id: number; kind: string; x: number; y: number; hp: number; siege?: boolean }[];
  events: { id: number; t: number; text: string; kind: string }[];
  nextEventId: number;
  relations: { a: number; b: number; score: number; friends: boolean; close?: boolean }[];
  desig: { chop: Uint8Array; mine: Uint8Array; harvest: Uint8Array };
  weather?: { rain?: boolean; rainUntil?: number; lastDay?: number; blizzard?: boolean; blizzardUntil?: number }; // старые сейвы — без blizzard
  stats: Stats;
  ev?: EvState;
  npid?: number; // nextPawnId (для новых колонистов; старые сейвы — вычисляем)
  nextItemId: number;
  nextAnimalId: number;
  lastWolfNight: number;
  alarmMin?: number; // боевая тревога: осталось игровых минут (старые сейвы — без поля)
  settings?: GameSettings; // настройки игры (старые сейвы — по умолчанию)
  expeditions?: { pawnId: number; mineId: number; stage: number; tTotal: number; tLeft: number; nextEv: number; log: { text: string; kind: string }[]; loot: { res: number; qty: number }[] }[];
  trade?: { traderId: number; goods: { res: number; qty: number; price: number }[]; sell: { res: number; price: number }[] } | null;
  hunt?: number[]; // звери, помеченные для охоты (старые сейвы — пусто)
  recipes?: RecipeDef[]; // каталог рецептов верстака (админ-редактор мог изменить)
  gameOver: boolean;
}

// Настройки игры (меню паузы): влияют на автосейв и автопаузу
export interface GameSettings {
  autosave: boolean; // автосохранение (пауза/ночь/сворачивание)
  autopauseEvents: boolean; // события с выбором ставят игру на паузу
  autopauseAlarm: boolean; // штурм волков ставит игру на паузу
}

const DEFAULT_SETTINGS: GameSettings = { autosave: true, autopauseEvents: true, autopauseAlarm: false };

export interface Stats {
  treesChopped: number;
  rocksMined: number;
  harvests: number;
  built: number;
  firstBuilt: Record<number, boolean>;
  wolvesKilled: number;
  nightsUnderRoof: number;
  lastRoofNight: number;
  milestones: Record<number, boolean>; // юбилейные вехи по дням
  firstMeal?: boolean; // первая похлёбка
  firstWinterSurvived?: boolean; // колония пережила первую зиму
  firstIron?: boolean; // первое железо
  firstMineYield?: boolean; // первая добыча из шахты (эпоха вечной жилы — совместимость)
  firstSword?: boolean; // первый меч
  firstSilver?: boolean; // первое серебро
  firstExpedition?: boolean; // первая экспедиция в шахту
}

// Экспедиция в шахту: пешка уходит под землю на EXP_TOTAL минут и
// приносит добычу, по дороге переживая сюрпризы (обвалы, жилы, тайники)
export interface Expedition {
  pawnId: number;
  mineId: number;
  stage: number; // 0 — идёт к шахте, 1 — под землёй
  tTotal: number;
  tLeft: number;
  nextEv: number; // индекс следующего сюрприза в EXP_CHECKPOINTS
  log: { text: string; kind: 'info' | 'good' | 'bad' | 'story' }[];
  loot: { res: Res; qty: number }[]; // накопленная добыча (сверх базовой)
}

// Караван: товары на продажу и цены, по которым купец берёт наши ресурсы
export interface TradeState {
  traderId: number;
  goods: { res: Res; qty: number; price: number }[];
  sell: { res: Res; price: number }[];
}

export class Game {
  world = new World();
  clock = new Clock();
  events = new EventLog();
  jobs = new JobSystem();
  rng = new RNG(1);

  seed = 0;
  spawnX = 32;
  spawnY = 32;
  pawns: Pawn[] = [];
  animals: Animal[] = [];

  desig = { chop: new Uint8Array(MAP * MAP), mine: new Uint8Array(MAP * MAP), harvest: new Uint8Array(MAP * MAP) };
  weather = { rain: false, rainUntil: 0, lastDay: 1, blizzard: false, blizzardUntil: 0 };
  relations = new Map<string, { a: number; b: number; score: number; friends: boolean; close?: boolean }>();

  attackTargetId: number | null = null;
  // Звери, помеченные игроком для охоты (🎯): доска работ сама найдёт охотников
  huntList = new Set<number>();
  gameOver = false;
  warnedNoFood = false;
  eatFailCd = 0;
  realNow = 0;
  nextPawnId = 4; // первые трое — стартовые
  stats: Stats = { treesChopped: 0, rocksMined: 0, harvests: 0, built: 0, firstBuilt: {}, wolvesKilled: 0, nightsUnderRoof: 0, lastRoofNight: 0, milestones: {} };

  // шахтные экспедиции и торговля
  expeditions: Expedition[] = [];
  trade: TradeState | null = null;
  prodOpenId: number | null = null; // открытая панель производства (верстак/костёр)

  // события и их последствия
  evDirector = new EventDirector();
  pendingChoice: PendingChoice | null = null;
  wolfBonus = 1; // усиление шанса волков (событие «Вой стаи»)
  alarmMin = 0; // боевая тревога: волки у стен — смелые и бойцы бегут защищать
  private seasonSeen = -1; // какой сезон последний раз видел (для записей о смене сезонов)
  private alarmLogCd = 0;

  // таймеры
  private fogT = 0;
  private jobT = 0;
  private relT = 0;
  private growthAcc = 0;
  private saveT = 30;
  private lastWolfNight = 0;
  private lastDeerDay = 0;
  private lastBoarDay = 0;
  private lastBearDay = 0;
  private hurtLogCd = 0;
  private nextItemId = 1;
  private nextAnimalId = 1;
  private lastRoofNightId = -1;
  private discoveredRuins = new Set<number>();

  // для рендера
  dirtyTiles = new Set<number>();
  fullRedrawFlag = true;
  arrows: { x0: number; y0: number; x1: number; y1: number; t: number }[] = []; // летящие стрелы (визуал)

  // интерфейс
  tool: Tool = 'inspect';
  selectedPawnId: number | null = null;
  selectedInfo: { title: string; lines: string[]; tile: number; canCancel: boolean; buryItemId?: number; zoneId?: number; prodBId?: number; prodKind?: 'bench' | 'fire'; mineBId?: number; canTrade?: boolean; huntId?: number; hunting?: boolean } | null = null;
  settingsZoneId: number | null = null; // открытая модалка настроек зоны
  followId: number | null = null;
  gameSettings: GameSettings = { ...DEFAULT_SETTINGS };
  autosaveHook: ((g: Game) => void) | null = null;

  constructor(seed?: number) {
    this.events.timeProvider = () => this.clock.totalMin;
    this.newGame(seed);
  }

  // ============ Создание новой игры ============
  newGame(seed?: number) {
    this.seed = seed ?? Math.floor(Math.random() * 9000000) + 1000000;
    this.rng = new RNG(this.seed ^ 0x9e3779b9);
    this.clock = new Clock();
    this.jobs = new JobSystem();
    this.pawns = [];
    this.animals = [];
    this.relations.clear();
    this.discoveredRuins.clear();
    this.attackTargetId = null;
    this.gameOver = false;
    this.warnedNoFood = false;
    this.eatFailCd = 0;
    this.nextPawnId = 4;
    this.stats = { treesChopped: 0, rocksMined: 0, harvests: 0, built: 0, firstBuilt: {}, wolvesKilled: 0, nightsUnderRoof: 0, lastRoofNight: 0, milestones: {} };
    this.expeditions = [];
    this.trade = null;
    this.prodOpenId = null;
    this.events.reset(); // новая партия — чистый журнал (хуки сохраняются)
    this.evDirector.reset();
    this.pendingChoice = null;
    this.wolfBonus = 1;
    this.alarmMin = 0;
    this.alarmLogCd = 0;
    this.seasonSeen = 0; // старт — лето (день 1); дальше смена сезонов отслеживается
    this.lastRoofNightId = -1;
    this.desig = { chop: new Uint8Array(MAP * MAP), mine: new Uint8Array(MAP * MAP), harvest: new Uint8Array(MAP * MAP) };
    this.weather = { rain: false, rainUntil: 0, lastDay: 1, blizzard: false, blizzardUntil: 0 };
    this.lastWolfNight = 0;
    this.lastDeerDay = 0;
    this.nextItemId = 1;
    this.nextAnimalId = 1;
    resetBuildingIds(1);
    this.fullRedrawFlag = true;
    this.dirtyTiles.clear();

    const gen = generateWorld(this.world, this.seed);
    this.spawnX = gen.spawnX;
    this.spawnY = gen.spawnY;
    placeStartCampfire(this.world, this.rng, this.spawnX, this.spawnY);

    // три колониста
    const traitPool = ['hardworker', 'sleeper', 'fidget', 'greedy', 'brave', 'coward', 'loner'];
    for (let i = 0; i < 3; i++) {
      const p = this.spawnPawn(
        i + 1,
        PAWN_NAMES[i],
        this.spawnX + (i - 1) * 1.2 + 0.5,
        this.spawnY + 0.5 + (i === 1 ? 1 : 0),
        [this.rng.pick(traitPool)],
        i === 0 ? 'ж' : i === 1 ? 'м' : 'ж',
        this.rng.int(22, 41),
      );
      // второй черт с шансом
      if (this.rng.chance(0.5)) {
        const t2 = this.rng.pick(traitPool);
        if (!p.traits.includes(t2)) p.traits.push(t2);
      }
      // навыки: один профильный + разброс
      const spec = this.rng.pick(SKILLS.map((s) => s.id));
      this.assignSpec(p, spec, this.rng.int(5, 8));
    }
    // кролики
    for (let i = 0; i < 6; i++) {
      const x = this.rng.int(3, MAP - 4);
      const y = this.rng.int(3, MAP - 4);
      if (this.world.passAnimal(x, y) && this.animalReachable(x, y)) this.spawnAnimal('rabbit', x + 0.5, y + 0.5);
    }
    // олени (крупная дичь — 8 еды)
    for (let i = 0; i < 4; i++) {
      const x = this.rng.int(3, MAP - 4);
      const y = this.rng.int(3, MAP - 4);
      if (this.world.passAnimal(x, y) && this.animalReachable(x, y)) this.spawnAnimal('deer', x + 0.5, y + 0.5);
    }
    // кабаны — свирепая дичь: много мяса и шкур, но и в ответ дают
    for (let i = 0; i < 3; i++) {
      const x = this.rng.int(3, MAP - 4);
      const y = this.rng.int(3, MAP - 4);
      if (this.world.passAnimal(x, y) && this.animalReachable(x, y)) this.spawnAnimal('boar', x + 0.5, y + 0.5);
    }
    // медведь — один, подальше от лагеря: хозяин леса
    for (let tries = 0; tries < 60; tries++) {
      const x = this.rng.int(3, MAP - 4);
      const y = this.rng.int(3, MAP - 4);
      const far = Math.hypot(x - this.spawnX, y - this.spawnY) > 14;
      if (far && this.world.passAnimal(x, y) && this.animalReachable(x, y)) {
        this.spawnAnimal('bear', x + 0.5, y + 0.5);
        break;
      }
    }
    this.world.updateVisibility(this.pawns);
    this.events.log(`Колония «Осколок» основана. Seed: ${this.seed}. Трое выживших разбивают лагерь.`, 'story');
    this.jobs.refresh(this.world, this.desig, this.realNow, this.canHaul(), this.jobExt());
  }

  canHaul(): boolean {
    return this.world.stockpileHasSpace();
  }

  // Зверь должен быть достижим из лагеря: животное, запертое скалами или буреломом,
  // нельзя ни добыть на охоте, ни встретить в бою — оно только зря попадает в метки.
  // BFS в 4 направлениях от точки спавна до окрестности лагеря (радиус 6).
  animalReachable(x: number, y: number): boolean {
    const w = this.world;
    if (!w.passAnimal(x, y)) return false;
    const seen = new Uint8Array(MAP * MAP);
    const q: number[] = [w.idx(x, y)];
    seen[q[0]] = 1;
    let head = 0;
    while (head < q.length) {
      const cur = q[head++];
      const cx = cur % MAP;
      const cy = (cur / MAP) | 0;
      if (Math.abs(cx - this.spawnX) <= 6 && Math.abs(cy - this.spawnY) <= 6) return true;
      for (const [dx, dy] of REACH_DIRS) {
        const nx = cx + dx;
        const ny = cy + dy;
        if (nx < 1 || ny < 1 || nx >= MAP - 1 || ny >= MAP - 1) continue;
        const ni = ny * MAP + nx;
        if (seen[ni] || !w.passAnimal(nx, ny)) continue;
        seen[ni] = 1;
        q.push(ni);
      }
    }
    return false;
  }

  // Данные для генерации задач готовки/крафта/охоты на доске работ
  jobExt(): JobExt {
    const alive = this.pawns.filter((p) => !p.dead);
    return {
      alive: alive.length,
      meals: this.world.countRes(Res.Meal),
      food: this.world.countRes(Res.Food),
      spears: this.world.countRes(Res.Spear) + alive.filter((p) => p.weapon === 'spear').length,
      bows: this.world.countRes(Res.Bow) + alive.filter((p) => p.weapon === 'bow').length,
      swords: this.world.countRes(Res.Sword) + alive.filter((p) => p.weapon === 'sword').length,
      coats: this.world.countRes(Res.Coat) + alive.filter((p) => p.cloth === 'coat').length,
      leathers: this.world.countRes(Res.LeatherArmor) + alive.filter((p) => p.armor === 'leather').length,
      irons: this.world.countRes(Res.IronArmor) + alive.filter((p) => p.armor === 'iron').length,
      hunt: this.animals.filter((a) => !a.dead && this.huntList.has(a.id)).map((a) => ({ id: a.id, kind: a.kind as string, x: a.x, y: a.y })),
    };
  }

  // Пометить/снять зверя с охоты (кнопка в окне зверя и инструмент 🎯)
  toggleHunt(animalId: number): boolean {
    const a = this.animals.find((an) => an.id === animalId && !an.dead);
    if (!a || a.kind === 'trader') return false;
    if (this.huntList.has(animalId)) {
      this.huntList.delete(animalId);
      this.events.log(`Охота на «${a.name}» отменена.`, 'info');
    } else {
      this.huntList.add(animalId);
      const bow = a.kind === 'deer' || a.kind === 'rabbit';
      this.events.log(`«${a.name}» помечен(а) для охоты${bow ? ' — нужен стрелок с луком' : ''}.`, 'info');
      // сразу скажем игроку, если охота в принципе не начнётся: нет подходящего снаряжения
      const hasGround = (t: Res) => this.world.items.some((it) => it.type === t);
      if (bow) {
        const shooter = this.pawns.some((p) => !p.dead && p.weapon === 'bow');
        if (!shooter && !hasGround(Res.Bow)) {
          this.events.log('Стрелка с луком нет: смастерите лук на верстаке (6 дерева) — иначе на бегущую дичь никто не пойдёт.', 'bad');
        }
      } else if ((HUNT_DANGEROUS as readonly string[]).includes(a.kind)) {
        const armed = this.pawns.some((p) => !p.dead && p.weapon !== null);
        const anyWeapon = hasGround(Res.Spear) || hasGround(Res.Bow) || hasGround(Res.Sword);
        if (!armed && !anyWeapon) {
          this.events.log('Ни у кого нет оружия: на такого зверя безоружный не пойдёт. Смастерите копьё или меч.', 'bad');
        }
      }
    }
    return true;
  }

  // Выстрел из лука — визуальная стрела (рендер рисует её полёт)
  spawnArrow(x0: number, y0: number, x1: number, y1: number) {
    this.arrows.push({ x0, y0, x1, y1, t: 0.22 });
  }

  // ==== Создание пешки (стартовые и новые колонисты) ====
  private spawnPawn(id: number, name: string, x: number, y: number, traits: string[], gender: 'м' | 'ж', age: number): Pawn {
    const p = new Pawn(id, name, x, y, id - 1, traits, gender, age);
    if (id >= this.nextPawnId) this.nextPawnId = id + 1;
    this.pawns.push(p);
    return p;
  }

  // Профильный навык: задаёт уровень, остальным разброс; навык поднимается в приоритетах
  private assignSpec(p: Pawn, spec: string, specLvl: number) {
    p.skills[spec as keyof Pawn['skills']] = { lvl: specLvl, xp: 0 };
    for (const s of SKILLS) {
      if (s.id !== spec) p.skills[s.id] = { lvl: this.rng.int(0, 3), xp: 0 };
    }
    const order: WorkCat[] = ['cook', 'build', 'farm', 'lumber', 'hunt', 'mine', 'haul'];
    const map: Record<string, WorkCat> = { lumber: 'lumber', mine: 'mine', farm: 'farm', build: 'build', medicine: 'cook', melee: 'lumber', cook: 'cook', ranged: 'hunt' };
    const top = map[spec] ?? 'lumber';
    p.priorities = [top, ...order.filter((c) => c !== top)];
  }

  // ==== Новый колонист: событие «Странник просит приюта» ====
  addColonyMember(name: string, gender: 'м' | 'ж'): Pawn | null {
    const alive = this.pawns.filter((p) => !p.dead);
    if (alive.length >= MAX_COLONY) return null;
    // ищем свободную клетку у края лагеря (гость выходит из леса)
    const c = this.world.stockpileCenter() ?? { x: this.spawnX, y: this.spawnY };
    let px = Math.floor(c.x);
    let py = Math.floor(c.y);
    outer: for (let r = 7; r <= 13; r += 2) {
      for (let t = 0; t < 20; t++) {
        const ang = (Math.PI * 2 * t) / 20 + this.rng.next();
        const tx = Math.round(c.x + Math.cos(ang) * r);
        const ty = Math.round(c.y + Math.sin(ang) * r);
        if (tx < 1 || ty < 1 || tx >= MAP - 1 || ty >= MAP - 1) continue;
        if (this.world.passPawn(tx, ty) && this.world.terrain[this.world.idx(tx, ty)] !== Terrain.Water) {
          px = tx;
          py = ty;
          break outer;
        }
      }
    }
    const traitPool = ['hardworker', 'sleeper', 'fidget', 'brave', 'coward', 'loner'];
    const traits = [this.rng.pick(traitPool)];
    if (this.rng.chance(0.4)) {
      const t2 = this.rng.pick(traitPool);
      if (!traits.includes(t2)) traits.push(t2);
    }
    const p = this.spawnPawn(this.nextPawnId, name, px + 0.5, py + 0.5, traits, gender, this.rng.int(19, 45));
    const spec = this.rng.pick(SKILLS.map((s) => s.id));
    this.assignSpec(p, spec, this.rng.int(4, 8));
    // настроение: новичок рад дому, колония — новым рукам
    p.addMod('newhome', 'Новая надежда', 6, 1440, this.clock.totalMin);
    for (const o of this.pawns) {
      if (o === p || o.dead) continue;
      o.addMod('newblood', 'Новые руки', 3, 960, this.clock.totalMin);
    }
    this.events.log(`Странник вышел из леса — теперь это ${p.name}. Колония выросла до ${this.pawns.filter((q) => !q.dead).length} человек.`, 'story');
    return p;
  }

  spawnAnimal(kind: AnimalKind, x: number, y: number): Animal {
    const a = new Animal(this.nextAnimalId++, kind, x, y);
    this.animals.push(a);
    return a;
  }

  removeAnimal(a: Animal) {
    a.dead = true;
    const k = this.animals.indexOf(a);
    if (k >= 0) this.animals.splice(k, 1);
    if (this.attackTargetId === a.id) this.attackTargetId = null;
    this.huntList.delete(a.id);
    if (a.kind === 'trader') this.closeTrade(a.id);
    for (const p of this.pawns) if (p.combatTargetId === a.id) {
      p.combatTargetId = null;
      if (p.state === 'fight') p.state = 'idle';
    }
  }

  // ============ Главный тик ============
  tick(dtReal: number) {
    this.realNow += dtReal;
    this.eatFailCd = Math.max(0, this.eatFailCd - dtReal);
    this.hurtLogCd = Math.max(0, this.hurtLogCd - dtReal);
    // стрелы живут в реальном времени — видны и на паузе
    for (let i = this.arrows.length - 1; i >= 0; i--) {
      this.arrows[i].t -= dtReal;
      if (this.arrows[i].t <= 0) this.arrows.splice(i, 1);
    }
    this.clock.tick(dtReal);
    const dtG = dtReal * MIN_PER_SEC * this.clock.speed;
    if (dtG <= 0 || this.gameOver) return;
    this.alarmLogCd = Math.max(0, this.alarmLogCd - dtG);

    // боевая тревога: тикает только в живом времени; без волков — отбой
    if (this.alarmMin > 0) {
      this.alarmMin = Math.max(0, this.alarmMin - dtG);
      if (this.alarmMin === 0 && !this.animals.some((a) => a.kind === 'wolf' && !a.dead)) {
        this.allClear();
      }
    }

    this.updateWeather();
    this.updateGrowth(dtG);
    this.updateCorpses(dtG);
    this.updateCold(dtG);
    this.updateTurrets(dtG);
    this.updateExpeditions(dtG);

    for (const a of [...this.animals]) updateAnimal(this, a, dtG);

    // решения AI со сдвигом фаз
    this.pawns.forEach((p, i) => {
      p.aiT -= dtReal;
      if (p.aiT <= 0) {
        p.aiT = 0.45 + i * 0.08;
        if (!p.dead) decidePawn(this, p);
      }
    });
    for (const p of this.pawns) updatePawn(this, p, dtG);

    this.updateRelations(dtG);

    this.fogT -= dtReal;
    if (this.fogT <= 0) {
      this.fogT = 0.4;
      this.world.updateVisibility(this.pawns.filter((p) => !p.dead && !p.underground));
      this.checkDiscoveries();
      this.checkRoofNight();
    }

    this.jobT -= dtReal;
    if (this.jobT <= 0) {
      this.jobT = 1.2;
      this.jobs.refresh(this.world, this.desig, this.realNow, this.canHaul(), this.jobExt());
    }

    this.updateWolfSpawns();
    this.updateDeerSpawns();
    this.updateBoarSpawns();
    this.updateBearSpawns();

    // режиссёр событий
    this.evDirector.update(this, dtG);

    this.saveT -= dtReal;
    if (this.saveT <= 0) {
      this.saveT = 30;
      if (this.autosaveHook) this.autosaveHook(this);
    }
  }

  // Арбалетные башни: сами находят врага в радиусе и бьют болтами
  private updateTurrets(dtG: number) {
    for (const b of this.world.buildings) {
      if (b.blueprint || b.type !== BType.Turret) continue;
      if ((b.turretCd ?? 0) > 0) {
        b.turretCd = Math.max(0, (b.turretCd ?? 0) - dtG);
        continue;
      }
      let best: Animal | null = null;
      let bd = Infinity;
      for (const a of this.animals) {
        if (a.dead || a.kind === 'trader') continue;
        const hostile = a.kind === 'wolf' || (a.kind === 'boar' && a.state === 'hunt') || (a.kind === 'bear' && a.state === 'hunt');
        if (!hostile) continue;
        const d = Math.max(Math.abs(a.x - (b.x + 0.5)), Math.abs(a.y - (b.y + 0.5)));
        if (d <= TURRET_RANGE && d < bd) {
          bd = d;
          best = a;
        }
      }
      if (!best) continue;
      b.turretCd = TURRET_CD;
      this.spawnArrow(b.x + 0.5, b.y + 0.5, best.x, best.y);
      this.damageAnimal(best, TURRET_DMG + this.rng.next() * TURRET_RAND);
    }
  }

  // ============ Шахтные экспедиции (отдельная локация с сюрпризами) ============

  // Игрок отправляет пешку в шахту: выбираем лучшего свободного шахтёра
  startExpedition(mineId: number): boolean {
    const mine = this.world.buildings.find((b) => b.id === mineId);
    if (!mine || mine.blueprint || mine.type !== BType.Mine) return false;
    if (this.expeditions.some((e) => e.mineId === mineId)) {
      this.events.log('Из этой шахты ещё не вернулся предыдущий отряд.', 'info');
      return false;
    }
    // лучший шахтёр: навык добычи, без груза, не в бою/сне/срыве, не под землёй
    let best: Pawn | null = null;
    let bl = -1;
    for (const p of this.pawns) {
      if (p.dead || p.underground) continue;
      if (p.state === 'sleep' || p.state === 'fight' || p.state === 'flee' || p.state === 'break' || p.state === 'eat') continue;
      if (p.inv) continue;
      const lvl = p.skillLvl('mine');
      // в простое — приоритет, чтобы не срывать важную работу
      const idleBonus = p.state === 'idle' ? 5 : 0;
      if (lvl + idleBonus > bl) {
        bl = lvl + idleBonus;
        best = p;
      }
    }
    if (!best) {
      this.events.log('Нет свободного шахтёра: всем нужен отдых или руки заняты.', 'info');
      return false;
    }
    if (best.food < 25) {
      this.events.log(`${best.name} слишком голоден(на) для спуска — пусть поест.`, 'info');
      return false;
    }
    if (!startExpeditionWalk(this, best, mine)) {
      this.events.log('Путь к шахте отрезан — расчистите дорогу.', 'info');
      return false;
    }
    const exp: Expedition = {
      pawnId: best.id,
      mineId,
      stage: 0,
      tTotal: EXP_TOTAL,
      tLeft: EXP_TOTAL,
      nextEv: 0,
      log: [],
      loot: [],
    };
    this.expeditions.push(exp);
    if (!this.stats.firstExpedition) {
      this.stats.firstExpedition = true;
      this.events.log(`${best.name} впервые отправляется в глубины шахты. Там темно, тихо и... кто знает.`, 'story');
    } else {
      this.events.log(`${best.name} спускается в шахту с киркой и факелом.`, 'info');
    }
    return true;
  }

  private updateExpeditions(dtG: number) {
    if (dtG <= 0) return;
    for (const exp of [...this.expeditions]) {
      const pawn = this.pawns.find((p) => p.id === exp.pawnId);
      // пешка потеряна (сорвалась на еду/сон/бой по дороге) — экспедиция расформирована
      if (!pawn || pawn.dead) {
        this.expeditions = this.expeditions.filter((e) => e !== exp);
        if (pawn?.dead) this.events.log('Шахтёр пропал без вести. В глубинах темно и неспокойно...', 'bad');
        continue;
      }
      if (pawn.job?.kind !== 'expedition') {
        this.expeditions = this.expeditions.filter((e) => e !== exp);
        continue;
      }
      if (exp.stage === 0) {
        exp.stage = pawn.job.stage >= 1 ? 1 : 0;
        continue;
      }
      exp.tLeft -= dtG;
      // голодный шахтёр вылезает раньше времени
      if (pawn.food < 8) {
        exp.log.push({ text: 'Пустой желудок важнее жилы — поднялся(лась) наверх раньше срока.', kind: 'info' });
        this.finishExpedition(exp, 0.5);
        continue;
      }
      // сюрпризы на контрольных отметках
      while (exp.nextEv < EXP_CHECKPOINTS.length) {
        const cp = EXP_CHECKPOINTS[exp.nextEv];
        const done = 1 - exp.tLeft / exp.tTotal;
        if (done < cp) break;
        exp.nextEv++;
        this.fireExpeditionEvent(exp, pawn);
      }
      if (exp.tLeft <= 0) this.finishExpedition(exp, 1);
    }
  }

  // Сюрприз шахты: богатая жила, обвал, пещерный зверь, тайник, серебро, древние знаки
  private fireExpeditionEvent(exp: Expedition, pawn: Pawn) {
    const r = this.rng.next();
    const addLoot = (res: Res, qty: number) => {
      if (qty <= 0) return;
      const stack = exp.loot.find((l) => l.res === res);
      if (stack) stack.qty += qty;
      else exp.loot.push({ res, qty });
    };
    if (r < 0.22) {
      const qty = 5 + this.rng.int(0, 4);
      addLoot(Res.Iron, qty);
      exp.log.push({ text: `Богатая жила! Намолотили ${qty} железа сверх плана.`, kind: 'good' });
      this.events.log(`${pawn.name} наткнулся(лась) в шахте на богатую железную жилу.`, 'good');
    } else if (r < 0.37) {
      // обвал: тряска, камнепад — шахтёр цел, но тряхнуло (урон ограничен: под землёй не умираем)
      const dmg = Math.min(8 + this.rng.next() * 8, Math.max(2, pawn.hp - 8));
      pawn.hp = Math.max(2, pawn.hp - dmg);
      exp.log.push({ text: 'Обвал! Камни посыпались с перекрытия — еле увернулись.', kind: 'bad' });
      this.events.log(`В шахте грохнул обвал — ${pawn.name} чудом цел(а).`, 'bad');
    } else if (r < 0.51) {
      // пещерный зверь: оружие и навык решают
      const armed = pawn.weapon !== null;
      const brave = pawn.hasTrait('brave') || pawn.skillLvl('melee') >= 5;
      if (armed || (brave && this.rng.chance(0.6))) {
        addLoot(Res.Food, 3);
        exp.log.push({ text: 'В туннеле шипело что-то большое. Прогнали — на ужин осталось мясо.', kind: 'good' });
      } else {
        const dmg = Math.min(10 + this.rng.next() * 10, Math.max(2, pawn.hp - 8));
        pawn.hp = Math.max(2, pawn.hp - dmg);
        exp.log.push({ text: 'Кто-то схватил за ногу в темноте! Убежали, обронив часть добычи.', kind: 'bad' });
        this.events.log(`${pawn.name} встретил(а) в шахте пещерного зверя — еле ушёл(ла).`, 'bad');
      }
    } else if (r < 0.63) {
      addLoot(Res.Loot, 1);
      exp.log.push({ text: 'Заброшенный тайник старателей: кулёк припасов и странный свёрток.', kind: 'good' });
      this.events.log(`${pawn.name} нашёл(ла) в шахте заброшенный тайник!`, 'good');
    } else if (r < 0.75) {
      const qty = 2 + this.rng.int(0, 2);
      addLoot(Res.Silver, qty);
      exp.log.push({ text: `Серебряная ветвь в стене! ${qty} блестящих куска — торговцы будут в восторге.`, kind: 'story' });
      this.events.log(`${pawn.name} нашёл(ла) в шахте серебро!`, 'story');
      if (!this.stats.firstSilver) {
        this.stats.firstSilver = true;
      }
    } else if (r < 0.87) {
      exp.log.push({ text: 'Подземный ручей: холодная вода и эхо. Немного камня попутно.', kind: 'info' });
      addLoot(Res.Stone, 2);
    } else {
      for (const p of this.pawns) {
        if (!p.dead) p.addMod('discovery', 'Древние знаки', 4, 480, this.clock.totalMin);
      }
      exp.log.push({ text: 'Наскальные знаки древних людей. Колония будет вспоминать этот день.', kind: 'story' });
      this.events.log(`${pawn.name} нашёл(ла) в шахте древние наскальные знаки. Вся колония взволнована.`, 'story');
    }
  }

  // Возврат из глубин: пешка появляется у входа и выкладывает добычу
  private finishExpedition(exp: Expedition, yieldMult: number) {
    const pawn = this.pawns.find((p) => p.id === exp.pawnId);
    const mine = this.world.buildings.find((b) => b.id === exp.mineId);
    this.expeditions = this.expeditions.filter((e) => e !== exp);
    if (!pawn || !mine) return;
    pawn.underground = false;
    pawn.job = null;
    pawn.state = 'idle';
    pawn.path = null;
    const spot = freeSpotNear(this.world, mine.x, mine.y);
    pawn.x = spot.x + 0.5;
    pawn.y = spot.y + 0.5;
    // базовая добыча полной выработки
    const baseIron = Math.max(2, Math.round((3 + pawn.skillLvl('mine') * 0.5) * yieldMult));
    this.world.addItem(Res.Iron, baseIron, spot.x, spot.y);
    if (this.rng.chance(0.6)) {
      const stone = Math.max(1, Math.round(4 * yieldMult));
      this.world.addItem(Res.Stone, stone, spot.x, spot.y);
    }
    // накопленные сюрпризами трофеи (при раннем уходе — часть пропадает)
    for (const l of exp.loot) {
      if (l.qty <= 0) continue;
      const qty = l.qty >= 0 ? Math.max(0, Math.round(l.qty * (yieldMult >= 1 ? 1 : 0.5))) : 0;
      if (qty <= 0) continue;
      this.world.addItem(l.res, qty, spot.x, spot.y);
    }
    this.renderDirtyTile(spot.x, spot.y);
    pawn.addXp('mine', 6);
    const tail = exp.log.length > 0 ? ` Из глубин: «${exp.log[exp.log.length - 1].text}»` : '';
    this.events.log(`${pawn.name} поднялся(лась) на поверхность с ${baseIron} железа.${tail}`, 'story');
  }

  // ============ Погода и сезоны ============
  private updateWeather() {
    const day = this.clock.day;
    if (day !== this.weather.lastDay) {
      this.weather.lastDay = day;
      this.checkDayMilestone(day);
      this.checkSeason(day);
      const si = this.clock.seasonIdx;
      if (si === 2) {
        // зима: дождя нет — вместо него бураны
        this.weather.rain = false;
        if (this.rng.chance(BLIZZ_CHANCE)) {
          this.weather.blizzard = true;
          this.weather.blizzardUntil = this.clock.totalMin + this.rng.range(180, 300);
          this.events.log('Буран! Ветер гонит снег стеной — в такую пургу и волк не сунется, и работается плохо.', 'bad');
        }
      } else {
        this.weather.blizzard = false;
        const rainChance = si === 1 ? 0.4 : si === 3 ? 0.3 : 0.25; // осень промозглая, весна дождливая
        if (this.rng.chance(rainChance)) {
          this.weather.rain = true;
          this.weather.rainUntil = this.clock.totalMin + this.rng.range(180, 360);
          this.events.log('Начался дождь. Растения будут расти быстрее.', 'info');
        } else {
          this.weather.rain = false;
        }
      }
    }
    if (this.weather.rain && this.clock.totalMin > this.weather.rainUntil) {
      this.weather.rain = false;
      this.events.log('Дождь закончился.', 'info');
    }
    if (this.weather.blizzard && this.clock.totalMin > this.weather.blizzardUntil) {
      this.weather.blizzard = false;
      this.events.log('Буран стих. Снег ложится ровно и тихо.', 'info');
    }
  }

  // Смена сезона: записи в историю, миграция оленей, перекраска мира
  private checkSeason(day: number) {
    const si = this.clock.seasonIdx;
    if (si === this.seasonSeen) return;
    const firstLoad = this.seasonSeen === -1; // загрузка сейва — без записи, если сезон уже «видели»
    this.seasonSeen = si;
    if (firstLoad) return;
    this.fullRedrawFlag = true; // снег лёг / сошёл — перекрашиваем тайлы
    switch (si) {
      case 0:
        this.events.log('Вернулось лето. Тепло, ягода поспевает, трава растёт как на дрожжах.', 'story');
        break;
      case 1:
        this.events.log(`Наступила осень (день ${day}). Дожди чаще, трава растёт медленнее. Зима не за горами — пора делать запасы еды и дров.`, 'story');
        break;
      case 2: {
        const gone = this.animals.filter((a) => a.kind === 'deer').length;
        if (gone > 0) this.animals = this.animals.filter((a) => a.kind !== 'deer');
        this.events.log('Пришли холода. Первый снег лёг на траву. Олени ушли на юг, ягода уснула — теперь всё держится на запасах. Держитесь костра.', 'story');
        break;
      }
      case 3: {
        for (let i = 0; i < 3; i++) {
          for (let tries = 0; tries < 40; tries++) {
            const x = this.rng.int(3, MAP - 4);
            const y = this.rng.int(3, MAP - 4);
            if (this.world.passAnimal(x, y) && this.animalReachable(x, y)) {
              this.spawnAnimal('deer', x + 0.5, y + 0.5);
              break;
            }
          }
        }
        this.events.log('Весна. Снег сошёл, олени вернулись на поляны, земля снова принимает семена.', 'story');
        if (!this.stats.firstWinterSurvived) {
          this.stats.firstWinterSurvived = true;
          this.events.log('Колония пережила свою первую зиму. Осколок стал домом по-настоящему.', 'story');
          for (const p of this.pawns) {
            if (!p.dead) p.addMod('survivedWinter', 'Перезимовали!', 10, 1440, this.clock.totalMin);
          }
        }
        break;
      }
    }
  }

  // ============ Холод ============
  // Зимой ночью и в буран пешки на улице мёрзнут: настроение падает, HP тают.
  // Тепло: рядом с костром или в кровати (сон в укрытии).
  private updateCold(dtG: number) {
    if (dtG <= 0) return;
    const si = this.clock.seasonIdx;
    const night = this.clock.isNight;
    const bliz = this.weather.blizzard;
    const fires = this.world.campfires();
    for (const p of this.pawns) {
      if (p.dead) continue;
      const indoors = (p.state === 'sleep' && p.job && !p.job.ground) || p.underground; // в глубинах шахты не мёрзнут
      let warm = indoors;
      if (!warm) {
        for (const f of fires) {
          if (dist(p.x, p.y, f.x + 0.5, f.y + 0.5) <= FIRE_WARM_R) {
            warm = true;
            break;
          }
        }
      }
      const coatWarm = p.cloth === 'coat'; // тёплая куртка зиму не страшна
      const coldNow = si === 2 && (night || bliz) && !warm && !coatWarm;
      const chillNow = si === 1 && night && !warm && !coatWarm;
      p.noRegen = coldNow; // обморожение глушит ночную регенерацию
      if (coldNow) {
        if (!p.hasMod('cold')) p.addMod('cold', 'Мёрзнет', COLD_MOOD, 525600, this.clock.totalMin);
        p.hp = Math.max(0, p.hp - COLD_HP_RATE * dtG);
      } else if (p.hasMod('cold')) {
        p.removeMod('cold');
      }
      if (chillNow) {
        if (!p.hasMod('chill')) p.addMod('chill', 'Осенняя стужа', AUTUMN_MOOD, 525600, this.clock.totalMin);
      } else if (p.hasMod('chill')) {
        p.removeMod('chill');
      }
      // куртка радует: зимой и осенью одетый по погоде колонист доволен
      if (coatWarm && !coldNow && !chillNow && !p.hasMod('coatwarm') && (si === 1 || si === 2)) {
        p.addMod('coatwarm', 'Тёплая куртка', COAT_WARM_MOOD, 525600, this.clock.totalMin);
      } else if (p.hasMod('coatwarm') && si !== 1 && si !== 2) {
        p.removeMod('coatwarm');
      }
    }
  }

  // Замедление пешек: снег и буран
  walkPenalty(): number {
    if (this.weather.blizzard) return WALK_BLIZZARD;
    if (this.clock.isWinter) return WALK_WINTER;
    return 1;
  }

  // ============ Юбилейные вехи колонии ============
  private checkDayMilestone(day: number) {
    const TEXTS: Record<number, string> = {
      3: 'Третий день. Костёр ещё горит, руки не поддались страху. Осколок держится.',
      7: 'Неделя на осколке. Кажется, здесь можно жить.',
      14: 'Две недели. Это уже не лагерь — это дом.',
      21: 'Три недели. Лес начал обходить колонию стороной.',
      30: 'Месяц. Об этом месте будут рассказывать у чужих костров.',
    };
    const text = TEXTS[day];
    if (!text || this.stats.milestones[day]) return;
    this.stats.milestones[day] = true;
    for (const p of this.pawns) {
      if (!p.dead) p.addMod('jubilee', 'Юбилей колонии', 4, 960, this.clock.totalMin);
    }
    this.events.log(text, 'story');
  }

  // ============ Рост растений ============
  private updateGrowth(dtG: number) {
    this.growthAcc += dtG;
    if (this.growthAcc < 2) return;
    const step = this.growthAcc;
    this.growthAcc = 0;
    const si = this.clock.seasonIdx;
    const sf = si === 2 ? 0 : si === 1 ? 0.7 : si === 3 ? 1.2 : 1; // зимой рост стоит, весна бодрит
    const rate = (step / (1440 * 2)) * (this.weather.rain ? 1.5 : 1) * sf;
    const regrowStep = sf === 0 ? 0 : step; // зимой ягода не восстанавливается
    const w = this.world;
    for (let i = 0; i < w.zone.length; i++) {
      if (w.berryRegrow[i] > 0 && regrowStep > 0) {
        w.berryRegrow[i] = Math.max(0, w.berryRegrow[i] - regrowStep);
        if (w.berryRegrow[i] === 0 && this.dirtyTiles.size < 200) {
          this.dirtyTiles.add(i);
        }
      }
      if (w.zone[i] === Zone.Farm && w.farmStage[i] === FarmStage.Planted) {
        w.farmGrowth[i] = Math.min(1, w.farmGrowth[i] + rate);
        if (w.farmGrowth[i] >= 1) {
          w.farmStage[i] = FarmStage.Ready;
          this.dirtyTiles.add(i);
        }
      }
    }
  }

  private updateCorpses(dtG: number) {
    for (const it of [...this.world.items]) {
      if (it.type === Res.Corpse && it.decay !== undefined) {
        it.decay -= dtG;
        if (it.decay <= 0) this.world.removeItem(it);
      }
    }
  }

  private updateRelations(dtG: number) {
    this.relT += dtG;
    if (this.relT < 2) return;
    this.relT = 0;
    const alive = this.pawns.filter((p) => !p.dead);
    for (let i = 0; i < alive.length; i++) {
      for (let j = i + 1; j < alive.length; j++) {
        const a = alive[i];
        const b = alive[j];
        if (a.state === 'idle' && b.state === 'idle') continue;
        if (dist(a.x, a.y, b.x, b.y) < 4) this.addRelation(a.id, b.id, 1);
      }
    }
  }

  addRelation(aId: number, bId: number, delta: number) {
    const key = aId < bId ? `${aId}:${bId}` : `${bId}:${aId}`;
    let r = this.relations.get(key);
    if (!r) {
      r = { a: Math.min(aId, bId), b: Math.max(aId, bId), score: 0, friends: false };
      this.relations.set(key, r);
    }
    const before = r.score;
    r.score = Math.max(-100, Math.min(100, r.score + delta));
    if (before < 25 && r.score >= 25 && !r.friends) {
      r.friends = true;
      const a = this.pawns.find((p) => p.id === r!.a);
      const b = this.pawns.find((p) => p.id === r!.b);
      if (a && b) this.events.log(`${a.name} и ${b.name} стали друзьями.`, 'good');
    }
    if (before < 60 && r.score >= 60 && !r.close) {
      r.close = true;
      const a = this.pawns.find((p) => p.id === r!.a);
      const b = this.pawns.find((p) => p.id === r!.b);
      if (a && b) this.events.log(`${a.name} и ${b.name} стали неразлучными. Их не разлей вода.`, 'story');
    }
  }

  relationPairs(pawnId: number): { other: number; score: number }[] {
    const out: { other: number; score: number }[] = [];
    for (const r of this.relations.values()) {
      if (r.a === pawnId) out.push({ other: r.b, score: r.score });
      else if (r.b === pawnId) out.push({ other: r.a, score: r.score });
    }
    return out;
  }

  private checkDiscoveries() {
    const w = this.world;
    for (let i = 0; i < w.obj.length; i++) {
      if (w.obj[i] === Obj.RuinWall && w.visible[i] && !this.discoveredRuins.has(i)) {
        // помечаем весь участок
        this.discoveredRuins.add(i);
        if (this.discoveredRuins.size === 1) {
          this.events.log('В лесу обнаружена старая постройка. Стоит осмотреть...', 'story');
        }
      }
    }
  }

  // Веха: вся колония впервые спит под крышей (в кроватях)
  private checkRoofNight() {
    if (!this.clock.isNight) return;
    const alive = this.pawns.filter((p) => !p.dead);
    if (alive.length === 0) return;
    const allInBeds = alive.every((p) => p.state === 'sleep' && p.job && !p.job.ground);
    if (!allInBeds) return;
    // ночь 22:00→06:00 может пересекать полночь — считаем одну «ночь» по сдвинутой дате
    const nightId = Math.floor((this.clock.totalMin + 120) / 1440);
    if (this.lastRoofNightId === nightId) return;
    this.lastRoofNightId = nightId;
    this.stats.nightsUnderRoof++;
    if (this.stats.nightsUnderRoof === 1) {
      this.events.log('Впервые вся колония спит под крышей. Пусть волки воют сколько хотят.', 'story');
    }
  }

  private updateWolfSpawns() {
    const h = this.clock.hour;
    const m = this.clock.minute;
    const day = this.clock.day;
    if (h === 22 && m < 4 && this.lastWolfNight !== day) {
      this.lastWolfNight = day;
      if (this.animals.some((a) => a.kind === 'wolf')) return;
      if (!this.rng.chance(nightWolfChance(day) * this.wolfBonus * (this.clock.isWinter ? WOLF_WINTER_MULT : 1))) return;
      this.wolfBonus = 1; // бонус сгорает за ночь
      const winter = this.clock.isWinter;
      const siege = day >= 4 || (winter && day >= 3); // зимой голодные волки штурмуют раньше
      const n = (day >= 8 ? 3 : day >= 4 ? 2 : 1) + (winter ? 1 : 0);
      let spawned = 0;
      for (let i = 0; i < n; i++) {
        // спавн у края карты
        for (let tries = 0; tries < 40; tries++) {
          const side = this.rng.int(0, 3);
          const x = side === 0 ? 1 : side === 1 ? MAP - 2 : this.rng.int(1, MAP - 2);
          const y = side === 2 ? 1 : side === 3 ? MAP - 2 : this.rng.int(1, MAP - 2);
          if (this.world.passAnimal(x, y) && this.animalReachable(x, y)) {
            const a = this.spawnAnimal('wolf', x + 0.5, y + 0.5);
            a.siege = siege;
            a.state = siege ? 'siege' : 'wander';
            spawned++;
            break;
          }
        }
      }
      if (spawned > 0) {
        if (siege) {
          this.raiseAlarm(180);
          this.events.log('Стая идёт на лагерь! Волки чуют еду и не отступят — нужны стены и крепкие руки.', 'bad');
        } else {
          this.events.log('Вой волка разносится над лагерем...', 'bad');
        }
      }
    }
  }

  // ============ Боевая тревога ============
  raiseAlarm(min: number) {
    if (min > this.alarmMin) this.alarmMin = min;
    // настройка «автопауза на тревогу»: штурм останавливает время, игрок успевает подготовиться
    if (this.gameSettings.autopauseAlarm && this.clock.speed > 0 && !this.gameOver) this.setSpeed(0);
  }

  private allClear() {
    for (const p of this.pawns) {
      if (!p.dead) p.addMod('safe', 'Опасность миновала', 3, 480, this.clock.totalMin);
    }
    this.events.log('Тревога отступила. Волки ушли в лес.', 'good');
  }

  // Днём изредка приходят новые олени — дичь возобновляема
  private updateDeerSpawns() {
    const h = this.clock.hour;
    const m = this.clock.minute;
    const day = this.clock.day;
    if (h !== 11 || m >= 4 || this.lastDeerDay === day) return;
    this.lastDeerDay = day;
    const deerCount = this.animals.filter((a) => a.kind === 'deer').length;
    if (deerCount >= 3 || !this.rng.chance(0.35)) return;
    for (let i = 0; i < 2; i++) {
      for (let tries = 0; tries < 30; tries++) {
        const side = this.rng.int(0, 3);
        const x = side === 0 ? 2 : side === 1 ? MAP - 3 : this.rng.int(2, MAP - 3);
        const y = side === 2 ? 2 : side === 3 ? MAP - 3 : this.rng.int(2, MAP - 3);
        if (this.world.passAnimal(x, y) && this.animalReachable(x, y)) {
          this.spawnAnimal('deer', x + 0.5, y + 0.5);
          break;
        }
      }
    }
    this.events.log('В лесу показались олени. Удачная охота даст много мяса.', 'info');
  }

  // Кабаны: дичь возобновляемая — изредка приходят новые, если в лесу тихо
  private updateBoarSpawns() {
    const h = this.clock.hour;
    const m = this.clock.minute;
    const day = this.clock.day;
    if (h !== 10 || m >= 4 || this.lastBoarDay === day) return;
    this.lastBoarDay = day;
    const n = this.animals.filter((a) => a.kind === 'boar').length;
    if (n >= BOAR_MAX || !this.rng.chance(BOAR_SPAWN_CHANCE)) return;
    for (let i = 0; i < 2 && n + i < BOAR_MAX; i++) {
      for (let tries = 0; tries < 30; tries++) {
        const side = this.rng.int(0, 3);
        const x = side === 0 ? 2 : side === 1 ? MAP - 3 : this.rng.int(2, MAP - 3);
        const y = side === 2 ? 2 : side === 3 ? MAP - 3 : this.rng.int(2, MAP - 3);
        if (this.world.passAnimal(x, y) && this.animalReachable(x, y)) {
          this.spawnAnimal('boar', x + 0.5, y + 0.5);
          break;
        }
      }
    }
    this.events.log('В чаще слышно хрюканье: в лесу бродят кабаны. Мясо и шкуры — но не зля их зря.', 'info');
  }

  // Медведь — редкий гость: чаще всего лес пуст, но...
  private updateBearSpawns() {
    const h = this.clock.hour;
    const m = this.clock.minute;
    const day = this.clock.day;
    if (h !== 15 || m >= 4 || this.lastBearDay === day) return;
    this.lastBearDay = day;
    if (this.animals.some((a) => a.kind === 'bear')) return;
    if (!this.rng.chance(BEAR_SPAWN_CHANCE)) return;
    for (let tries = 0; tries < 40; tries++) {
      const x = this.rng.int(3, MAP - 4);
      const y = this.rng.int(3, MAP - 4);
      const far = Math.hypot(x - this.spawnX, y - this.spawnY) > 12;
      if (far && this.world.passAnimal(x, y) && this.animalReachable(x, y)) {
        this.spawnAnimal('bear', x + 0.5, y + 0.5);
        this.events.log('Трещат сучья — по лесу бродит медведь. К нему лучше не подходить без брони.', 'bad');
        break;
      }
    }
  }

  // ============ Урон и смерть ============
  damagePawn(pawn: Pawn, dmg: number, by?: Animal) {
    if (pawn.dead) return;
    // броня гасит часть урона зверей (RimWorld: броня — разница между жизнью и могилой)
    if (pawn.armor === 'iron') dmg *= IRON_ARMOR_MULT;
    else if (pawn.armor === 'leather') dmg *= LEATHER_ARMOR_MULT;
    pawn.hp -= dmg;
    if (by && pawn.state === 'sleep') {
      pawn.state = 'idle';
      pawn.job = null;
    }
    if (pawn.hp <= 0) {
      this.killPawn(pawn);
      return;
    }
    if (this.hurtLogCd <= 0 && by) {
      this.hurtLogCd = 12;
      const who = by.name === 'Волк' ? 'волком' : by.name === 'Кабан' ? 'кабаном' : by.name === 'Медведь' ? 'медведем' : 'зверём';
      this.events.log(`${pawn.name} ранен(а) ${who}!`, 'bad');
    }
    // Ответный отпор: раненый зверем человек не умирает молча — вооружённый бьёт в ответ,
    // безоружный бросается прочь. «Пережил встречу» остаётся в памяти и настроении.
    if (by && !by.dead && pawn.state !== 'fight' && pawn.state !== 'flee' && pawn.state !== 'sleep' && !pawn.underground) {
      if (pawn.weapon && !pawn.hasTrait('coward')) startFight(this, pawn, by.id);
      else startFlee(this, pawn);
      pawn.addMod('survived', 'Пережил(а) встречу со зверем', -4, 600, this.clock.totalMin);
    }
  }

  private killPawn(pawn: Pawn) {
    pawn.dead = true;
    pawn.hp = 0;
    releaseBoardJob(this, pawn);
    pawn.state = 'idle';
    pawn.path = null;
    // оружие и одежда падают на землю — их подберут выжившие
    if (pawn.weapon) {
      this.world.addItem(WEAPON_RES[pawn.weapon], 1, Math.floor(pawn.x), Math.floor(pawn.y));
      pawn.weapon = null;
    }
    if (pawn.cloth) {
      this.world.addItem(Res.Coat, 1, Math.floor(pawn.x), Math.floor(pawn.y));
      pawn.cloth = null;
    }
    if (pawn.armor) {
      this.world.addItem(pawn.armor === 'iron' ? Res.IronArmor : Res.LeatherArmor, 1, Math.floor(pawn.x), Math.floor(pawn.y));
      pawn.armor = null;
    }
    if (pawn.inv) {
      this.world.addItem(pawn.inv.type as Res, pawn.inv.qty, Math.floor(pawn.x), Math.floor(pawn.y));
      pawn.inv = null;
    }
    const x = Math.floor(pawn.x);
    const y = Math.floor(pawn.y);
    const corpse = this.world.addItem(Res.Corpse, 1, x, y);
    corpse.decay = 2880;
    corpse.name = pawn.name;
    this.events.log(`${pawn.name} погиб(ла). Колония скорбит...`, 'bad');
    for (const other of this.pawns) {
      if (other === pawn || other.dead) continue;
      other.addMod('grief', 'Погиб товарищ', -18, 2880, this.clock.totalMin);
      this.addRelation(other.id, pawn.id, -8);
    }
    const alive = this.pawns.filter((p) => !p.dead);
    if (alive.length === 0) {
      this.gameOver = true;
      this.events.log(`Колония пала. Прожито дней: ${this.clock.day}.`, 'bad');
    }
    if (this.autosaveHook) this.autosaveHook(this);
  }

  damageAnimal(a: Animal, dmg: number, byPawnId?: number) {
    if (a.dead) return;
    a.hp -= dmg;
    if (a.hp <= 0) {
      const yieldN = a.kind === 'wolf' ? YIELDS.wolf : a.kind === 'deer' ? YIELDS.deer : a.kind === 'boar' ? YIELDS.boar : a.kind === 'bear' ? YIELDS.bear : YIELDS.rabbit;
      const hides = HIDE_YIELDS[a.kind] ?? 0;
      const x = Math.floor(a.x);
      const y = Math.floor(a.y);
      this.world.addItem(Res.Food, yieldN, x, y);
      if (hides > 0) this.world.addItem(Res.Hide, hides, x, y);
      if (a.kind === 'wolf') {
        this.stats.wolvesKilled++;
        this.events.log('Волк убит! Колония в безопасности... пока.', 'good');
      } else if (a.kind === 'deer') {
        this.events.log('Олень добыт — будет много мяса!', 'good');
      } else if (a.kind === 'boar') {
        this.events.log('Кабан повержен! Мяса на неделю вперёд и крепкие шкуры.', 'good');
      } else if (a.kind === 'bear') {
        this.events.log('Медведь побеждён! Такое случается раз в жизни: мясо и лучшие шкуры в колонии.', 'story');
      } else {
        this.events.log('Кролик добыт — будет мясо.', 'info');
      }
      this.removeAnimal(a);
      return;
    }
    // кабан взбешён: бьёт обидчика и не отступает; сородичи рядом тоже свирепеют
    if (a.kind === 'boar' && byPawnId !== undefined) {
      a.state = 'hunt';
      a.targetPawnId = byPawnId;
      a.path = null;
      for (const b of this.animals) {
        if (b === a || b.dead || b.kind !== 'boar' || b.state === 'hunt') continue;
        if (dist(b.x, b.y, a.x, a.y) < 8) {
          b.state = 'hunt';
          b.targetPawnId = byPawnId;
          b.path = null;
        }
      }
      this.events.log('Кабан взбешён — он идёт на обидчика!', 'bad');
      return;
    }
    // медведь мстительный: гонится за обидчиком
    if (a.kind === 'bear' && byPawnId !== undefined && a.state !== 'flee') {
      a.state = 'hunt';
      a.targetPawnId = byPawnId;
      a.path = null;
      this.events.log('Медведь разъярён! Бегите к костру или защищайтесь.', 'bad');
      return;
    }
    // олень ранен — паническое бегство
    if (a.kind === 'deer' && a.state !== 'flee') {
      a.state = 'flee';
      a.targetPawnId = null;
      const ex = a.x < MAP / 2 ? 1 : MAP - 2;
      const ey = a.y < MAP / 2 ? 1 : MAP - 2;
      const tx = Math.abs(a.x - ex) < Math.abs(a.y - ey) ? ex : Math.max(1, Math.min(MAP - 2, Math.floor(a.x) + (a.x < ex ? -6 : 6)));
      const ty = Math.abs(a.x - ex) < Math.abs(a.y - ey) ? Math.max(1, Math.min(MAP - 2, Math.floor(a.y) + (a.y < ey ? -6 : 6))) : ey;
      a.path = this.edgePath(a, tx, ty);
      a.pathI = 0;
    }
    if (a.kind === 'bear' && a.hp < a.maxHp * 0.12 && a.state !== 'flee') {
      // совсем плох — медведь отступает: победа всё равно за колонией (шкура осталась)
      a.state = 'flee';
      a.targetPawnId = null;
      const ex = a.x < MAP / 2 ? 1 : MAP - 2;
      const ey = a.y < MAP / 2 ? 1 : MAP - 2;
      const tx = Math.abs(a.x - ex) < Math.abs(a.y - ey) ? ex : Math.floor(a.x);
      const ty = Math.abs(a.x - ex) < Math.abs(a.y - ey) ? Math.floor(a.y) : ey;
      a.path = this.edgePath(a, tx, ty);
      a.pathI = 0;
    }
    if (a.kind === 'wolf') {
      if (a.hp < a.maxHp * 0.3 && a.state !== 'flee') {
        a.state = 'flee';
        a.targetPawnId = null;
        // бежать к ближайшему краю
        const ex = a.x < MAP / 2 ? 1 : MAP - 2;
        const ey = a.y < MAP / 2 ? 1 : MAP - 2;
        const tx = Math.abs(a.x - ex) < Math.abs(a.y - ey) ? ex : Math.floor(a.x);
        const ty = Math.abs(a.x - ex) < Math.abs(a.y - ey) ? Math.floor(a.y) : ey;
        a.path = this.edgePath(a, tx, ty);
        a.pathI = 0;
      } else if (byPawnId !== undefined && a.state === 'hunt') {
        a.targetPawnId = byPawnId;
      }
      // стая: сородичи рядом бросаются на обидчика
      if (byPawnId !== undefined) {
        for (const w of this.animals) {
          if (w === a || w.dead || w.kind !== 'wolf' || w.state === 'flee') continue;
          if (dist(w.x, w.y, a.x, a.y) < 9) {
            w.state = 'hunt';
            w.targetPawnId = byPawnId;
            w.path = null;
          }
        }
      }
    }
  }

  private edgePath(a: Animal, tx: number, ty: number): { x: number; y: number }[] | null {
    // простая линия к краю
    const path: { x: number; y: number }[] = [];
    const steps = 30;
    for (let i = 1; i <= steps; i++) {
      path.push({
        x: Math.max(0, Math.min(MAP - 1, Math.round(a.x + (tx - a.x) * (i / steps)))),
        y: Math.max(0, Math.min(MAP - 1, Math.round(a.y + (ty - a.y) * (i / steps)))),
      });
    }
    return path;
  }

  damageBuilding(b: Building, dmg: number, by?: Animal) {
    if (b.blueprint) {
      this.world.removeBuilding(b);
      return;
    }
    b.hp -= dmg;
    // волки грызут постройку — колония поднимает тревогу
    if (by && by.kind === 'wolf') {
      this.raiseAlarm(120);
      if (this.alarmLogCd <= 0) {
        this.alarmLogCd = 30;
        const label = BUILDINGS[b.type].name.toLowerCase();
        const acc = label === 'стена' ? 'стену' : label; // винительный падеж
        this.events.log(`Волки грызут ${acc}! ${this.pawns.some((p) => p.hasTrait('brave') && !p.dead) ? 'Смелые бросаются на защиту.' : 'Защитите лагерь!'}`, 'bad');
      }
    }
    if (b.hp <= 0) {
      this.world.removeBuilding(b);
      this.dirtyTiles.add(this.world.idx(b.x, b.y));
      const label = BUILDINGS[b.type].name.toLowerCase();
      this.events.log(`Волк проломил ${label === 'стена' ? 'стену' : label}!`, 'bad');
      void by;
    }
  }

  completeBuilding(b: Building, by?: Pawn) {
    if (!b.blueprint) return;
    completeBuildingInternal(b);
    this.stats.built++;
    this.dirtyTiles.add(this.world.idx(b.x, b.y));
    if (by) by.addXp('build');
    if (!this.stats.firstBuilt[b.type]) {
      this.stats.firstBuilt[b.type] = true;
      this.events.log(`Построено первое сооружение: ${BUILDINGS[b.type].name.toLowerCase()}.`, 'good');
    }
  }

  renderDirtyTile(x: number, y: number) {
    this.dirtyTiles.add(this.world.idx(x, y));
    for (let dy = -1; dy <= 1; dy++)
      for (let dx = -1; dx <= 1; dx++) {
        const nx = x + dx;
        const ny = y + dy;
        if (this.world.inBounds(nx, ny)) this.dirtyTiles.add(this.world.idx(nx, ny));
      }
  }

  desigClear(kind: 'chop' | 'mine' | 'harvest', tile: number) {
    this.desig[kind][tile] = 0;
  }

  // ============ Приказы игрока ============
  applyTap(wx: number, wy: number) {
    const x = Math.floor(wx);
    const y = Math.floor(wy);
    if (!this.world.inBounds(x, y)) return;
    const t = this.tool;
    if (t === 'attack') {
      // найти зверя рядом с тапом
      let best: Animal | null = null;
      let bd = 2.2;
      for (const a of this.animals) {
        const d = dist(wx, wy, a.x, a.y);
        if (d < bd) {
          bd = d;
          best = a;
        }
      }
      if (best) {
        this.attackTargetId = best.id;
        this.events.log(`Колония атакует: ${best.name}!`, 'info');
      } else {
        this.attackTargetId = null;
      }
      return;
    }
    if (t === 'hunt') {
      // пометить зверя для охоты (повторный тап снимает метку)
      let best: Animal | null = null;
      let bd = 2.2;
      for (const a of this.animals) {
        if (a.kind === 'trader') continue; // караванщика не трогаем
        const d = dist(wx, wy, a.x, a.y);
        if (d < bd) {
          bd = d;
          best = a;
        }
      }
      if (best) this.toggleHunt(best.id);
      return;
    }
    if (t === 'chop' || t === 'mine' || t === 'harvest') {
      this.designateOne(t, x, y);
      return;
    }
    const bt = TOOL_BTYPE[t];
    if (bt !== undefined) {
      this.placeBlueprintAt(bt, x, y);
      return;
    }
    if (t === 'stockpile' || t === 'farm') {
      this.setZoneOne(t, x, y);
      return;
    }
    // inspect: выбор
    this.selectAt(wx, wy);
  }

  applyRect(x0: number, y0: number, x1: number, y1: number) {
    const ax = Math.max(0, Math.min(x0, x1));
    const bx = Math.max(0, Math.max(x0, x1));
    const ay = Math.max(0, Math.min(y0, y1));
    const by = Math.max(0, Math.max(y0, y1));
    const t = this.tool;
    if (t === 'chop' || t === 'mine' || t === 'harvest') {
      for (let y = ay; y <= by; y++) for (let x = ax; x <= bx; x++) this.designateOne(t, x, y);
      return;
    }
    if (t === 'hunt') {
      // рамкой помечаем сразу всё стадо, попавшее в неё
      let n = 0;
      for (const a of this.animals) {
        if (a.kind === 'trader' || a.dead) continue;
        if (a.x >= ax && a.x <= bx + 1 && a.y >= ay && a.y <= by + 1) {
          if (!this.huntList.has(a.id)) {
            this.huntList.add(a.id);
            n++;
          }
        }
      }
      if (n > 0) this.events.log(`Для охоты помечено зверей: ${n}.`, 'info');
      return;
    }
    if (t === 'wall') {
      for (let y = ay; y <= by; y++) for (let x = ax; x <= bx; x++) this.placeBlueprintAt(BType.Wall, x, y);
      return;
    }
    if (t === 'stockpile' || t === 'farm') {
      for (let y = ay; y <= by; y++) for (let x = ax; x <= bx; x++) this.setZoneOne(t, x, y);
      return;
    }
    this.applyTap((ax + bx) / 2 + 0.5, (ay + by) / 2 + 0.5);
  }

  private designateOne(t: 'chop' | 'mine' | 'harvest', x: number, y: number) {
    const i = this.world.idx(x, y);
    if (t === 'chop') {
      if (this.world.obj[i] === Obj.Tree || this.world.obj[i] === Obj.BerryBush) {
        this.desig.chop[i] = 1;
        this.dirtyTiles.add(i);
      }
    } else if (t === 'mine') {
      // валун, любая руда или сплошная скала (вгрызаемся в гору)
      if (this.world.isMineable(x, y)) {
        this.desig.mine[i] = 1;
        this.dirtyTiles.add(i);
      }
    } else {
      const bush = this.world.obj[i] === Obj.BerryBush && this.world.berryRegrow[i] <= 0;
      const crop = this.world.zone[i] === Zone.Farm && this.world.farmStage[i] === FarmStage.Ready;
      if (bush || crop) {
        this.desig.harvest[i] = 1;
        this.dirtyTiles.add(i);
      }
    }
  }

  placeBlueprintAt(type: BType, x: number, y: number) {
    const i = this.world.idx(x, y);
    if (this.world.terrain[i] === Terrain.Water) return;
    // шахта строится только на горной скале — в ней вечная руда
    if (type === BType.Mine && this.world.terrain[i] !== Terrain.Stone) {
      this.events.log('Шахту можно заложить только на серой горной скале — ищите горы.', 'info');
      return;
    }
    // куст мешает стройке — убирается автоматически
    if (this.world.obj[i] === Obj.BerryBush) {
      this.world.obj[i] = Obj.None;
      this.world.berryRegrow[i] = 0;
      this.dirtyTiles.add(i);
    }
    // валун на скале не помеха шахте — расчищается при стройке (руда — не трогаем, её копают)
    if (type === BType.Mine && this.world.obj[i] === Obj.Rock) {
      this.world.obj[i] = Obj.None;
      this.dirtyTiles.add(i);
    }
    if (this.world.obj[i] !== Obj.None) return;
    if (this.world.buildingMap.has(i)) return;
    if (this.world.zone[i] !== Zone.None) return;
    const b = createBlueprint(type, x, y);
    this.world.placeBuilding(b);
    this.dirtyTiles.add(i);
  }

  private setZoneOne(t: 'stockpile' | 'farm', x: number, y: number) {
    const i = this.world.idx(x, y);
    if (this.world.terrain[i] === Terrain.Water) return;
    // куст мешает зоне — убирается автоматически
    if (this.world.obj[i] === Obj.BerryBush) {
      this.world.obj[i] = Obj.None;
      this.world.berryRegrow[i] = 0;
      this.dirtyTiles.add(i);
    }
    if (this.world.obj[i] !== Obj.None) return;
    if (this.world.buildingMap.has(i)) return;
    if (this.world.zone[i] !== Zone.None) return;
    const kind: Zone = t === 'stockpile' ? Zone.Stockpile : Zone.Farm;
    // Примыкание (RimWorld-стиль): клетка вплотную к зоне того же типа — расширяет её,
    // в стороне — создаёт НОВУЮ зону со своим названием и настройками.
    let zid = 0;
    for (let dy = -1; dy <= 1 && zid === 0; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        if (dx === 0 && dy === 0) continue;
        const nx = x + dx;
        const ny = y + dy;
        if (!this.world.inBounds(nx, ny)) continue;
        const ni = this.world.idx(nx, ny);
        if (this.world.zone[ni] === kind && this.world.zoneId[ni] !== 0) {
          zid = this.world.zoneId[ni];
          break;
        }
      }
    }
    if (zid === 0) {
      const zd = this.world.createZone(t as ZoneKind);
      if (!zd) return; // предел числа зон
      zid = zd.id;
    }
    this.world.zone[i] = kind;
    this.world.zoneId[i] = zid;
    this.dirtyTiles.add(i);
  }

  cancelAt(wx: number, wy: number) {
    const x = Math.floor(wx);
    const y = Math.floor(wy);
    if (!this.world.inBounds(x, y)) return;
    const i = this.world.idx(x, y);
    let did = false;
    if (this.desig.chop[i]) {
      this.desig.chop[i] = 0;
      this.jobs.removeByTile('chop', i);
      did = true;
    }
    if (this.desig.mine[i]) {
      this.desig.mine[i] = 0;
      this.jobs.removeByTile('mine', i);
      did = true;
    }
    if (this.desig.harvest[i]) {
      this.desig.harvest[i] = 0;
      this.jobs.removeByTile('harvest', i);
      did = true;
    }
    const b = this.world.buildingMap.get(i);
    if (b && b.blueprint) {
      this.world.removeBuilding(b);
      this.jobs.removeByTile('build', i);
      did = true;
    }
    if (this.world.zone[i] !== Zone.None) {
      const z = this.world.zone[i];
      const zid = this.world.zoneId[i];
      this.world.zone[i] = Zone.None;
      this.world.zoneId[i] = 0;
      this.world.deleteZoneIfEmpty(zid);
      if (z === Zone.Farm) this.world.farmStage[i] = 0;
      did = true;
    }
    if (did) this.dirtyTiles.add(i);
  }

  selectAt(wx: number, wy: number) {
    // пешка?
    let best: Pawn | null = null;
    let bd = 1.2;
    for (const p of this.pawns) {
      if (p.dead) continue;
      const d = dist(wx, wy, p.x, p.y);
      if (d < bd) {
        bd = d;
        best = p;
      }
    }
    if (best) {
      this.selectedPawnId = best.id;
      this.selectedInfo = null;
      return;
    }
    // зверь?
    let bestA: Animal | null = null;
    bd = 1.5;
    for (const a of this.animals) {
      const d = dist(wx, wy, a.x, a.y);
      if (d < bd) {
        bd = d;
        bestA = a;
      }
    }
    if (bestA) {
      this.selectedPawnId = null;
      const lines: string[] = [`Здоровье: ${Math.ceil(bestA.hp)}/${bestA.maxHp}`];
      if (bestA.kind !== 'trader') {
        // подсказка, чем добывать эту дичь
        const fast = bestA.kind === 'deer' || bestA.kind === 'rabbit';
        lines.push(fast ? 'Убегает — нужен охотник с луком' : 'Опасная дичь: лучше оружие в руках');
        // удар хищника — чтобы игрок знал, чем рискует
        const atk = PREDATOR_STATS[bestA.kind];
        if (atk) lines.push(atk);
      }
      if (this.huntList.has(bestA.id)) lines.push('Помечен(а) для охоты 🎯');
      this.selectedInfo = {
        title: bestA.name,
        lines: bestA.kind === 'trader' ? ['Караванщика можно поторговать, пока он у лагеря'] : lines,
        tile: -1,
        canCancel: false,
        canTrade: bestA.kind === 'trader',
        huntId: bestA.kind === 'trader' ? undefined : bestA.id,
        hunting: this.huntList.has(bestA.id),
      };
      return;
    }
    // постройка / клетка
    const x = Math.floor(wx);
    const y = Math.floor(wy);
    const i = this.world.idx(x, y);
    const b = this.world.buildingMap.get(i);
    this.selectedPawnId = null;
    const lines: string[] = [];
    let canCancel = false;
    let prodBId: number | undefined;
    let prodKind: 'bench' | 'fire' | undefined;
    let mineBId: number | undefined;
    if (b) {
      lines.push(`Прочность: ${Math.ceil(b.hp)}/${b.maxHp}`);
      if (b.blueprint) {
        lines.push(`Материалы: ${b.matHave}/${b.matNeed}`);
        canCancel = true;
      }
      if (b.type === BType.Bed && b.ownerId !== null) {
        const owner = this.pawns.find((p) => p.id === b.ownerId);
        if (owner) lines.push(`Хозяин: ${owner.name}`);
      }
      if (b.type === BType.Grave && b.graveName) {
        lines.push(`Здесь покоится: ${b.graveName}`);
      }
      if (b.type === BType.Workbench && !b.blueprint) {
        const left = (b.bills ?? []).reduce((s, bl) => s + Math.max(0, bl.count - bl.done), 0);
        lines.push(left > 0 ? `В заказах осталось изделий: ${left}` : 'Заказов нет — назначьте через меню');
        prodBId = b.id;
        prodKind = 'bench';
      }
      if (b.type === BType.Campfire && !b.blueprint) {
        lines.push(`Похлёбки в колонии: ${this.world.countRes(Res.Meal)} · цель варки: ${b.mealTarget ?? 8}`);
        prodBId = b.id;
        prodKind = 'fire';
      }
      if (b.type === BType.Mine && !b.blueprint) {
        const exp = this.expeditions.find((e) => e.mineId === b.id);
        if (exp) {
          const p2 = this.pawns.find((p) => p.id === exp.pawnId);
          lines.push(`В глубинах: ${p2?.name ?? 'шахтёр'} (${Math.round((1 - exp.tLeft / exp.tTotal) * 100)}%)`);
        } else {
          lines.push('Вход в подземелье. Отсюда уходят экспедиции за рудой');
        }
        mineBId = b.id;
      }
      if (b.type === BType.Turret && !b.blueprint) {
        lines.push('Сама бьёт по волкам в радиусе 5 клеток');
      }
      this.selectedInfo = { title: BUILDINGS[b.type].name + (b.blueprint ? ' (чертёж)' : ''), lines, tile: i, canCancel, prodBId, prodKind, mineBId };
      return;
    }
    lines.push(this.world.tileName(x, y));
    if (this.desig.chop[i] || this.desig.mine[i] || this.desig.harvest[i]) canCancel = true;
    if (this.world.zone[i] !== Zone.None) canCancel = true;
    const items = this.world.itemsAt(x, y);
    let buryItemId: number | undefined;
    for (const it of items) {
      if (it.type === Res.Corpse) {
        lines.push(`Тело: ${it.name ?? 'неизвестный'}`);
        buryItemId = it.id;
      } else {
        lines.push(`${RES_INFO[it.type as Res]?.name ?? 'Предмет'} ×${it.qty}`);
        // статы предмета: урон оружия, защита брони, сытость еды
        const st = ITEM_STATS[it.type as Res];
        if (st) lines.push(st);
      }
    }
    // зона с настройками: имя + номер клетки (для кнопки «Настройки»)
    let zoneId: number | undefined;
    const zd = this.world.zoneDefOf(i);
    if (this.world.zone[i] === Zone.Stockpile) {
      lines.push(`Склад «${zd?.name ?? 'Склад'}»`);
      if (zd) zoneId = zd.id;
    }
    if (this.world.zone[i] === Zone.Farm) {
      const st = this.world.farmStage[i] as FarmStage;
      lines.push(`Ферма «${zd?.name ?? 'Ферма'}»`);
      lines.push(['', 'Грядка вспахана', 'Посажено (растёт)', 'Урожай созрел!'][st] || 'Грядка');
      if (zd) zoneId = zd.id;
    }
    this.selectedInfo = { title: `${x}:${y}`, lines, tile: i, canCancel, buryItemId, zoneId };
  }

  // Приказ «Похоронить» — игрок нажимает кнопку в окне тела
  orderBurial(itemId: number): boolean {
    const item = this.world.items.find((it) => it.id === itemId && it.type === Res.Corpse);
    if (!item) return false;
    if (this.jobs.hasJob('bury', item.id)) return false;
    this.jobs.add('bury', this.world.idx(item.x, item.y), item.id, item.id);
    this.events.log(`Колония решила похоронить ${item.name ?? 'погибшего'}...`, 'info');
    return true;
  }

  // Случайная живая пешка (для событий)
  randomAlivePawn(): Pawn | null {
    const alive = this.pawns.filter((p) => !p.dead);
    if (alive.length === 0) return null;
    return alive[Math.floor(this.rng.next() * alive.length)];
  }

  // Игрок выбрал вариант в событии — применяем последствия
  resolveChoice(idx: number) {
    if (!this.pendingChoice) return;
    this.evDirector.resolve(this, idx);
  }

  clearSelection() {
    this.selectedPawnId = null;
    this.selectedInfo = null;
  }

  // ============ Настройки зон (RimWorld-стиль) ============
  // Снимок зоны для модалки настроек
  zoneSettings(id: number) {
    const zd = this.world.zoneDefs.get(id);
    if (!zd) return null;
    let tiles = 0;
    let ready = 0;
    const stored = new Map<Res, number>();
    for (let i = 0; i < this.world.zoneId.length; i++) {
      if (this.world.zoneId[i] !== id) continue;
      tiles++;
      if (zd.kind === 'farm' && this.world.farmStage[i] === FarmStage.Ready) ready++;
      for (const it of this.world.itemsAt(i % MAP, (i / MAP) | 0)) {
        stored.set(it.type, (stored.get(it.type) ?? 0) + it.qty);
      }
    }
    return {
      id: zd.id,
      kind: zd.kind,
      name: zd.name,
      tiles,
      ready,
      filters: STOCKPILE_RES.map((r) => ({ res: r as number, name: RES_INFO[r].name, icon: RES_INFO[r].icon, allowed: zd.filters[r] })),
      stored: [...stored.entries()].map(([r, qty]) => ({ icon: RES_INFO[r].icon, name: RES_INFO[r].name, qty })),
    };
  }

  renameZone(id: number, name: string) {
    const zd = this.world.zoneDefs.get(id);
    if (!zd) return;
    const clean = name.trim().slice(0, 24);
    zd.name = clean.length > 0 ? clean : zd.name;
  }

  // Фильтр склада: принимать ли ресурс. Уже лежащее лежит, но переносится прочь.
  setZoneFilter(id: number, res: number, allowed: boolean) {
    const zd = this.world.zoneDefs.get(id);
    if (!zd || res < 0 || res >= zd.filters.length) return;
    zd.filters[res] = allowed;
  }

  // Удалить зону целиком: клетки очищаются, предметы остаются на земле
  deleteZone(id: number) {
    const zd = this.world.zoneDefs.get(id);
    if (!zd) return;
    for (let i = 0; i < this.world.zoneId.length; i++) {
      if (this.world.zoneId[i] !== id) continue;
      this.world.zone[i] = Zone.None;
      this.world.zoneId[i] = 0;
      if (zd.kind === 'farm') {
        this.world.farmStage[i] = 0;
        this.world.farmGrowth[i] = 0;
      }
      this.dirtyTiles.add(i);
    }
    this.world.zoneDefs.delete(id);
    if (this.settingsZoneId === id) this.settingsZoneId = null;
    this.events.log(`Зона «${zd.name}» убрана.`, 'info');
  }

  // Список зон для интерфейса
  zonesList(): { id: number; kind: string; name: string; tiles: number }[] {
    const out: { id: number; kind: string; name: string; tiles: number }[] = [];
    for (const zd of this.world.zoneDefs.values()) {
      let tiles = 0;
      for (let i = 0; i < this.world.zoneId.length; i++) if (this.world.zoneId[i] === zd.id) tiles++;
      out.push({ id: zd.id, kind: zd.kind, name: zd.name, tiles });
    }
    return out.sort((a, b) => a.id - b.id);
  }

  // ============ Производство: заказы на верстаке и варка на костре ============

  // Снимок панели производства (открыта через prodOpenId)
  productionPanel() {
    if (this.prodOpenId === null) return null;
    const b = this.world.buildings.find((bb) => bb.id === this.prodOpenId);
    if (!b || b.blueprint) return null;
    if (b.type === BType.Workbench) {
      return {
        kind: 'bench' as const,
        id: b.id,
        bills: (b.bills ?? []).map((bl, idx) => {
          const rec = RECIPES[bl.recipe];
          const cost = rec
            ? `${rec.wood > 0 ? `🪵${rec.wood} ` : ''}${rec.iron > 0 ? `🔩${rec.iron} ` : ''}${rec.hide > 0 ? `🟤${rec.hide}` : ''}`.trim()
            : '';
          return { idx, recipe: bl.recipe, name: rec?.name ?? '?', icon: rec ? RES_INFO[rec.res].icon : '❓', cost, count: bl.count, done: bl.done, stat: rec ? ITEM_STATS[rec.res] ?? null : null };
        }),
      };
    }
    if (b.type === BType.Campfire) {
      return { kind: 'fire' as const, id: b.id, meals: this.world.countRes(Res.Meal), target: b.mealTarget ?? 8 };
    }
    return null;
  }

  // Добавить заказ на верстак: рецепт и количество
  addBill(bId: number, recipe: number, count: number) {
    const b = this.world.buildings.find((bb) => bb.id === bId);
    if (!b || b.type !== BType.Workbench || !RECIPES[recipe]) return;
    if (!b.bills) b.bills = [];
    b.bills.push({ recipe, count: Math.max(1, Math.min(99, count)), done: 0 });
    const rec = RECIPES[recipe];
    this.events.log(`Заказ на верстаке: ${rec.name} ×${count}.`, 'info');
  }

  removeBill(bId: number, index: number) {
    const b = this.world.buildings.find((bb) => bb.id === bId);
    if (!b?.bills || index < 0 || index >= b.bills.length) return;
    b.bills.splice(index, 1);
  }

  // Цель варки на костре: до скольких порций похлёбки варить (0 — не варить)
  setMealTarget(fireId: number, target: number) {
    const b = this.world.buildings.find((bb) => bb.id === fireId);
    if (!b || b.type !== BType.Campfire) return;
    b.mealTarget = Math.max(0, Math.min(60, target));
    this.events.log(b.mealTarget === 0 ? 'Варка похлёбки отключена.' : `Цель варки: держать ${b.mealTarget} порций похлёбки.`, 'info');
  }

  // ============ Караваны и торговля ============

  // Приход каравана (вызывается режиссёром событий)
  spawnCaravan() {
    if (this.animals.some((a) => a.kind === 'trader' && !a.dead)) return;
    for (let tries = 0; tries < 60; tries++) {
      const side = this.rng.int(0, 3);
      const x = side === 0 ? 2 : side === 1 ? MAP - 3 : this.rng.int(2, MAP - 3);
      const y = side === 2 ? 2 : side === 3 ? MAP - 3 : this.rng.int(2, MAP - 3);
      if (!this.world.passAnimal(x, y)) continue;
      const t = this.spawnAnimal('trader', x + 0.5, y + 0.5);
      t.state = 'arrive';
      this.openCaravan(t);
      this.events.log('Из-за холмов показался торговый караван — идёт к лагерю с товарами.', 'story');
      return;
    }
  }

  // Ассортимент каравана: случайные товары и цены с разбросом
  private openCaravan(t: Animal) {
    const goods: TradeState['goods'] = [];
    const pool = [...TRADE_SELL];
    const n = this.rng.int(4, 6);
    for (let i = 0; i < n && pool.length > 0; i++) {
      const idx = this.rng.int(0, pool.length - 1);
      const def = pool.splice(idx, 1)[0];
      goods.push({ res: def.res, qty: this.rng.int(def.qty[0], def.qty[1]), price: def.price });
    }
    const sell: TradeState['sell'] = [];
    for (const key of Object.keys(TRADE_BUY)) {
      const res = Number(key) as Res;
      const base = TRADE_BUY[res] ?? 1;
      sell.push({ res, price: Math.max(1, Math.round(base * this.rng.range(0.75, 1.3))) });
    }
    this.trade = { traderId: t.id, goods, sell };
  }

  // Караван ушёл/ушатан — торговля закрыта
  closeTrade(traderId: number) {
    if (this.trade?.traderId === traderId) this.trade = null;
  }

  // Снимок панели торговли
  tradePanel() {
    if (!this.trade) return null;
    const goods = this.trade.goods
      .map((g, idx) => ({ idx, res: g.res as number, icon: RES_INFO[g.res].icon, name: RES_INFO[g.res].name, qty: g.qty, price: g.price, stat: ITEM_STATS[g.res] ?? null }))
      .filter((g) => g.qty > 0);
    const sellable = this.trade.sell
      .map((s) => ({ res: s.res as number, icon: RES_INFO[s.res]?.icon ?? '❓', name: RES_INFO[s.res]?.name ?? '?', qty: this.world.countRes(s.res), price: s.price, stat: ITEM_STATS[s.res] ?? null }))
      .filter((s) => s.qty > 0);
    return { traderId: this.trade.traderId, silver: this.world.countRes(Res.Silver), goods, sellable };
  }

  // Купить товар у каравана (idx — позиция в trade.goods)
  buyGood(idx: number): boolean {
    if (!this.trade) return false;
    const g = this.trade.goods[idx];
    if (!g || g.qty <= 0) return false;
    if (this.world.countRes(Res.Silver) < g.price) {
      this.events.log('Серебра не хватает — торговец качает головой.', 'info');
      return false;
    }
    this.takeRes(Res.Silver, g.price);
    const c = this.world.stockpileCenter() ?? this.centerBase();
    const spot = freeSpotNear(this.world, Math.floor(c.x), Math.floor(c.y));
    this.world.addItem(g.res, 1, spot.x, spot.y);
    this.renderDirtyTile(spot.x, spot.y);
    g.qty--;
    this.events.log(`Куплено у каравана: ${RES_INFO[g.res].name} за ${g.price} 🪙.`, 'good');
    return true;
  }

  // Продать каравану ресурс (по текущей цене)
  sellRes(res: number, qty: number): boolean {
    if (!this.trade) return false;
    const entry = this.trade.sell.find((s) => s.res === res);
    if (!entry) return false;
    const take = Math.min(qty, this.world.countRes(res as Res));
    if (take <= 0) return false;
    this.takeRes(res as Res, take);
    const earned = entry.price * take;
    const c = this.world.stockpileCenter() ?? this.centerBase();
    const spot = freeSpotNear(this.world, Math.floor(c.x), Math.floor(c.y));
    this.world.addItem(Res.Silver, earned, spot.x, spot.y);
    this.renderDirtyTile(spot.x, spot.y);
    this.events.log(`Продано каравану: ${RES_INFO[res as Res]?.name ?? '?'} ×${take} за ${earned} 🪙.`, 'good');
    return true;
  }

  // Забрать количество ресурса из предметов мира (склад + земля)
  takeRes(res: Res, qty: number) {
    let need = qty;
    for (const it of [...this.world.items]) {
      if (it.type !== res || need <= 0) continue;
      const take = Math.min(it.qty, need);
      it.qty -= take;
      need -= take;
      if (it.qty <= 0) this.world.removeItem(it);
    }
  }

  // ============ Сохранение ============
  serialize(): SaveData {
    const w = this.world;
    return {
      v: 1,
      seed: this.seed,
      totalMin: this.clock.totalMin,
      terrain: w.terrain.slice(),
      obj: w.obj.slice(),
      objHp: w.objHp.slice(),
      zone: w.zone.slice(),
      zoneId: w.zoneId.slice(),
      zoneDefs: [...w.zoneDefs.values()].map((z) => ({ id: z.id, kind: z.kind, name: z.name, filters: [...z.filters] })),
      farmStage: w.farmStage.slice(),
      farmGrowth: w.farmGrowth.slice(),
      berryRegrow: w.berryRegrow.slice(),
      explored: w.explored.slice(),
      items: w.items.map((it) => ({ id: it.id, type: it.type, qty: it.qty, x: it.x, y: it.y, decay: it.decay, name: it.name })),
      buildings: w.buildings.map((b) => ({ ...b })),
      pawns: this.pawns.map((p) => ({
        id: p.id, name: p.name, gender: p.gender, age: p.age, traits: [...p.traits],
        x: p.x, y: p.y, hp: p.hp, food: p.food, rest: p.rest,
        skills: JSON.parse(JSON.stringify(p.skills)), priorities: [...p.priorities],
        inv: p.inv ? { ...p.inv } : null, bedId: p.bedId, dead: p.dead, weapon: p.weapon,
        cloth: p.cloth ?? null, armor: p.armor ?? null,
        mods: p.mods.map((m) => ({ ...m })), sickMin: p.sickMin,
        breakMin: p.breakMin, breakKind: p.breakKind, breakCd: p.breakCd,
      })),
      animals: this.animals.map((a) => ({ id: a.id, kind: a.kind, x: a.x, y: a.y, hp: a.hp, siege: a.siege || undefined })),
      events: this.events.entries.slice(-120).map((e) => ({ id: e.id, t: e.t, text: e.text, kind: e.kind })),
      nextEventId: this.events.nextIdValue,
      relations: [...this.relations.values()].map((r) => ({ ...r })),
      desig: { chop: this.desig.chop.slice(), mine: this.desig.mine.slice(), harvest: this.desig.harvest.slice() },
      weather: { ...this.weather },
      stats: JSON.parse(JSON.stringify(this.stats)),
      ev: { ...this.evDirector.state },
      npid: this.nextPawnId,
      nextItemId: w.nextItemId,
      nextAnimalId: this.nextAnimalId,
      lastWolfNight: this.lastWolfNight,
      alarmMin: this.alarmMin > 0 ? Math.round(this.alarmMin) : undefined,
      settings: { ...this.gameSettings },
      expeditions: this.expeditions.map((e) => ({ pawnId: e.pawnId, mineId: e.mineId, stage: e.stage, tTotal: e.tTotal, tLeft: Math.round(e.tLeft), nextEv: e.nextEv, log: e.log.map((l) => ({ ...l })), loot: e.loot.map((l) => ({ res: l.res as number, qty: l.qty })) })),
      trade: this.trade ? { traderId: this.trade.traderId, goods: this.trade.goods.map((g) => ({ res: g.res as number, qty: g.qty, price: g.price })), sell: this.trade.sell.map((s) => ({ res: s.res as number, price: s.price })) } : null,
      hunt: [...this.huntList],
      recipes: RECIPES.map((r) => ({ ...r })),
      gameOver: this.gameOver,
    };
  }

  applySave(d: SaveData) {
    const w = this.world;
    this.seed = d.seed;
    this.clock = new Clock();
    this.clock.totalMin = d.totalMin;
    w.terrain.set(d.terrain);
    w.obj.set(d.obj);
    w.objHp.set(d.objHp);
    w.zone.set(d.zone);
    w.resetZones();
    if (d.zoneId && d.zoneDefs) {
      // новый формат: реестр зон с настройками
      w.zoneId.set(d.zoneId);
      for (const zd of d.zoneDefs) {
        const filters = new Array(FILTER_LEN).fill(false);
        (zd.filters ?? []).forEach((v, k) => {
          if (k < FILTER_LEN) filters[k] = v;
        });
        // миграция старых сейвов: железо появилось позже — на существующих складах принимаем по умолчанию;
        // шкуры и одежда — новый блок: тоже разрешаем по умолчанию
        if ((zd.filters ?? []).length < FILTER_LEN) {
          filters[Res.Iron] = true;
          filters[Res.Hide] = true;
          filters[Res.Coat] = true;
          filters[Res.LeatherArmor] = true;
          filters[Res.IronArmor] = true;
        }
        // серебро — валюта караванов: на всех существующих складах включаем сразу
        filters[Res.Silver] = true;
        w.zoneDefs.set(zd.id, { id: zd.id, kind: zd.kind as ZoneKind, name: zd.name, filters });
      }
      w.nextZoneId = Math.max(1, ...d.zoneDefs.map((z) => z.id)) + 1;
    } else {
      // миграция старых сейвов: одна безымянная зона на тип
      for (let i = 0; i < w.zone.length; i++) {
        if (w.zone[i] !== Zone.Stockpile && w.zone[i] !== Zone.Farm) continue;
        const kind: ZoneKind = w.zone[i] === Zone.Stockpile ? 'stockpile' : 'farm';
        let zd = [...w.zoneDefs.values()].find((z) => z.kind === kind);
        if (!zd) zd = w.createZone(kind)!;
        w.zoneId[i] = zd.id;
      }
    }
    w.farmStage.set(d.farmStage);
    w.farmGrowth.set(d.farmGrowth);
    w.berryRegrow.set(d.berryRegrow);
    w.explored.set(d.explored);
    w.visible.fill(0);
    w.items = [];
    w.itemMap.clear();
    for (const it of d.items) {
      const item = { ...it, type: it.type as Res };
      w.items.push(item);
      const i = w.idx(item.x, item.y);
      if (!w.itemMap.has(i)) w.itemMap.set(i, []);
      w.itemMap.get(i)!.push(item);
    }
    w.buildings = d.buildings.map((b) => ({ ...b }));
    w.buildingMap.clear();
    for (const b of w.buildings) w.buildingMap.set(w.idx(b.x, b.y), b);
    let maxBId = 0;
    for (const b of w.buildings) maxBId = Math.max(maxBId, b.id);
    resetBuildingIds(maxBId + 1);
    w.nextItemId = Math.max(1, ...d.items.map((it) => it.id)) + 1;
    // миграция: верстаки без заказов и костры без цели варки (новые механики)
    for (const b of w.buildings) {
      if (b.type === BType.Workbench && !b.bills) b.bills = defaultBills();
      if (b.type === BType.Campfire && b.mealTarget === undefined) b.mealTarget = 8;
    }

    this.pawns = d.pawns.map((ps) => {
      const p = new Pawn(ps.id as number, ps.name as string, ps.x as number, ps.y as number, 0, ps.traits as string[], ps.gender as 'м' | 'ж', ps.age as number);
      p.color = PAWN_COLORS[(p.id - 1) % PAWN_COLORS.length];
      p.hp = ps.hp as number;
      p.food = ps.food as number;
      p.rest = ps.rest as number;
      p.skills = ps.skills as Pawn['skills'];
      p.priorities = ps.priorities as WorkCat[];
      p.inv = ps.inv as Pawn['inv'];
      p.bedId = ps.bedId as number | null;
      p.dead = ps.dead as boolean;
      p.mods = (ps.mods as Pawn['mods']) ?? [];
      p.sickMin = (ps.sickMin as number) ?? 0;
      p.breakMin = (ps.breakMin as number) ?? 0;
      p.breakKind = (ps.breakKind as Pawn['breakKind']) ?? null;
      p.breakCd = (ps.breakCd as number) ?? 0;
      p.weapon = (ps.weapon as Pawn['weapon']) ?? null;
      p.cloth = (ps.cloth as Pawn['cloth']) ?? null;
      p.armor = (ps.armor as Pawn['armor']) ?? null;
      // миграция старых сейвов: новые навыки и категории работ
      for (const s of SKILLS) if (!p.skills[s.id]) p.skills[s.id] = { lvl: 0, xp: 0 };
      // старые расклады: готовка была в конце и никто не варил — поднимаем наверх;
      // охота — новая категория: ставим перед переноской
      if (!p.priorities.includes('hunt')) {
        const rest = p.priorities.filter((c) => c !== 'cook' && c !== 'haul');
        const haulIdx = p.priorities.indexOf('haul');
        const head: WorkCat[] = ['cook', ...rest];
        if (haulIdx >= 0) head.push('hunt', 'haul');
        else head.push('hunt');
        p.priorities = head;
      }
      for (const c of WORK_CATS) if (!p.priorities.includes(c.id)) p.priorities.push(c.id);
      return p;
    });
    this.animals = d.animals.map((as) => {
      const a = new Animal(as.id, as.kind as AnimalKind, as.x, as.y);
      a.hp = as.hp;
      a.siege = (as.siege as boolean) ?? false;
      return a;
    });
    this.nextAnimalId = Math.max(1, ...d.animals.map((a) => a.id)) + 1;
    // экспедиции: пешка либо в пути к шахте, либо под землёй — восстанавливаем её задачу
    this.expeditions = (d.expeditions ?? [])
      .map((e) => ({ pawnId: e.pawnId, mineId: e.mineId, stage: e.stage, tTotal: e.tTotal, tLeft: e.tLeft, nextEv: e.nextEv, log: e.log.map((l) => ({ text: l.text, kind: l.kind as Expedition['log'][number]['kind'] })), loot: e.loot.map((l) => ({ res: l.res as Res, qty: l.qty })) }))
      .filter((e) => this.pawns.some((p) => p.id === e.pawnId && !p.dead) && this.world.buildings.some((b) => b.id === e.mineId && b.type === BType.Mine));
    for (const e of this.expeditions) {
      const pawn = this.pawns.find((p) => p.id === e.pawnId);
      const mine = this.world.buildings.find((b) => b.id === e.mineId);
      if (pawn && mine) resumeExpedition(this, pawn, mine, e.stage);
    }
    this.trade = d.trade ? { traderId: d.trade.traderId, goods: d.trade.goods.map((g) => ({ res: g.res as Res, qty: g.qty, price: g.price })), sell: d.trade.sell.map((s) => ({ res: s.res as Res, price: s.price })) } : null;
    if (this.trade && !this.animals.some((a) => a.id === this.trade!.traderId && a.kind === 'trader')) this.trade = null;
    // охота: помеченные звери, выжившие после загрузки
    this.huntList = new Set((d.hunt ?? []).filter((id) => this.animals.some((a) => a.id === id)));
    this.events.restore(
      d.events.map((e) => ({ ...e, kind: e.kind as 'info' | 'good' | 'bad' | 'story' })),
      d.nextEventId,
    );
    this.relations.clear();
    for (const r of d.relations) this.relations.set(`${r.a}:${r.b}`, { ...r });
    this.desig = { chop: new Uint8Array(d.desig.chop), mine: new Uint8Array(d.desig.mine), harvest: new Uint8Array(d.desig.harvest) };
    this.weather = { rain: false, rainUntil: 0, lastDay: 1, blizzard: false, blizzardUntil: 0, ...d.weather };
    this.seasonSeen = this.clock.seasonIdx; // сезон уже «видели» — без повторной записи
    const st = JSON.parse(JSON.stringify(d.stats));
    this.stats = {
      treesChopped: 0, rocksMined: 0, harvests: 0, built: 0, firstBuilt: {}, wolvesKilled: 0,
      nightsUnderRoof: 0, lastRoofNight: 0, milestones: {}, ...st,
    };
    if (d.ev) this.evDirector.state = { ...this.evDirector.state, ...d.ev };
    this.nextPawnId = d.npid ?? Math.max(3, ...this.pawns.map((p) => p.id)) + 1;
    this.lastWolfNight = d.lastWolfNight;
    this.alarmMin = (d.alarmMin as number) ?? 0;
    if (d.settings) this.gameSettings = { ...DEFAULT_SETTINGS, ...d.settings };
    // каталог рецептов (админ-редактор): заменяем содержимое на месте, ссылки живут
    if (d.recipes && Array.isArray(d.recipes)) {
      RECIPES.length = 0;
      for (const r of d.recipes) {
        RECIPES.push({ id: r.id, res: r.res, name: r.name, work: r.work, wood: r.wood, iron: r.iron, hide: r.hide });
      }
    }
    this.gameOver = d.gameOver;
    // стартовая точка
    const sc = w.stockpileCenter();
    if (sc) {
      this.spawnX = sc.x;
      this.spawnY = sc.y;
    }
    this.fullRedrawFlag = true;
    this.dirtyTiles.clear();
    this.jobs.refresh(this.world, this.desig, this.realNow, this.canHaul(), this.jobExt());
  }

  // ============ Снимок для UI ============
  uiSnapshot() {
    const alive = this.pawns.filter((p) => !p.dead);
    return {
      day: this.clock.day,
      hhmm: this.clock.hhmm,
      night: this.clock.isNight,
      light: this.clock.light,
      speed: this.clock.speed,
      tool: this.tool,
      rain: this.weather.rain,
      season: this.clock.seasonName,
      seasonIcon: this.clock.seasonIcon,
      winter: this.clock.isWinter,
      blizzard: this.weather.blizzard,
      wood: this.world.countRes(Res.Wood),
      stone: this.world.countRes(Res.Stone),
      food: this.world.countRes(Res.Food),
      meals: this.world.countRes(Res.Meal),
      iron: this.world.countRes(Res.Iron),
      seed: this.seed,
      gameOver: this.gameOver,
      pawns: this.pawns.map((p) => ({
        id: p.id,
        name: p.name,
        color: p.color,
        dead: p.dead,
        sick: p.sickMin > 0,
        weapon: p.weapon,
        cloth: p.cloth,
        armor: p.armor,
        action: p.dead ? 'Погиб(ла)' : activityOf(this, p),
        hp: p.hp,
        food: p.food,
        rest: p.rest,
        mood: moodList(this, p).reduce((s, m) => s + m.delta, 50),
        breaking: p.breakMin > 0,
      })),
      selected: this.selectedPawnId !== null ? this.pawnDetail(this.selectedPawnId) : null,
      info: this.selectedInfo,
      choice: this.pendingChoice,
      attackTargetId: this.attackTargetId,
      followId: this.followId,
      settings: { ...this.gameSettings },
      wolves: this.animals.filter((a) => a.kind === 'wolf').length,
      alarm: this.alarmMin > 0,
      aliveCount: alive.length,
      zoneSettings: this.settingsZoneId !== null ? this.zoneSettings(this.settingsZoneId) : null,
      silver: this.world.countRes(Res.Silver),
      expeditions: this.expeditions.map((e) => {
        const p = this.pawns.find((q) => q.id === e.pawnId);
        const mine = this.world.buildings.find((b) => b.id === e.mineId);
        return {
          mineId: e.mineId,
          minePos: mine ? { x: mine.x, y: mine.y } : null,
          pawnName: p?.name ?? '?',
          pawnColor: p?.color ?? '#fff',
          stage: e.stage,
          progress: Math.max(0, Math.min(1, 1 - e.tLeft / e.tTotal)),
          lastText: e.log.length > 0 ? e.log[e.log.length - 1].text : 'Пока тихо... только стук кирки.',
          lastKind: e.log.length > 0 ? e.log[e.log.length - 1].kind : 'info',
        };
      }),
      prod: this.productionPanel(),
      trade: this.tradePanel(),
    };
  }

  pawnDetail(id: number) {
    const p = this.pawns.find((pp) => pp.id === id);
    if (!p) return null;
    return {
      id: p.id,
      name: p.name,
      gender: p.gender,
      age: p.age,
      color: p.color,
      traits: p.traits,
      action: activityOf(this, p),
      weapon: p.weapon,
      weaponName: p.weapon ? WEAPON_NAMES[p.weapon] : null,
      weaponIcon: p.weapon ? WEAPON_ICONS[p.weapon] : null,
      weaponStats: p.weapon ? weaponStatLine(p.weapon) : null,
      cloth: p.cloth,
      armor: p.armor,
      armorName: p.armor ? ARMOR_NAMES[p.armor] : null,
      armorIcon: p.armor ? ARMOR_ICONS[p.armor] : null,
      armorStats: p.armor ? armorStatLine(p.armor) : null,
      sick: p.sickMin > 0,
      hp: p.hp,
      food: p.food,
      rest: p.rest,
      mood: moodList(this, p).reduce((s, m) => s + m.delta, 50),
      mods: moodList(this, p),
      skills: SKILLS.map((s) => ({ id: s.id, name: s.name, lvl: p.skills[s.id].lvl })),
      priorities: [...p.priorities],
      relations: this.relationPairs(p.id)
        .map((r) => ({ name: this.pawns.find((pp) => pp.id === r.other)?.name ?? '?', score: r.score }))
        .sort((a, b) => b.score - a.score),
      carrying: p.inv ? { type: p.inv.type as number, qty: p.inv.qty } : null,
    };
  }

  reorderPriority(pawnId: number, index: number, dir: -1 | 1) {
    const p = this.pawns.find((pp) => pp.id === pawnId);
    if (!p) return;
    const ni = index + dir;
    if (ni < 0 || ni >= p.priorities.length) return;
    const arr = [...p.priorities];
    [arr[index], arr[ni]] = [arr[ni], arr[index]];
    p.priorities = arr;
  }

  centerBase(): { x: number; y: number } {
    const c = this.world.stockpileCenter();
    return c ?? { x: this.spawnX, y: this.spawnY };
  }

  campfires(): { x: number; y: number }[] {
    return this.world.campfires();
  }

  setSpeed(s: 0 | 1 | 2 | 4 | 8 | 16) {
    this.clock.speed = s;
    // Пауза НЕ перезаписывает сохранение: игрок должен иметь возможность
    // «сохранился → поиграл → на паузу → загрузился» и вернуться к своей сейв-точке.
  }

  peekNextItemId(): number {
    void this;
    return 0;
  }

  peekBId(): number {
    return peekBuildingId();
  }
}

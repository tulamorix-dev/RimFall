// Журнал историй колонии: важные события записываются и показываются как тосты

export type EventKind = 'info' | 'good' | 'bad' | 'story';

export interface LogEntry {
  id: number;
  t: number; // игровое время (минуты с начала)
  text: string;
  kind: EventKind;
}

export class EventLog {
  entries: LogEntry[] = [];
  private nextId = 1;
  timeProvider: () => number = () => 0;
  onEvent: ((e: LogEntry) => void) | null = null;

  log(text: string, kind: EventKind = 'info'): LogEntry {
    const e: LogEntry = { id: this.nextId++, t: this.timeProvider(), text, kind };
    this.entries.push(e);
    if (this.entries.length > 300) this.entries.splice(0, this.entries.length - 300);
    if (this.onEvent) this.onEvent(e);
    return e;
  }

  restore(entries: LogEntry[], nextId: number) {
    this.entries = entries;
    this.nextId = nextId;
  }

  // Новая партия: чистый журнал, но хуки (время/тосты) сохраняются
  reset() {
    this.entries = [];
    this.nextId = 1;
  }

  get nextIdValue(): number {
    return this.nextId;
  }
}

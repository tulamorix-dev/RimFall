// Игровые часы: сутки, часы, скорости, освещённость

import { DAWN_H, DAY_H, EVENING_H, NIGHT_H, MIN_PER_SEC, SEASON_DAYS, SEASONS } from '../data/defs';
import { clamp, lerp } from './util';

export class Clock {
  totalMin = 7 * 60; // старт: День 1, 07:00
  speed: 0 | 1 | 2 | 4 | 8 | 16 = 1;

  tick(dtReal: number) {
    if (this.speed > 0) this.totalMin += dtReal * MIN_PER_SEC * this.speed;
  }

  get day(): number {
    return Math.floor(this.totalMin / 1440) + 1;
  }
  get hour(): number {
    return Math.floor((this.totalMin % 1440) / 60);
  }
  get minute(): number {
    return Math.floor(this.totalMin % 60);
  }
  get hhmm(): string {
    const h = this.hour.toString().padStart(2, '0');
    const m = this.minute.toString().padStart(2, '0');
    return `${h}:${m}`;
  }

  // ---- Сезоны: год 24 дня, сезон 6 дней (0 лето, 1 осень, 2 зима, 3 весна) ----
  get seasonIdx(): 0 | 1 | 2 | 3 {
    return Math.floor(((this.day - 1) % (SEASON_DAYS * 4)) / SEASON_DAYS) as 0 | 1 | 2 | 3;
  }
  get seasonName(): string {
    return SEASONS[this.seasonIdx].name;
  }
  get seasonIcon(): string {
    return SEASONS[this.seasonIdx].icon;
  }
  get isWinter(): boolean {
    return this.seasonIdx === 2;
  }
  get isNight(): boolean {
    const h = (this.totalMin % 1440) / 60;
    return h >= NIGHT_H || h < DAWN_H;
  }

  // 0 = глухая ночь, 1 = полный день
  get light(): number {
    const h = (this.totalMin % 1440) / 60;
    if (h >= DAY_H && h < EVENING_H) return 1;
    if (h >= DAWN_H && h < DAY_H) return lerp(0.15, 1, (h - DAWN_H) / (DAY_H - DAWN_H)); // рассвет
    if (h >= EVENING_H && h < NIGHT_H) return lerp(1, 0.25, (h - EVENING_H) / (NIGHT_H - EVENING_H)); // закат
    if (h >= NIGHT_H) return lerp(0.25, 0, (h - NIGHT_H) / 2);
    return lerp(0, 0.15, h / DAWN_H); // глубокая ночь -> начало рассвета
  }

  // Альфа затемнения экрана ночью
  get nightAlpha(): number {
    return clamp((1 - this.light) * 0.82, 0, 0.82);
  }
}

// Детерминированный ГСЧ и value-noise для процедурной генерации

export class RNG {
  private s: number;
  constructor(seed: number) {
    this.s = seed >>> 0;
  }
  next(): number {
    let t = (this.s += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }
  int(min: number, max: number): number {
    return Math.floor(this.range(min, max + 1));
  }
  chance(p: number): boolean {
    return this.next() < p;
  }
  pick<T>(arr: T[]): T {
    return arr[Math.floor(this.next() * arr.length)];
  }
}

// Сглаженный value-noise (билинейная интерполяция + smoothstep)
function hash2(seed: number, x: number, y: number): number {
  let h = seed ^ Math.imul(x, 374761393) ^ Math.imul(y, 668265263);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

function smooth(t: number): number {
  return t * t * (3 - 2 * t);
}

export function valueNoise(seed: number, fx: number, fy: number, x: number, y: number): number {
  const x0 = Math.floor(x / fx);
  const y0 = Math.floor(y / fy);
  const tx = smooth((x / fx) - x0);
  const ty = smooth((y / fy) - y0);
  const a = hash2(seed, x0, y0);
  const b = hash2(seed, x0 + 1, y0);
  const c = hash2(seed, x0, y0 + 1);
  const d = hash2(seed, x0 + 1, y0 + 1);
  return a + (b - a) * tx + (c - a) * ty + (a - b - c + d) * tx * ty;
}

// Многооктавный шум
export function fbm(seed: number, x: number, y: number): number {
  let v = 0;
  v += 0.55 * valueNoise(seed, 11, 11, x, y);
  v += 0.30 * valueNoise(seed + 101, 6, 6, x, y);
  v += 0.15 * valueNoise(seed + 202, 3, 3, x, y);
  return v;
}

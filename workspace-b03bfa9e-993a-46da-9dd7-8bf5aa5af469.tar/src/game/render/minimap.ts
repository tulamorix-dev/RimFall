// Мини-карта: территория, вода, постройки, пешки, враги

import { MAP, Obj, Zone, Terrain, BType } from '../data/defs';
import type { Game } from '../core/game';
import type { Camera } from './camera';

const MINI_COLORS: Record<number, string> = {
  [Terrain.Grass]: '#3f6636',
  [Terrain.Dirt]: '#6b573c',
  [Terrain.Water]: '#2b5a7a',
  [Terrain.Stone]: '#5c5e63',
  [Terrain.Forest]: '#2e4d29',
  [Terrain.Rock]: '#3c3e44',
};

// Зимние цвета миникарты (снег и лёд)
const MINI_WINTER: Record<number, string> = {
  [Terrain.Grass]: '#aeb9bd',
  [Terrain.Dirt]: '#9aa5a8',
  [Terrain.Water]: '#7c9cb4',
  [Terrain.Stone]: '#8a8f96',
  [Terrain.Forest]: '#8fa094',
  [Terrain.Rock]: '#6e7278',
};

export class Minimap {
  canvas: HTMLCanvasElement;
  game: Game;
  cam: Camera;
  private px = 2;

  constructor(canvas: HTMLCanvasElement, game: Game, cam: Camera) {
    this.canvas = canvas;
    this.game = game;
    this.cam = cam;
    canvas.width = MAP * this.px;
    canvas.height = MAP * this.px;
    canvas.addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      const rect = canvas.getBoundingClientRect();
      const fx = (e.clientX - rect.left) / rect.width;
      const fy = (e.clientY - rect.top) / rect.height;
      this.cam.x = fx * MAP * 32;
      this.cam.y = fy * MAP * 32;
      this.cam.clampToMap();
      this.cam.followId = null;
    });
  }

  draw() {
    const g = this.canvas.getContext('2d')!;
    const w = this.game.world;
    const p = this.px;
    const winter = this.game.clock.isWinter;
    const base = winter ? MINI_WINTER : MINI_COLORS;
    for (let y = 0; y < MAP; y++) {
      for (let x = 0; x < MAP; x++) {
        const i = y * MAP + x;
        g.fillStyle = base[w.terrain[i]] ?? '#333';
        const o = w.obj[i] as Obj;
        if (o === Obj.Tree) g.fillStyle = winter ? '#6d7f6a' : '#24401f';
        if (o === Obj.Ore) g.fillStyle = winter ? '#e8a54e' : '#e2913f'; // железная жила — ярко, чтобы найти
        if (o === Obj.SilverOre) g.fillStyle = '#eef1f5'; // серебро — белая искра на миникарте
        if (w.zone[i] === Zone.Stockpile) g.fillStyle = '#8a7a3a';
        if (w.zone[i] === Zone.Farm) g.fillStyle = '#5a452c';
        g.fillRect(x * p, y * p, p, p);
      }
    }
    // постройки
    for (const b of this.game.world.buildings) {
      if (b.blueprint) continue;
      g.fillStyle = b.type === BType.Campfire ? '#f5c542' : b.type === BType.StoneWall || b.type === BType.Grave ? '#9a9a94' : b.type === BType.Mine ? '#8a5a28' : '#c98a4a';
      g.fillRect(b.x * p, b.y * p, p, p);
    }
    // пешки
    for (const pn of this.game.pawns) {
      if (pn.dead) continue;
      g.fillStyle = '#ffffff';
      g.fillRect(Math.floor(pn.x) * p, Math.floor(pn.y) * p, p, p);
    }
    // звери
    for (const a of this.game.animals) {
      g.fillStyle = a.kind === 'wolf' ? '#ff4d3d' : a.kind === 'deer' ? '#c9955a' : a.kind === 'trader' ? '#d9b13f' : '#d8cfc0';
      g.fillRect(Math.floor(a.x) * p, Math.floor(a.y) * p, p, p);
    }
    // рамка камеры
    const scale = this.canvas.width / (MAP * 32);
    const cam = this.cam;
    const visW = (cam.lastViewW / cam.zoom) * scale;
    const visH = (cam.lastViewH / cam.zoom) * scale;
    g.strokeStyle = 'rgba(255,255,255,0.8)';
    g.lineWidth = 1;
    g.strokeRect(cam.x * scale - visW / 2, cam.y * scale - visH / 2, visW, visH);
  }
}

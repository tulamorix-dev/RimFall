// Рендерер Canvas2D: кэш террейна, ночь/свет, дождь, сущности, жесты

import { MAP, TILE, Obj, Zone, FarmStage, BType, BUILDINGS, Res, Tool, HUNT_MARKER } from '../data/defs';
import type { Game } from '../core/game';
import type { Pawn } from '../entities/pawn';
import type { Animal } from '../entities/animal';
import { Camera } from './camera';
import { clamp } from '../core/util';

const TERRAIN_COLORS: Record<number, [number, number, number]> = {
  0: [77, 124, 66], // трава
  1: [138, 111, 77], // земля
  2: [58, 124, 168], // вода
  3: [133, 135, 140], // камень
  4: [63, 107, 56], // лесная подстилка
  5: [86, 88, 94], // сплошная скала — тёмный монолит
};

function tileHash(i: number): number {
  let h = Math.imul(i + 1, 2654435761);
  h ^= h >>> 13;
  return (h >>> 0) / 4294967296;
}

// Оттенки складов: разные зоны — слегка разные цвета (5 вариантов по zoneId)
const STOCK_TINTS = [
  ['rgba(230,200,90,0.10)', 'rgba(230,200,90,0.5)'],
  ['rgba(215,160,85,0.11)', 'rgba(215,160,85,0.5)'],
  ['rgba(175,200,95,0.11)', 'rgba(175,200,95,0.5)'],
  ['rgba(225,175,125,0.11)', 'rgba(225,175,125,0.5)'],
  ['rgba(195,195,125,0.11)', 'rgba(195,195,125,0.5)'],
];

export class Renderer {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  game: Game;
  cam = new Camera();

  private terrain = document.createElement('canvas');
  private tctx: CanvasRenderingContext2D;
  private light = document.createElement('canvas');
  private lctx: CanvasRenderingContext2D;
  private dpr = 1;
  private viewW = 0;
  private viewH = 0;
  private time = 0;

  private rain: { x: number; y: number; s: number; l: number }[] = [];
  private raining = false;
  private snow: { x: number; y: number; s: number; r: number; ph: number }[] = [];
  private snowing = false;

  // кэш подписей зон (обновляется раз в полсекунды)
  private zLabels: { id: number; x: number; y: number; name: string; kind: string }[] = [];
  private zLabelsT = 0;

  // жесты
  private pointers = new Map<number, { x: number; y: number }>();
  private gesture: 'none' | 'maybePan' | 'panning' | 'maybeDrag' | 'dragging' | 'pinch' = 'none';
  private downX = 0;
  private downY = 0;
  private lastX = 0;
  private lastY = 0;
  private downT = 0;
  private pinchD0 = 0;
  private pinchZ0 = 1;
  private pinchMX = 0;
  private pinchMY = 0;
  private lastTapT = 0;
  private lastTapX = 0;
  private lastTapY = 0;
  rectStart: { x: number; y: number } | null = null;
  rectCur: { x: number; y: number } | null = null;

  private dragTools: Tool[] = ['chop', 'mine', 'harvest', 'wall', 'stockpile', 'farm'];

  constructor(canvas: HTMLCanvasElement, game: Game) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.game = game;
    this.terrain.width = MAP * TILE;
    this.terrain.height = MAP * TILE;
    this.tctx = this.terrain.getContext('2d')!;
    this.lctx = this.light.getContext('2d')!;
    this.attachInput();
    this.rebuildFull();
  }

  // ================= Террейн-кэш =================
  rebuildFull() {
    for (let i = 0; i < MAP * MAP; i++) this.drawTileCache(i);
    this.game.fullRedrawFlag = false;
    this.game.dirtyTiles.clear();
  }

  flushDirty() {
    if (this.game.fullRedrawFlag) {
      this.rebuildFull();
      return;
    }
    if (this.game.dirtyTiles.size === 0) return;
    for (const i of this.game.dirtyTiles) this.drawTileCache(i);
    this.game.dirtyTiles.clear();
  }

  private drawTileCache(i: number) {
    const w = this.game.world;
    const winter = this.game.clock.isWinter; // снежный покров на тайлах
    const x = (i % MAP) * TILE;
    const y = Math.floor(i / MAP) * TILE;
    const g = this.tctx;
    const [r, gr, bl] = TERRAIN_COLORS[w.terrain[i]] ?? TERRAIN_COLORS[0];
    const v = (tileHash(i) - 0.5) * 14;
    g.fillStyle = `rgb(${Math.round(r + v)},${Math.round(gr + v)},${Math.round(bl + v)})`;
    g.fillRect(x, y, TILE, TILE);

    const t = w.terrain[i];
    if (t === 2) {
      // берег
      g.strokeStyle = 'rgba(220,240,250,0.35)';
      g.lineWidth = 1.5;
      g.beginPath();
      const up = y > 0 ? w.terrain[i - MAP] : 2;
      const left = x > 0 ? w.terrain[i - 1] : 2;
      const right = x < MAP - 1 ? w.terrain[i + 1] : 2;
      const down = y < MAP - 1 ? w.terrain[i + MAP] : 2;
      if (up !== 2) {
        g.moveTo(x, y + 1);
        g.lineTo(x + TILE, y + 1);
      }
      if (down !== 2) {
        g.moveTo(x, y + TILE - 1);
        g.lineTo(x + TILE, y + TILE - 1);
      }
      if (left !== 2) {
        g.moveTo(x + 1, y);
        g.lineTo(x + 1, y + TILE);
      }
      if (right !== 2) {
        g.moveTo(x + TILE - 1, y);
        g.lineTo(x + TILE - 1, y + TILE);
      }
      g.stroke();
    } else if (t === 5) {
      // сплошная скала: грань монолита с трещинами (RimWorld-стиль)
      g.strokeStyle = 'rgba(30,30,34,0.55)';
      g.lineWidth = 1;
      g.beginPath();
      const h1 = tileHash(i * 3);
      const h2 = tileHash(i * 7 + 1);
      g.moveTo(x + 4 + h1 * 6, y);
      g.lineTo(x + 10 + h2 * 10, y + TILE / 2);
      g.lineTo(x + 5 + h1 * 8, y + TILE);
      g.moveTo(x + TILE, y + 6 + h2 * 8);
      g.lineTo(x + TILE / 2, y + 12 + h1 * 6);
      g.stroke();
      g.fillStyle = 'rgba(255,255,255,0.05)';
      g.fillRect(x, y, TILE, 3);
    }

    // зима: снежный покров (лёд на воде, припорошенный камень, белый снег)
    if (winter) {
      if (t === 2) g.fillStyle = 'rgba(185,212,232,0.55)';
      else if (t === 3) g.fillStyle = 'rgba(240,244,248,0.16)';
      else if (t === 5) g.fillStyle = 'rgba(240,244,248,0.10)';
      else if (t === 1) g.fillStyle = 'rgba(235,240,246,0.4)';
      else g.fillStyle = tileHash(i) > 0.5 ? 'rgba(238,243,248,0.52)' : 'rgba(238,243,248,0.46)';
      g.fillRect(x, y, TILE, TILE);
    }

    // зоны (оттенок — по номеру зоны, чтобы соседние склады различались)
    const z = w.zone[i];
    if (z === Zone.Stockpile) {
      const pair = STOCK_TINTS[w.zoneId[i] % STOCK_TINTS.length];
      g.fillStyle = pair[0];
      g.fillRect(x, y, TILE, TILE);
      g.strokeStyle = pair[1];
      g.lineWidth = 1;
      g.strokeRect(x + 1, y + 1, TILE - 2, TILE - 2);
    } else if (z === Zone.Farm) {
      const st = w.farmStage[i] as FarmStage;
      g.fillStyle = st === FarmStage.None ? 'rgba(107,74,47,0.55)' : '#6b4a2f';
      g.fillRect(x, y, TILE, TILE);
      g.strokeStyle = 'rgba(60,40,25,0.7)';
      g.lineWidth = 1;
      for (let k = 1; k < 4; k++) {
        g.beginPath();
        g.moveTo(x, y + (k * TILE) / 4);
        g.lineTo(x + TILE, y + (k * TILE) / 4);
        g.stroke();
      }
      if (st === FarmStage.Planted) {
        const gr2 = w.farmGrowth[i];
        g.fillStyle = '#7fc25a';
        const n = 3;
        for (let k = 0; k < n; k++) {
          const px = x + 6 + k * 10;
          const h = 3 + gr2 * 9;
          g.fillRect(px, y + TILE - 4 - h, 2, h);
        }
      } else if (st === FarmStage.Ready) {
        g.fillStyle = '#d9b13f';
        for (let k = 0; k < 3; k++) {
          const px = x + 6 + k * 10;
          g.fillRect(px, y + TILE - 16, 2, 12);
          g.fillRect(px - 1, y + TILE - 18, 4, 4);
        }
      }
    }

    // объекты
    const o = w.obj[i] as Obj;
    if (o === Obj.Tree) {
      g.fillStyle = 'rgba(0,0,0,0.18)';
      g.beginPath();
      g.ellipse(x + TILE / 2 + 2, y + TILE - 6, 9, 4, 0, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#6b4a2f';
      g.fillRect(x + TILE / 2 - 2, y + TILE - 12, 4, 8);
      const h = tileHash(i);
      g.fillStyle = h > 0.5 ? '#2f5d2f' : '#356534';
      g.beginPath();
      g.arc(x + TILE / 2, y + TILE / 2 - 3, 10, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = 'rgba(120,190,110,0.35)';
      g.beginPath();
      g.arc(x + TILE / 2 - 3, y + TILE / 2 - 6, 5, 0, Math.PI * 2);
      g.fill();
      if (winter) {
        // снежная шапка на кроне
        g.fillStyle = 'rgba(242,247,252,0.85)';
        g.beginPath();
        g.arc(x + TILE / 2 - 1, y + TILE / 2 - 8, 5.5, 0, Math.PI * 2);
        g.arc(x + TILE / 2 + 4, y + TILE / 2 - 5, 4, 0, Math.PI * 2);
        g.fill();
      }
    } else if (o === Obj.Rock) {
      g.fillStyle = 'rgba(0,0,0,0.18)';
      g.beginPath();
      g.ellipse(x + TILE / 2 + 2, y + TILE - 8, 10, 4, 0, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#9a9ca0';
      g.beginPath();
      g.moveTo(x + 5, y + 24);
      g.lineTo(x + 10, y + 8);
      g.lineTo(x + 22, y + 6);
      g.lineTo(x + 27, y + 22);
      g.lineTo(x + 20, y + 27);
      g.lineTo(x + 8, y + 27);
      g.closePath();
      g.fill();
      g.fillStyle = 'rgba(255,255,255,0.18)';
      g.beginPath();
      g.moveTo(x + 10, y + 8);
      g.lineTo(x + 22, y + 6);
      g.lineTo(x + 18, y + 14);
      g.closePath();
      g.fill();
    } else if (o === Obj.BerryBush) {
      g.fillStyle = '#2e5c30';
      g.beginPath();
      g.arc(x + TILE / 2, y + TILE / 2 + 2, 9, 0, Math.PI * 2);
      g.fill();
      if (w.berryRegrow[i] <= 0) {
        g.fillStyle = '#c94f4f';
        for (let k = 0; k < 4; k++) {
          const a = tileHash(i * 7 + k) * Math.PI * 2;
          g.beginPath();
          g.arc(x + TILE / 2 + Math.cos(a) * 5, y + TILE / 2 + 2 + Math.sin(a) * 5, 1.8, 0, Math.PI * 2);
          g.fill();
        }
      }
    } else if (o === Obj.RuinWall) {
      g.fillStyle = '#8d8a82';
      g.fillRect(x + 2, y + 2, TILE - 4, TILE - 4);
      g.strokeStyle = 'rgba(40,40,38,0.6)';
      g.lineWidth = 1;
      g.strokeRect(x + 2.5, y + 2.5, TILE - 5, TILE - 5);
      g.beginPath();
      g.moveTo(x + 2, y + TILE / 2);
      g.lineTo(x + TILE - 2, y + TILE / 2);
      g.moveTo(x + TILE / 2, y + 2);
      g.lineTo(x + TILE / 2, y + TILE - 2);
      g.stroke();
    } else if (o === Obj.Ore) {
      // железная жила: тёмный камень с ржаво-оранжевыми блёстками
      g.fillStyle = 'rgba(0,0,0,0.18)';
      g.beginPath();
      g.ellipse(x + TILE / 2 + 2, y + TILE - 8, 10, 4, 0, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#5f5c57';
      g.beginPath();
      g.moveTo(x + 5, y + 24);
      g.lineTo(x + 9, y + 9);
      g.lineTo(x + 21, y + 6);
      g.lineTo(x + 27, y + 21);
      g.lineTo(x + 19, y + 27);
      g.lineTo(x + 8, y + 27);
      g.closePath();
      g.fill();
      g.fillStyle = 'rgba(255,255,255,0.10)';
      g.beginPath();
      g.moveTo(x + 9, y + 9);
      g.lineTo(x + 21, y + 6);
      g.lineTo(x + 17, y + 14);
      g.closePath();
      g.fill();
      g.fillStyle = '#c98a3a';
      for (let k = 0; k < 5; k++) {
        const a = tileHash(i * 5 + k) * Math.PI * 2;
        const rr = 2.5 + tileHash(i * 9 + k) * 4;
        g.beginPath();
        g.arc(x + TILE / 2 + Math.cos(a) * rr, y + TILE / 2 + Math.sin(a) * rr - 2, 1.6, 0, Math.PI * 2);
        g.fill();
      }
      g.fillStyle = '#e8b25a';
      g.fillRect(x + 12, y + 12, 2, 2);
      g.fillRect(x + 20, y + 18, 2, 2);
    } else if (o === Obj.SilverOre) {
      // серебряная жила: тёмный камень с холодным белым блеском
      g.fillStyle = 'rgba(0,0,0,0.18)';
      g.beginPath();
      g.ellipse(x + TILE / 2 + 2, y + TILE - 8, 10, 4, 0, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#54565c';
      g.beginPath();
      g.moveTo(x + 6, y + 24);
      g.lineTo(x + 10, y + 9);
      g.lineTo(x + 21, y + 7);
      g.lineTo(x + 26, y + 22);
      g.lineTo(x + 18, y + 27);
      g.lineTo(x + 8, y + 27);
      g.closePath();
      g.fill();
      g.fillStyle = '#e6ecf2';
      for (let k = 0; k < 5; k++) {
        const a = tileHash(i * 11 + k) * Math.PI * 2;
        const rr = 2.5 + tileHash(i * 13 + k) * 4;
        g.beginPath();
        g.arc(x + TILE / 2 + Math.cos(a) * rr, y + TILE / 2 + Math.sin(a) * rr - 2, 1.5, 0, Math.PI * 2);
        g.fill();
      }
      g.fillStyle = '#f6f9fc';
      g.fillRect(x + 13, y + 11, 2.5, 2.5);
      g.fillRect(x + 21, y + 19, 2.5, 2.5);
    }

    // постройки (статичные готовые)
    const b = w.buildingMap.get(i);
    if (b && !b.blueprint) this.drawBuildingCache(g, b, x, y);
  }

  private drawBuildingCache(g: CanvasRenderingContext2D, b: { type: BType; graveName?: string }, x: number, y: number) {
    if (b.type === BType.Wall) {
      g.fillStyle = '#7a5a3a';
      g.fillRect(x + 1, y + 1, TILE - 2, TILE - 2);
      g.strokeStyle = 'rgba(50,35,20,0.8)';
      g.lineWidth = 1;
      g.strokeRect(x + 1.5, y + 1.5, TILE - 3, TILE - 3);
      g.beginPath();
      for (let k = 1; k < 3; k++) {
        g.moveTo(x + 1, y + (k * TILE) / 3);
        g.lineTo(x + TILE - 1, y + (k * TILE) / 3);
      }
      g.stroke();
    } else if (b.type === BType.Door) {
      g.fillStyle = '#5a4028';
      g.fillRect(x + 1, y + 1, TILE - 2, TILE - 2);
      g.fillStyle = '#8a6a45';
      g.fillRect(x + 4, y + 3, TILE - 8, TILE - 6);
      g.fillStyle = '#d9c98a';
      g.beginPath();
      g.arc(x + TILE - 9, y + TILE / 2, 2, 0, Math.PI * 2);
      g.fill();
    } else if (b.type === BType.Bed) {
      g.fillStyle = '#6a4a2e';
      g.fillRect(x + 3, y + 2, TILE - 6, TILE - 4);
      g.fillStyle = '#cabb9a';
      g.fillRect(x + 5, y + 8, TILE - 10, TILE - 12);
      g.fillStyle = '#e8e0cc';
      g.fillRect(x + 5, y + 4, TILE - 10, 6);
    } else if (b.type === BType.Campfire) {
      g.fillStyle = '#7d7f83';
      for (let k = 0; k < 6; k++) {
        const a = (k / 6) * Math.PI * 2;
        g.beginPath();
        g.arc(x + TILE / 2 + Math.cos(a) * 9, y + TILE / 2 + Math.sin(a) * 9, 2.6, 0, Math.PI * 2);
        g.fill();
      }
      g.fillStyle = '#5a4028';
      g.fillRect(x + 10, y + 14, 12, 3);
      g.fillRect(x + 14, y + 10, 3, 12);
    } else if (b.type === BType.Workbench) {
      // верстак: колода + столешница + инструмент
      g.fillStyle = '#4a3520';
      g.fillRect(x + 3, y + 8, TILE - 6, TILE - 12);
      g.fillStyle = '#8a6a45';
      g.fillRect(x + 2, y + 5, TILE - 4, 8);
      g.fillStyle = '#5a4028';
      g.fillRect(x + 4, y + 16, 4, 12);
      g.fillRect(x + TILE - 8, y + 16, 4, 12);
      g.strokeStyle = '#c9c2b0';
      g.lineWidth = 1.5;
      g.beginPath();
      g.moveTo(x + 8, y + 9);
      g.lineTo(x + 16, y + 9);
      g.stroke();
      g.fillStyle = '#9a9ca0';
      g.fillRect(x + 20, y + 5, 6, 4);
    } else if (b.type === BType.Table) {
      // стол: столешница и ножки
      g.fillStyle = '#5a4028';
      g.fillRect(x + 4, y + 18, 4, 11);
      g.fillRect(x + TILE - 8, y + 18, 4, 11);
      g.fillStyle = '#8a6a45';
      g.fillRect(x + 2, y + 9, TILE - 4, 10);
      g.fillStyle = '#a8845a';
      g.fillRect(x + 2, y + 9, TILE - 4, 3);
      g.strokeStyle = 'rgba(50,35,20,0.55)';
      g.lineWidth = 1;
      g.strokeRect(x + 2.5, y + 9.5, TILE - 5, 9);
    } else if (b.type === BType.Chair) {
      // стул: сиденье + спинка
      g.fillStyle = '#6a4a2e';
      g.fillRect(x + 7, y + 5, 5, 10);
      g.fillStyle = '#8a6a45';
      g.fillRect(x + 6, y + 14, TILE - 13, 9);
      g.fillStyle = '#5a4028';
      g.fillRect(x + 6, y + 23, 3, 6);
      g.fillRect(x + TILE - 10, y + 23, 3, 6);
    } else if (b.type === BType.StoneWall) {
      // каменная стена: серые блоки с раствором, вразбежку — вдвое крепче деревянной
      g.fillStyle = '#8b8b86';
      g.fillRect(x + 1, y + 1, TILE - 2, TILE - 2);
      g.fillStyle = '#a2a29c';
      g.fillRect(x + 1, y + 1, TILE - 2, 3);
      g.fillStyle = '#6e6e69';
      g.fillRect(x + 1, y + TILE - 5, TILE - 2, 4);
      g.strokeStyle = 'rgba(40,40,36,0.75)';
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(x + 1, y + TILE / 3 + 0.5);
      g.lineTo(x + TILE - 1, y + TILE / 3 + 0.5);
      g.moveTo(x + 1, y + (2 * TILE) / 3 + 0.5);
      g.lineTo(x + TILE - 1, y + (2 * TILE) / 3 + 0.5);
      g.moveTo(x + TILE / 2 + 0.5, y + 1);
      g.lineTo(x + TILE / 2 + 0.5, y + TILE / 3);
      g.moveTo(x + TILE / 4 + 0.5, y + TILE / 3);
      g.lineTo(x + TILE / 4 + 0.5, y + (2 * TILE) / 3);
      g.moveTo(x + (3 * TILE) / 4 + 0.5, y + TILE / 3);
      g.lineTo(x + (3 * TILE) / 4 + 0.5, y + (2 * TILE) / 3);
      g.moveTo(x + TILE / 2 + 0.5, y + (2 * TILE) / 3);
      g.lineTo(x + TILE / 2 + 0.5, y + TILE - 1);
      g.stroke();
    } else if (b.type === BType.Grave) {
      // могила: холмик земли; занятая — с каменным надгробием и крестом
      g.fillStyle = b.graveName ? '#5a4a34' : '#463a29';
      g.beginPath();
      g.ellipse(x + TILE / 2, y + TILE - 8, 11, 6, 0, 0, Math.PI * 2);
      g.fill();
      if (b.graveName) {
        g.fillStyle = '#9a9a94';
        g.beginPath();
        g.moveTo(x + 9, y + 15);
        g.lineTo(x + 9, y + 8);
        g.arc(x + TILE / 2, y + 8, 7, Math.PI, 0);
        g.lineTo(x + TILE - 9, y + 15);
        g.closePath();
        g.fill();
        g.strokeStyle = 'rgba(40,40,36,0.6)';
        g.lineWidth = 1;
        g.stroke();
        g.strokeStyle = '#5f5f5a';
        g.beginPath();
        g.moveTo(x + TILE / 2, y + 5);
        g.lineTo(x + TILE / 2, y + 12);
        g.moveTo(x + TILE / 2 - 2.5, y + 7);
        g.lineTo(x + TILE / 2 + 2.5, y + 7);
        g.stroke();
      } else {
        // пустая: краеугольные камни по краям насыпи
        g.fillStyle = '#8b8b86';
        g.fillRect(x + 4, y + TILE - 8, 4, 4);
        g.fillRect(x + TILE - 8, y + TILE - 8, 4, 4);
      }
    } else if (b.type === BType.Torch) {
      // факел: кол + обмотка (пламя рисуется отдельно, оно живое)
      g.strokeStyle = '#5a4028';
      g.lineWidth = 3.5;
      g.beginPath();
      g.moveTo(x + TILE / 2, y + TILE - 4);
      g.lineTo(x + TILE / 2, y + 10);
      g.stroke();
      g.fillStyle = '#7a5a3a';
      g.fillRect(x + TILE / 2 - 3, y + 8, 6, 5);
    } else if (b.type === BType.Trap) {
      // ловушка из кольев: доска с острыми колышками
      g.fillStyle = '#5a4028';
      g.fillRect(x + 4, y + TILE - 10, TILE - 8, 5);
      g.fillStyle = '#8a6a45';
      g.fillRect(x + 4, y + TILE - 12, TILE - 8, 3);
      g.fillStyle = '#c9c2b0';
      for (let k = 0; k < 4; k++) {
        const px = x + 8 + k * 5.5;
        g.beginPath();
        g.moveTo(px, y + TILE - 12);
        g.lineTo(px + 1.6, y + 8);
        g.lineTo(px + 3.2, y + TILE - 12);
        g.closePath();
        g.fill();
      }
    } else if (b.type === BType.Turret) {
      // арбалетная башня: деревянный помост с арбалетом наверху
      g.fillStyle = '#4a3520';
      g.fillRect(x + 9, y + 12, 5, TILE - 13);
      g.fillRect(x + TILE - 14, y + 12, 5, TILE - 13);
      g.fillStyle = '#7a5a3a';
      g.fillRect(x + 5, y + 8, TILE - 10, 7);
      g.fillStyle = '#9a7448';
      g.fillRect(x + 5, y + 8, TILE - 10, 3);
      // арбалет: лук и ложа
      g.strokeStyle = '#5a4028';
      g.lineWidth = 2;
      g.beginPath();
      g.arc(x + TILE / 2, y + 5, 5, Math.PI * 0.9, Math.PI * 2.1);
      g.stroke();
      g.strokeStyle = '#2e2216';
      g.lineWidth = 1.2;
      g.beginPath();
      g.moveTo(x + TILE / 2 - 5, y + 6);
      g.lineTo(x + TILE / 2 + 5, y + 6);
      g.stroke();
      g.fillStyle = '#c9c2b0';
      g.fillRect(x + TILE / 2 - 1, y + 2, 2, 6);
    } else if (b.type === BType.Mine) {
      // шахта: вход в гору — серый каменный фасад, чёрный проём, деревянные крепи
      g.fillStyle = '#7d7d78';
      g.beginPath();
      g.moveTo(x + 1, y + TILE - 1);
      g.lineTo(x + 1, y + 10);
      g.lineTo(x + 8, y + 3);
      g.lineTo(x + TILE - 8, y + 3);
      g.lineTo(x + TILE - 1, y + 10);
      g.lineTo(x + TILE - 1, y + TILE - 1);
      g.closePath();
      g.fill();
      g.fillStyle = 'rgba(255,255,255,0.12)';
      g.beginPath();
      g.moveTo(x + 1, y + 10);
      g.lineTo(x + 8, y + 3);
      g.lineTo(x + TILE - 8, y + 3);
      g.lineTo(x + TILE - 1, y + 10);
      g.lineTo(x + TILE - 6, y + 10);
      g.closePath();
      g.fill();
      // тёмный проём
      g.fillStyle = '#14120e';
      g.beginPath();
      g.moveTo(x + 9, y + TILE - 1);
      g.lineTo(x + 9, y + 16);
      g.arc(x + TILE / 2, y + 16, 7, Math.PI, 0);
      g.lineTo(x + TILE - 9, y + TILE - 1);
      g.closePath();
      g.fill();
      // деревянные крепи: столбы и перекладина
      g.fillStyle = '#6a4a2e';
      g.fillRect(x + 6, y + 14, 3, TILE - 15);
      g.fillRect(x + TILE - 9, y + 14, 3, TILE - 15);
      g.fillRect(x + 5, y + 11, TILE - 10, 4);
      g.fillStyle = '#8a6a45';
      g.fillRect(x + 5, y + 11, TILE - 10, 1.5);
      // рудный блеск у входа — где лежит добыча
      g.fillStyle = '#c98a3a';
      g.fillRect(x + 4, y + TILE - 5, 2, 2);
      g.fillRect(x + TILE - 7, y + TILE - 7, 2, 2);
    }
  }

  // ================= Основной кадр =================
  resize() {
    const rect = this.canvas.getBoundingClientRect();
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(1, Math.round(rect.width));
    const h = Math.max(1, Math.round(rect.height));
    if (this.canvas.width !== Math.round(w * this.dpr) || this.canvas.height !== Math.round(h * this.dpr)) {
      this.canvas.width = Math.round(w * this.dpr);
      this.canvas.height = Math.round(h * this.dpr);
    }
    this.viewW = w;
    this.viewH = h;
  }

  draw(dtReal: number) {
    this.resize();
    this.flushDirty();
    this.time += dtReal;
    const g = this.ctx;
    const game = this.game;
    const cam = this.cam;
    const dpr = this.dpr;
    const vw = this.viewW;
    const vh = this.viewH;
    cam.lastViewW = vw;
    cam.lastViewH = vh;

    // слежение
    if (cam.followId !== null) {
      const p = game.pawns.find((pp) => pp.id === cam.followId && !pp.dead);
      if (p) {
        cam.x = p.x * TILE;
        cam.y = p.y * TILE;
        cam.clampToMap();
      } else {
        cam.followId = null;
      }
    }

    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.fillStyle = '#101613';
    g.fillRect(0, 0, vw, vh);
    g.save();
    g.translate(vw / 2, vh / 2);
    g.scale(cam.zoom, cam.zoom);
    g.translate(-cam.x, -cam.y);

    // террейн (подпрямоугольник видимой области)
    const visW = vw / cam.zoom;
    const visH = vh / cam.zoom;
    const sx = clamp(cam.x - visW / 2, 0, MAP * TILE);
    const sy = clamp(cam.y - visH / 2, 0, MAP * TILE);
    const sw = clamp(visW + 2, 0, MAP * TILE - sx);
    const sh = clamp(visH + 2, 0, MAP * TILE - sy);
    g.imageSmoothingEnabled = false;
    if (sw > 0 && sh > 0) g.drawImage(this.terrain, sx, sy, sw, sh, sx, sy, sw, sh);
    g.imageSmoothingEnabled = true;

    // видимые клетки (для предметов/обозначений)
    const tx0 = Math.max(0, Math.floor(sx / TILE));
    const ty0 = Math.max(0, Math.floor(sy / TILE));
    const tx1 = Math.min(MAP - 1, Math.ceil((sx + sw) / TILE));
    const ty1 = Math.min(MAP - 1, Math.ceil((sy + sh) / TILE));

    // предметы
    for (const it of game.world.items) {
      if (it.x < tx0 - 1 || it.x > tx1 + 1 || it.y < ty0 - 1 || it.y > ty1 + 1) continue;
      this.drawItem(g, it.type, it.x * TILE, it.y * TILE, it.qty);
    }

    // обозначения (приказы)
    const d = game.desig;
    for (let y = ty0; y <= ty1; y++) {
      for (let x = tx0; x <= tx1; x++) {
        const i = y * MAP + x;
        if (d.chop[i]) this.desigMark(g, x, y, 'rgba(230,140,40,0.20)', 'rgba(230,140,40,0.8)');
        else if (d.mine[i]) this.desigMark(g, x, y, 'rgba(180,180,180,0.22)', 'rgba(200,200,200,0.8)');
        else if (d.harvest[i]) this.desigMark(g, x, y, 'rgba(120,200,90,0.20)', 'rgba(120,200,90,0.8)');
      }
    }

    // подписи зон (RimWorld-стиль: имя над центром зоны)
    this.zLabelsT -= dtReal;
    if (this.zLabelsT <= 0) {
      this.zLabelsT = 0.5;
      this.zLabels = game.world.zoneCenters();
    }
    if (this.zLabels.length > 0 && cam.zoom >= 0.7) {
      g.font = 'bold 10px sans-serif';
      g.textAlign = 'center';
      g.lineWidth = 3;
      for (const zl of this.zLabels) {
        const px = zl.x * TILE;
        const py = zl.y * TILE;
        if (px < sx - 80 || px > sx + sw + 80 || py < sy - 40 || py > sy + sh + 40) continue;
        g.strokeStyle = 'rgba(8,10,6,0.8)';
        g.strokeText(zl.name, px, py - 4);
        g.fillStyle = zl.kind === 'farm' ? '#d8e8b0' : '#f0dfae';
        g.fillText(zl.name, px, py - 4);
      }
      g.textAlign = 'left';
    }

    // чертежи
    for (const b of game.world.buildings) {
      if (!b.blueprint) continue;
      if (b.x < tx0 - 1 || b.x > tx1 + 1 || b.y < ty0 - 1 || b.y > ty1 + 1) continue;
      const x = b.x * TILE;
      const y = b.y * TILE;
      g.globalAlpha = 0.45;
      this.drawBuildingCache(g, b, x, y);
      g.globalAlpha = 1;
      g.strokeStyle = 'rgba(240,240,255,0.9)';
      g.setLineDash([4, 3]);
      g.lineWidth = 1.5;
      g.strokeRect(x + 2, y + 2, TILE - 4, TILE - 4);
      g.setLineDash([]);
      if (b.matHave > 0) {
        g.fillStyle = 'rgba(240,240,255,0.9)';
        g.fillRect(x + 4, y + TILE - 6, (TILE - 8) * (b.matHave / b.matNeed), 3);
      }
    }

    // огонь костров и факелов (анимация)
    for (const cf of game.campfires()) {
      if (cf.x < tx0 - 1 || cf.x > tx1 + 1 || cf.y < ty0 - 1 || cf.y > ty1 + 1) continue;
      const fx = cf.x * TILE + TILE / 2;
      const fy = cf.y * TILE + TILE / 2 - 3;
      const fl = Math.sin(this.time * 9 + cf.x) * 1.5;
      g.fillStyle = '#e8763a';
      g.beginPath();
      g.moveTo(fx, fy - 9 - fl);
      g.lineTo(fx + 4.5, fy + 2);
      g.lineTo(fx - 4.5, fy + 2);
      g.closePath();
      g.fill();
      g.fillStyle = '#f5c542';
      g.beginPath();
      g.moveTo(fx, fy - 4 - fl * 0.6);
      g.lineTo(fx + 2.5, fy + 2);
      g.lineTo(fx - 2.5, fy + 2);
      g.closePath();
      g.fill();
    }
    // факелы: живое пламя на тополе
    for (const b of game.world.buildings) {
      if (b.blueprint || b.type !== BType.Torch) continue;
      if (b.x < tx0 - 1 || b.x > tx1 + 1 || b.y < ty0 - 1 || b.y > ty1 + 1) continue;
      const fx = b.x * TILE + TILE / 2;
      const fy = b.y * TILE + 8;
      const fl = Math.sin(this.time * 11 + b.x * 2.7) * 1.1;
      g.fillStyle = '#e8763a';
      g.beginPath();
      g.moveTo(fx, fy - 5 - fl);
      g.lineTo(fx + 3, fy + 2);
      g.lineTo(fx - 3, fy + 2);
      g.closePath();
      g.fill();
      g.fillStyle = '#f5c542';
      g.beginPath();
      g.moveTo(fx, fy - 2 - fl * 0.5);
      g.lineTo(fx + 1.6, fy + 2);
      g.lineTo(fx - 1.6, fy + 2);
      g.closePath();
      g.fill();
    }

    // HP повреждённых стен
    for (const b of game.world.buildings) {
      if (b.blueprint || b.hp >= b.maxHp) continue;
      if (b.x < tx0 - 1 || b.x > tx1 + 1 || b.y < ty0 - 1 || b.y > ty1 + 1) continue;
      const x = b.x * TILE;
      const y = b.y * TILE;
      g.fillStyle = 'rgba(0,0,0,0.5)';
      g.fillRect(x + 4, y - 5, TILE - 8, 3);
      g.fillStyle = b.hp > b.maxHp * 0.4 ? '#d9b13f' : '#c94f4f';
      g.fillRect(x + 4, y - 5, (TILE - 8) * (b.hp / b.maxHp), 3);
    }

    // звери
    for (const a of game.animals) this.drawAnimal(g, a);

    // пешки
    for (const p of game.pawns) {
      if (p.dead || p.underground) continue; // ушедшие в глубины шахты не видны
      this.drawPawn(g, p);
    }

    // летящие стрелы (полёт ~0.22 с, реальное время)
    if (game.arrows.length > 0) {
      const FLIGHT = 0.22;
      g.strokeStyle = '#e8dfbe';
      g.lineWidth = 1.5;
      for (const ar of game.arrows) {
        const pr = Math.max(0, Math.min(1, 1 - ar.t / FLIGHT));
        const pr0 = Math.max(0, pr - 0.18);
        const hx = (ar.x0 + (ar.x1 - ar.x0) * pr) * TILE;
        const hy = (ar.y0 + (ar.y1 - ar.y0) * pr) * TILE;
        const tx0 = (ar.x0 + (ar.x1 - ar.x0) * pr0) * TILE;
        const ty0 = (ar.y0 + (ar.y1 - ar.y0) * pr0) * TILE;
        g.beginPath();
        g.moveTo(tx0, ty0);
        g.lineTo(hx, hy);
        g.stroke();
      }
    }

    // выбранная пешка — кольцо
    if (game.selectedPawnId !== null) {
      const p = game.pawns.find((pp) => pp.id === game.selectedPawnId);
      if (p && !p.dead) {
        g.strokeStyle = '#f5f0e0';
        g.lineWidth = 2;
        g.beginPath();
        g.arc(p.x * TILE, p.y * TILE, 14 + Math.sin(this.time * 4) * 1.5, 0, Math.PI * 2);
        g.stroke();
      }
    }

    // маркер цели атаки
    if (game.attackTargetId !== null) {
      const a = game.animals.find((an) => an.id === game.attackTargetId);
      if (a) {
        g.strokeStyle = '#e05545';
        g.lineWidth = 2;
        g.beginPath();
        g.arc(a.x * TILE, a.y * TILE, 13 + Math.sin(this.time * 6) * 2, 0, Math.PI * 2);
        g.stroke();
      }
    }

    // метки дичи, помеченной для охоты (🎯): пульсирующее кольцо с прицелом
    if (game.huntList.size > 0) {
      g.strokeStyle = HUNT_MARKER;
      g.fillStyle = HUNT_MARKER;
      g.lineWidth = 1.6;
      for (const a of game.animals) {
        if (!game.huntList.has(a.id)) continue;
        const r = 11 + Math.sin(this.time * 5) * 1.5;
        g.setLineDash([4, 3]);
        g.beginPath();
        g.arc(a.x * TILE, a.y * TILE, r, 0, Math.PI * 2);
        g.stroke();
        g.setLineDash([]);
        // прицел: четыре чёрточки внутрь
        g.beginPath();
        g.moveTo(a.x * TILE - r - 3, a.y * TILE);
        g.lineTo(a.x * TILE - r + 3, a.y * TILE);
        g.moveTo(a.x * TILE + r + 3, a.y * TILE);
        g.lineTo(a.x * TILE + r - 3, a.y * TILE);
        g.moveTo(a.x * TILE, a.y * TILE - r - 3);
        g.lineTo(a.x * TILE, a.y * TILE - r + 3);
        g.moveTo(a.x * TILE, a.y * TILE + r + 3);
        g.lineTo(a.x * TILE, a.y * TILE + r - 3);
        g.stroke();
      }
    }

    g.restore();

    // экранные координаты мирового нуля (для света и эффектов)
    const ox = vw / 2 - cam.x * cam.zoom;
    const oy = vh / 2 - cam.y * cam.zoom;

    // ---- Ночь и свет ----
    const na = game.clock.nightAlpha;
    if (na > 0.02) {
      if (this.light.width !== this.canvas.width || this.light.height !== this.canvas.height) {
        this.light.width = this.canvas.width;
        this.light.height = this.canvas.height;
      }
      const lc = this.lctx;
      lc.setTransform(dpr, 0, 0, dpr, 0, 0);
      lc.clearRect(0, 0, vw, vh);
      lc.fillStyle = `rgba(8,12,34,${na})`;
      lc.fillRect(0, 0, vw, vh);
      lc.globalCompositeOperation = 'destination-out';
      const punch = (wx: number, wy: number, rTiles: number, strength: number) => {
        const px = (wx * TILE) * cam.zoom + ox;
        const py = (wy * TILE) * cam.zoom + oy;
        const r = rTiles * TILE * cam.zoom;
        const grad = lc.createRadialGradient(px, py, 0, px, py, r);
        grad.addColorStop(0, `rgba(0,0,0,${strength})`);
        grad.addColorStop(1, 'rgba(0,0,0,0)');
        lc.fillStyle = grad;
        lc.beginPath();
        lc.arc(px, py, r, 0, Math.PI * 2);
        lc.fill();
      };
      for (const lt of game.world.litBuildings()) {
        const fl = 1 + Math.sin(this.time * 7 + lt.x * 3) * 0.06;
        if (lt.type === BType.Torch) {
          punch(lt.x + 0.5, lt.y + 0.5, BUILDINGS[BType.Torch].light * fl, 0.8);
        } else {
          punch(lt.x + 0.5, lt.y + 0.5, BUILDINGS[BType.Campfire].light * fl, 0.95);
        }
      }
      for (const p of game.pawns) {
        if (!p.dead) punch(p.x, p.y, 2.6, 0.7);
      }
      lc.globalCompositeOperation = 'source-over';
      g.drawImage(this.light, 0, 0, vw, vh);
      // тёплый отсвет от костров
      g.globalCompositeOperation = 'lighter';
      for (const cf of game.campfires()) {
        const px = (cf.x + 0.5) * TILE * cam.zoom + ox;
        const py = (cf.y + 0.5) * TILE * cam.zoom + oy;
        const r = BUILDINGS[BType.Campfire].light * TILE * cam.zoom * 0.8;
        const grad = g.createRadialGradient(px, py, 0, px, py, r);
        grad.addColorStop(0, `rgba(240,150,60,${0.16 * na / 0.82})`);
        grad.addColorStop(1, 'rgba(240,150,60,0)');
        g.fillStyle = grad;
        g.beginPath();
        g.arc(px, py, r, 0, Math.PI * 2);
        g.fill();
      }
      g.globalCompositeOperation = 'source-over';
    }

    // рассвет/закат — тёплый оттенок
    const h = game.clock.hour + game.clock.minute / 60;
    let warm = 0;
    if (h >= 5 && h < 8) warm = 1 - Math.abs(h - 6.5) / 1.5;
    else if (h >= 18 && h < 21) warm = 1 - Math.abs(h - 19.5) / 1.5;
    if (warm > 0) {
      g.fillStyle = `rgba(255,140,60,${0.10 * clamp(warm, 0, 1)})`;
      g.fillRect(0, 0, vw, vh);
    }

    // ---- Дождь ----
    if (game.weather.rain) {
      if (!this.raining) {
        this.raining = true;
        this.rain = [];
        for (let i = 0; i < 90; i++) {
          this.rain.push({ x: Math.random() * vw, y: Math.random() * vh, s: 380 + Math.random() * 260, l: 9 + Math.random() * 9 });
        }
      }
      g.strokeStyle = 'rgba(180,200,230,0.42)';
      g.lineWidth = 1;
      g.beginPath();
      for (const dr of this.rain) {
        dr.y += dr.s * dtReal;
        dr.x += dr.s * dtReal * 0.12;
        if (dr.y > vh) {
          dr.y = -dr.l;
          dr.x = Math.random() * vw;
        }
        g.moveTo(dr.x, dr.y);
        g.lineTo(dr.x - dr.l * 0.12, dr.y - dr.l);
      }
      g.stroke();
      g.fillStyle = 'rgba(40,60,90,0.07)';
      g.fillRect(0, 0, vw, vh);
    } else {
      this.raining = false;
    }

    // ---- Снегопад (зимой всегда лёгкий, в буран — стена снега) ----
    const winterNow = game.clock.isWinter;
    const snowHeavy = game.weather.blizzard;
    if (winterNow || snowHeavy) {
      const want = snowHeavy ? 150 : 55;
      if (!this.snowing || this.snow.length !== want) {
        this.snowing = true;
        this.snow = [];
        for (let i = 0; i < want; i++) {
          this.snow.push({ x: Math.random() * vw, y: Math.random() * vh, s: 26 + Math.random() * 46, r: 1 + Math.random() * 1.7, ph: Math.random() * Math.PI * 2 });
        }
      }
      g.fillStyle = snowHeavy ? 'rgba(235,240,248,0.85)' : 'rgba(235,240,248,0.66)';
      for (const fl of this.snow) {
        fl.y += fl.s * dtReal * (snowHeavy ? 2.1 : 1);
        fl.x += Math.sin(this.time * 1.3 + fl.ph) * 14 * dtReal + (snowHeavy ? 42 * dtReal : 0);
        if (fl.y > vh) {
          fl.y = -3;
          fl.x = Math.random() * vw;
        }
        if (fl.x > vw) fl.x = 0;
        if (fl.x < 0) fl.x = vw;
        g.beginPath();
        g.arc(fl.x, fl.y, fl.r, 0, Math.PI * 2);
        g.fill();
      }
      if (snowHeavy) {
        g.fillStyle = 'rgba(88,98,120,0.13)';
        g.fillRect(0, 0, vw, vh);
      }
    } else {
      this.snowing = false;
    }

    // ---- Прямоугольник выделения ----
    if (this.rectStart && this.rectCur) {
      const a = this.cam.screenToWorld(Math.min(this.rectStart.x, this.rectCur.x), Math.min(this.rectStart.y, this.rectCur.y), vw, vh);
      const bpt = this.cam.screenToWorld(Math.max(this.rectStart.x, this.rectCur.x), Math.max(this.rectStart.y, this.rectCur.y), vw, vh);
      g.strokeStyle = 'rgba(245,240,220,0.95)';
      g.fillStyle = 'rgba(245,240,220,0.12)';
      g.lineWidth = 1.5;
      g.save();
      g.translate(vw / 2, vh / 2);
      g.scale(cam.zoom, cam.zoom);
      g.translate(-cam.x, -cam.y);
      g.fillRect(a.x, a.y, bpt.x - a.x, bpt.y - a.y);
      g.strokeRect(a.x, a.y, bpt.x - a.x, bpt.y - a.y);
      g.restore();
    }
  }

  private desigMark(g: CanvasRenderingContext2D, x: number, y: number, fill: string, border: string) {
    g.fillStyle = fill;
    g.fillRect(x * TILE, y * TILE, TILE, TILE);
    g.strokeStyle = border;
    g.lineWidth = 1.5;
    g.strokeRect(x * TILE + 1.5, y * TILE + 1.5, TILE - 3, TILE - 3);
  }

  private drawItem(g: CanvasRenderingContext2D, type: Res, x: number, y: number, qty: number) {
    const cx = x + TILE / 2;
    const cy = y + TILE / 2;
    if (type === Res.Wood) {
      g.fillStyle = '#8a5f38';
      g.fillRect(cx - 9, cy - 2, 18, 5);
      g.fillRect(cx - 6, cy - 7, 18, 5);
      g.fillStyle = '#c9a06a';
      g.fillRect(cx + 7, cy - 2, 2, 5);
      g.fillRect(cx + 10, cy - 7, 2, 5);
    } else if (type === Res.Stone) {
      g.fillStyle = '#9a9ca0';
      g.beginPath();
      g.arc(cx - 4, cy + 2, 5, 0, Math.PI * 2);
      g.arc(cx + 5, cy - 1, 6, 0, Math.PI * 2);
      g.fill();
    } else if (type === Res.Food) {
      g.fillStyle = '#c94f5f';
      g.beginPath();
      g.arc(cx - 4, cy, 3.2, 0, Math.PI * 2);
      g.arc(cx + 3, cy - 3, 3.2, 0, Math.PI * 2);
      g.arc(cx + 2, cy + 4, 3.2, 0, Math.PI * 2);
      g.fill();
    } else if (type === Res.Loot) {
      g.fillStyle = '#7a5a3a';
      g.fillRect(cx - 7, cy - 8, 14, 16);
      g.fillStyle = '#5a4028';
      g.fillRect(cx - 7, cy - 2, 14, 3);
    } else if (type === Res.Corpse) {
      g.fillStyle = '#8f9588';
      g.beginPath();
      g.ellipse(cx, cy, 11, 5, 0, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#c9c2b0';
      g.beginPath();
      g.arc(cx + 9, cy, 3.5, 0, Math.PI * 2);
      g.fill();
    } else if (type === Res.Meal) {
      // миска похлёбки
      g.fillStyle = '#b5793a';
      g.beginPath();
      g.ellipse(cx, cy + 1, 8, 5.5, 0, 0, Math.PI);
      g.fill();
      g.fillStyle = '#e8b25a';
      g.beginPath();
      g.ellipse(cx, cy, 7.5, 3, 0, 0, Math.PI * 2);
      g.fill();
      g.strokeStyle = 'rgba(255,240,220,0.5)';
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(cx - 2, cy - 4);
      g.quadraticCurveTo(cx - 4, cy - 7, cx - 2, cy - 9);
      g.moveTo(cx + 2, cy - 4);
      g.quadraticCurveTo(cx, cy - 7, cx + 2, cy - 9);
      g.stroke();
    } else if (type === Res.Spear) {
      // копьё лежит наискосок
      g.strokeStyle = '#8a5f38';
      g.lineWidth = 2.5;
      g.beginPath();
      g.moveTo(cx - 8, cy + 8);
      g.lineTo(cx + 6, cy - 6);
      g.stroke();
      g.fillStyle = '#c9c2b0';
      g.beginPath();
      g.moveTo(cx + 4, cy - 4);
      g.lineTo(cx + 10, cy - 10);
      g.lineTo(cx + 8, cy - 3);
      g.closePath();
      g.fill();
    } else if (type === Res.Bow) {
      // лук: дуга + тетива
      g.strokeStyle = '#8a5f38';
      g.lineWidth = 2.5;
      g.beginPath();
      g.arc(cx, cy, 9, -Math.PI / 2.4, Math.PI / 2.4);
      g.stroke();
      g.strokeStyle = '#d9cfa8';
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(cx + Math.cos(-Math.PI / 2.4) * 9, cy + Math.sin(-Math.PI / 2.4) * 9);
      g.lineTo(cx + Math.cos(Math.PI / 2.4) * 9, cy + Math.sin(Math.PI / 2.4) * 9);
      g.stroke();
    } else if (type === Res.Iron) {
      // железные слитки
      g.fillStyle = '#6a6d73';
      g.fillRect(cx - 9, cy + 1, 12, 5);
      g.fillRect(cx - 3, cy - 5, 12, 5);
      g.fillStyle = '#9a9ea6';
      g.fillRect(cx - 9, cy + 1, 12, 2);
      g.fillRect(cx - 3, cy - 5, 12, 2);
      g.fillStyle = '#c9cdd5';
      g.fillRect(cx - 6, cy + 2, 3, 1.5);
    } else if (type === Res.Hide) {
      // шкура: коричневый лоскут с более тёмным краем
      g.fillStyle = '#7a5a3a';
      g.beginPath();
      g.ellipse(cx, cy, 9, 7, 0.3, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#94714c';
      g.beginPath();
      g.ellipse(cx - 1, cy - 1, 6.5, 5, 0.3, 0, Math.PI * 2);
      g.fill();
    } else if (type === Res.Coat) {
      // тёплая куртка: туловище с рукавами и воротником
      g.fillStyle = '#a8623c';
      g.fillRect(cx - 6, cy - 5, 12, 13);
      g.fillRect(cx - 10, cy - 4, 4, 9);
      g.fillRect(cx + 6, cy - 4, 4, 9);
      g.fillStyle = '#c9885a';
      g.fillRect(cx - 6, cy - 5, 12, 3);
      g.fillStyle = '#e8dfc8';
      g.fillRect(cx - 2, cy - 7, 4, 3);
    } else if (type === Res.LeatherArmor) {
      // кожаная броня: нагрудник с ремнями
      g.fillStyle = '#6b4a2c';
      g.beginPath();
      g.moveTo(cx - 8, cy - 6);
      g.lineTo(cx + 8, cy - 6);
      g.lineTo(cx + 6, cy + 8);
      g.lineTo(cx - 6, cy + 8);
      g.closePath();
      g.fill();
      g.strokeStyle = '#3d2a18';
      g.lineWidth = 1.5;
      g.beginPath();
      g.moveTo(cx - 4, cy - 6);
      g.lineTo(cx - 2, cy + 8);
      g.moveTo(cx + 4, cy - 6);
      g.lineTo(cx + 2, cy + 8);
      g.stroke();
    } else if (type === Res.IronArmor) {
      // железная броня: стальной нагрудник с бликом
      g.fillStyle = '#7a828c';
      g.beginPath();
      g.moveTo(cx - 8, cy - 6);
      g.lineTo(cx + 8, cy - 6);
      g.lineTo(cx + 6, cy + 8);
      g.lineTo(cx - 6, cy + 8);
      g.closePath();
      g.fill();
      g.fillStyle = '#a8b0ba';
      g.beginPath();
      g.moveTo(cx - 8, cy - 6);
      g.lineTo(cx + 2, cy - 6);
      g.lineTo(cx - 3, cy + 8);
      g.lineTo(cx - 6, cy + 8);
      g.closePath();
      g.fill();
      g.fillStyle = '#c9cdd5';
      g.fillRect(cx - 2, cy - 2, 3, 1.5);
    } else if (type === Res.Sword) {
      // меч: клинок с гардой, лежит наискосок
      g.strokeStyle = '#c9cdd5';
      g.lineWidth = 3;
      g.beginPath();
      g.moveTo(cx - 2, cy + 2);
      g.lineTo(cx + 8, cy - 8);
      g.stroke();
      g.strokeStyle = '#eef1f5';
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(cx - 1, cy + 1);
      g.lineTo(cx + 7, cy - 7);
      g.stroke();
      g.strokeStyle = '#8a6a45';
      g.lineWidth = 2.5;
      g.beginPath();
      g.moveTo(cx - 7, cy + 7);
      g.lineTo(cx - 2, cy + 2);
      g.stroke();
      g.strokeStyle = '#8a6a45';
      g.lineWidth = 2;
      g.beginPath();
      g.moveTo(cx - 4.5, cy - 0.5);
      g.lineTo(cx + 0.5, cy + 4.5);
      g.stroke();
    } else if (type === Res.Silver) {
      // серебро: блестящие монеты/слитки
      g.fillStyle = '#c9cdd5';
      g.beginPath();
      g.arc(cx - 4, cy + 2, 4.5, 0, Math.PI * 2);
      g.arc(cx + 4, cy - 2, 4.5, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#eef1f5';
      g.beginPath();
      g.arc(cx - 5, cy + 1, 1.6, 0, Math.PI * 2);
      g.arc(cx + 3, cy - 3, 1.6, 0, Math.PI * 2);
      g.fill();
    }
    if (qty > 1) {
      g.font = '9px sans-serif';
      g.fillStyle = 'rgba(255,255,255,0.85)';
      g.textAlign = 'center';
      g.fillText(`${qty}`, cx, cy + 13);
      g.textAlign = 'left';
    }
  }

  private drawPawn(g: CanvasRenderingContext2D, p: Pawn) {
    const x = p.x * TILE;
    const y = p.y * TILE;
    // тень
    g.fillStyle = 'rgba(0,0,0,0.25)';
    g.beginPath();
    g.ellipse(x, y + 8, 8, 3.5, 0, 0, Math.PI * 2);
    g.fill();
    // тело
    g.fillStyle = p.color;
    g.beginPath();
    g.arc(x, y, 8.5, 0, Math.PI * 2);
    g.fill();
    g.strokeStyle = 'rgba(30,20,10,0.6)';
    g.lineWidth = 1.5;
    g.stroke();
    // голова
    g.fillStyle = '#e8c49a';
    g.beginPath();
    g.arc(x, y - 4, 4, 0, Math.PI * 2);
    g.fill();
    // одежда и броня (RimWorld: слои видны на колонисте)
    if (p.cloth === 'coat') {
      // куртка: воротник-опушка вокруг шеи
      g.strokeStyle = '#a8623c';
      g.lineWidth = 3;
      g.beginPath();
      g.arc(x, y - 1, 7.5, Math.PI * 0.15, Math.PI * 0.85, false);
      g.stroke();
      g.strokeStyle = '#e8dfc8';
      g.lineWidth = 1.2;
      g.beginPath();
      g.arc(x, y - 1, 8.6, Math.PI * 0.25, Math.PI * 0.75, false);
      g.stroke();
    }
    if (p.armor === 'iron') {
      // железный нагрудник: серая дуга на теле с бликом
      g.fillStyle = '#7a828c';
      g.beginPath();
      g.ellipse(x, y + 1.5, 7.5, 6.5, 0, Math.PI * 0.08, Math.PI * 0.92, false);
      g.fill();
      g.strokeStyle = '#4a5058';
      g.lineWidth = 1;
      g.stroke();
      g.strokeStyle = '#c9cdd5';
      g.lineWidth = 1.4;
      g.beginPath();
      g.moveTo(x - 4, y - 1);
      g.lineTo(x - 1, y + 4.5);
      g.stroke();
    } else if (p.armor === 'leather') {
      // кожаный нагрудник
      g.fillStyle = '#6b4a2c';
      g.beginPath();
      g.ellipse(x, y + 1.5, 7.5, 6.5, 0, Math.PI * 0.08, Math.PI * 0.92, false);
      g.fill();
      g.strokeStyle = '#3d2a18';
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(x - 3, y - 2);
      g.lineTo(x - 1.5, y + 5);
      g.moveTo(x + 3, y - 2);
      g.lineTo(x + 1.5, y + 5);
      g.stroke();
    }
    // оружие в руках
    if (p.weapon === 'spear') {
      g.strokeStyle = '#a8763e';
      g.lineWidth = 2;
      g.beginPath();
      g.moveTo(x + 5, y + 7);
      g.lineTo(x + 11, y - 7);
      g.stroke();
      g.fillStyle = '#d9d5c5';
      g.beginPath();
      g.moveTo(x + 10, y - 5);
      g.lineTo(x + 13, y - 11);
      g.lineTo(x + 12, y - 4);
      g.closePath();
      g.fill();
    } else if (p.weapon === 'bow') {
      g.strokeStyle = '#a8763e';
      g.lineWidth = 2;
      g.beginPath();
      g.arc(x + 9, y, 6, -Math.PI / 2.2, Math.PI / 2.2);
      g.stroke();
      g.strokeStyle = 'rgba(240,235,210,0.8)';
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(x + 9 + Math.cos(-Math.PI / 2.2) * 6, y + Math.sin(-Math.PI / 2.2) * 6);
      g.lineTo(x + 9 + Math.cos(Math.PI / 2.2) * 6, y + Math.sin(Math.PI / 2.2) * 6);
      g.stroke();
    } else if (p.weapon === 'sword') {
      // меч в руке: короткий клинок с гардой
      g.strokeStyle = '#5a4028';
      g.lineWidth = 2;
      g.beginPath();
      g.moveTo(x + 5, y + 8);
      g.lineTo(x + 8, y + 5);
      g.stroke();
      g.strokeStyle = '#8a6a45';
      g.lineWidth = 2.4;
      g.beginPath();
      g.moveTo(x + 6.2, y + 2.8);
      g.lineTo(x + 10.2, y + 6.8);
      g.stroke();
      g.strokeStyle = '#d9dee6';
      g.lineWidth = 2.6;
      g.beginPath();
      g.moveTo(x + 8.6, y + 4.2);
      g.lineTo(x + 13.5, y - 6.5);
      g.stroke();
      g.strokeStyle = '#f4f7fb';
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(x + 9.4, y + 3.2);
      g.lineTo(x + 13, y - 4.5);
      g.stroke();
    }
    // статус
    if (p.state === 'sleep') {
      g.font = 'bold 11px sans-serif';
      g.fillStyle = '#d9e2ff';
      g.fillText('z z', x + 6, y - 10);
    } else if (p.state === 'fight') {
      g.font = 'bold 11px sans-serif';
      g.fillStyle = '#ff6a5a';
      g.fillText('!', x - 1, y - 12);
    } else if (p.state === 'flee') {
      // паника: пульсирующий восклицательный знак — видно и в движении, и издалека
      const pulse = 1 + 0.35 * Math.sin(performance.now() / 120);
      g.font = `bold ${Math.round(13 * pulse)}px sans-serif`;
      g.fillStyle = '#ffd23c';
      g.strokeStyle = 'rgba(60,20,10,0.9)';
      g.lineWidth = 2;
      g.strokeText('❗', x - 4, y - 13);
      g.fillText('❗', x - 4, y - 13);
    }
    // груз
    if (p.inv) {
      g.fillStyle = p.inv.type === Res.Wood ? '#8a5f38' : p.inv.type === Res.Stone ? '#9a9ca0' : p.inv.type === Res.Meal ? '#e8a44a' : p.inv.type === Res.Iron ? '#7a818c' : p.inv.type === Res.Silver ? '#c9cdd5' : '#c94f5f';
      g.fillRect(x + 6, y - 2, 5, 5);
    }
    // HP
    if (p.hp < 99.5) {
      g.fillStyle = 'rgba(0,0,0,0.5)';
      g.fillRect(x - 9, y - 16, 18, 3);
      g.fillStyle = p.hp > 50 ? '#8fd05a' : '#e05545';
      g.fillRect(x - 9, y - 16, 18 * (p.hp / 100), 3);
    }
    // имя
    if (this.cam.zoom > 0.7) {
      g.font = '10px sans-serif';
      g.textAlign = 'center';
      g.strokeStyle = 'rgba(0,0,0,0.7)';
      g.lineWidth = 2.5;
      g.strokeText(p.name, x, y - 20);
      g.fillStyle = '#fff';
      g.fillText(p.name, x, y - 20);
      g.textAlign = 'left';
    }
  }

  private drawAnimal(g: CanvasRenderingContext2D, a: Animal) {
    const x = a.x * TILE;
    const y = a.y * TILE;
    g.fillStyle = 'rgba(0,0,0,0.22)';
    g.beginPath();
    g.ellipse(x, y + 6, 8, 3, 0, 0, Math.PI * 2);
    g.fill();
    if (a.kind === 'wolf') {
      g.fillStyle = '#5a5f66';
      g.beginPath();
      g.ellipse(x, y, 10, 6, 0, 0, Math.PI * 2);
      g.fill();
      g.beginPath();
      g.arc(x + 9, y - 3, 4.5, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#4a4f55';
      g.beginPath();
      g.moveTo(x + 6, y - 6);
      g.lineTo(x + 8, y - 11);
      g.lineTo(x + 10, y - 6);
      g.closePath();
      g.fill();
      g.fillStyle = '#d95a4a';
      g.beginPath();
      g.arc(x + 11, y - 4, 1.1, 0, Math.PI * 2);
      g.fill();
      if (a.hp < a.maxHp) {
        g.fillStyle = 'rgba(0,0,0,0.5)';
        g.fillRect(x - 9, y - 14, 18, 3);
        g.fillStyle = '#e05545';
        g.fillRect(x - 9, y - 14, 18 * (a.hp / a.maxHp), 3);
      }
      // штурмовик: красный «!» — идёт на лагерь / ломает стены
      if (a.siege || a.state === 'attackWall') {
        g.fillStyle = '#ff6a4a';
        g.fillRect(x - 1, y - 21, 2.4, 7);
        g.fillRect(x - 1, y - 12.5, 2.4, 2.4);
      }
    } else if (a.kind === 'deer') {
      // олень: крупное тело, рога
      g.fillStyle = '#8f6b47';
      g.beginPath();
      g.ellipse(x, y, 11, 6.5, 0, 0, Math.PI * 2);
      g.fill();
      g.beginPath();
      g.arc(x + 10, y - 4, 4, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#7a5a3a';
      g.beginPath();
      g.ellipse(x - 9, y + 3, 2.5, 4, 0, 0, Math.PI * 2);
      g.fill();
      // рога
      g.strokeStyle = '#d9c9a8';
      g.lineWidth = 1.6;
      g.beginPath();
      g.moveTo(x + 9, y - 7);
      g.lineTo(x + 7, y - 13);
      g.moveTo(x + 8, y - 10);
      g.lineTo(x + 5, y - 12);
      g.moveTo(x + 12, y - 7);
      g.lineTo(x + 13, y - 13);
      g.moveTo(x + 12.5, y - 10);
      g.lineTo(x + 15, y - 11.5);
      g.stroke();
      if (a.hp < a.maxHp) {
        g.fillStyle = 'rgba(0,0,0,0.5)';
        g.fillRect(x - 9, y - 16, 18, 3);
        g.fillStyle = '#e05545';
        g.fillRect(x - 9, y - 16, 18 * (a.hp / a.maxHp), 3);
      }
    } else if (a.kind === 'boar') {
      // кабан: коренастый, тёмно-бурый, с рылом и клыками
      g.fillStyle = '#5c4632';
      g.beginPath();
      g.ellipse(x, y, 10.5, 6.5, 0, 0, Math.PI * 2);
      g.fill();
      // щетина на спине
      g.strokeStyle = '#3d2e20';
      g.lineWidth = 1.2;
      g.beginPath();
      g.moveTo(x - 5, y - 6);
      g.lineTo(x - 3.5, y - 9);
      g.moveTo(x - 1, y - 6.5);
      g.lineTo(x + 0.5, y - 9.5);
      g.moveTo(x + 3, y - 6);
      g.lineTo(x + 4.5, y - 9);
      g.stroke();
      // голова с рылом
      g.fillStyle = '#4d3a28';
      g.beginPath();
      g.arc(x + 9, y - 1, 5, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#2e2216';
      g.beginPath();
      g.ellipse(x + 13, y, 2, 1.6, 0, 0, Math.PI * 2);
      g.fill();
      // белые клыки — знак «не зли меня»
      g.fillStyle = '#e8e0cc';
      g.beginPath();
      g.moveTo(x + 11, y + 2.5);
      g.lineTo(x + 12.5, y + 5.5);
      g.lineTo(x + 13.5, y + 2.5);
      g.closePath();
      g.fill();
      g.fillStyle = '#c94f3f';
      g.beginPath();
      g.arc(x + 10.5, y - 2.5, 1, 0, Math.PI * 2);
      g.fill();
      if (a.hp < a.maxHp) {
        g.fillStyle = 'rgba(0,0,0,0.5)';
        g.fillRect(x - 9, y - 15, 18, 3);
        g.fillStyle = '#e05545';
        g.fillRect(x - 9, y - 15, 18 * (a.hp / a.maxHp), 3);
      }
      // взбешён: красный «!»
      if (a.state === 'hunt') {
        g.fillStyle = '#ff6a4a';
        g.fillRect(x - 1, y - 21, 2.4, 7);
        g.fillRect(x - 1, y - 12.5, 2.4, 2.4);
      }
    } else if (a.kind === 'bear') {
      // медведь: крупный, тёмно-бурый, с горбом и круглыми ушами
      g.fillStyle = '#4a3524';
      g.beginPath();
      g.ellipse(x, y, 13, 8.5, 0, 0, Math.PI * 2);
      g.fill();
      // горб
      g.beginPath();
      g.ellipse(x - 3, y - 6, 7, 4.5, 0, Math.PI, Math.PI * 2);
      g.fill();
      // голова
      g.beginPath();
      g.arc(x + 12, y - 3, 5.5, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#382818';
      g.beginPath();
      g.ellipse(x + 15.5, y - 1.5, 2.2, 1.8, 0, 0, Math.PI * 2);
      g.fill();
      // уши
      g.beginPath();
      g.arc(x + 10, y - 7.5, 1.8, 0, Math.PI * 2);
      g.arc(x + 14, y - 7.5, 1.8, 0, Math.PI * 2);
      g.fill();
      // глаза
      g.fillStyle = '#d9a03f';
      g.beginPath();
      g.arc(x + 13.5, y - 4, 1, 0, Math.PI * 2);
      g.fill();
      // лапы
      g.fillStyle = '#382818';
      g.beginPath();
      g.ellipse(x - 8, y + 7, 3, 2.2, 0, 0, Math.PI * 2);
      g.ellipse(x + 6, y + 7, 3, 2.2, 0, 0, Math.PI * 2);
      g.fill();
      if (a.hp < a.maxHp) {
        g.fillStyle = 'rgba(0,0,0,0.5)';
        g.fillRect(x - 11, y - 17, 22, 3);
        g.fillStyle = '#e05545';
        g.fillRect(x - 11, y - 17, 22 * (a.hp / a.maxHp), 3);
      }
      if (a.state === 'hunt') {
        // разъярён: красный «!»
        g.fillStyle = '#ff6a4a';
        g.fillRect(x - 1, y - 24, 2.6, 8);
        g.fillRect(x - 1, y - 14, 2.6, 2.6);
      }
    } else if (a.kind === 'trader') {
      // торговец: человек в плаще с большим мешком за спиной
      g.fillStyle = '#6a4a7a';
      g.beginPath();
      g.arc(x, y + 2, 8, 0, Math.PI * 2);
      g.fill();
      // мешок с товаром
      g.fillStyle = '#8a6a45';
      g.beginPath();
      g.ellipse(x - 9, y + 1, 5.5, 6.5, 0.3, 0, Math.PI * 2);
      g.fill();
      g.strokeStyle = '#5a4028';
      g.lineWidth = 1.2;
      g.beginPath();
      g.moveTo(x - 7, y - 4);
      g.lineTo(x - 5, y - 1);
      g.stroke();
      // голова в капюшоне
      g.fillStyle = '#e8c49a';
      g.beginPath();
      g.arc(x, y - 5, 4.2, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#584068';
      g.beginPath();
      g.arc(x, y - 6.5, 4.4, Math.PI * 0.85, Math.PI * 2.15);
      g.fill();
      // монетка-значок караванщика
      g.fillStyle = '#d9b13f';
      g.beginPath();
      g.arc(x + 6, y - 4, 2, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#f0dfae';
      g.beginPath();
      g.arc(x + 5.5, y - 4.5, 0.7, 0, Math.PI * 2);
      g.fill();
    } else {
      // кролик: маленький, серо-белый, с ушами
      g.fillStyle = '#d8cfc0';
      g.beginPath();
      g.arc(x, y, 5, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = '#c8bfae';
      g.beginPath();
      g.ellipse(x - 1, y - 7, 1.5, 4, -0.3, 0, Math.PI * 2);
      g.ellipse(x + 2, y - 7, 1.5, 4, 0.3, 0, Math.PI * 2);
      g.fill();
    }
  }

  // ================= Ввод =================
  private attachInput() {
    const c = this.canvas;
    c.style.touchAction = 'none';
    c.addEventListener('pointerdown', (e) => {
      try {
        c.setPointerCapture(e.pointerId);
      } catch {
        // синтетические указатели нельзя захватить — не критично
      }
      this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (this.pointers.size === 1) {
        this.gesture = this.dragTools.includes(this.game.tool) ? 'maybeDrag' : 'maybePan';
        this.downX = e.clientX;
        this.downY = e.clientY;
        this.lastX = e.clientX;
        this.lastY = e.clientY;
        this.downT = performance.now();
        this.rectStart = null;
        this.rectCur = null;
      } else if (this.pointers.size === 2) {
        const pts = [...this.pointers.values()];
        this.pinchD0 = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        this.pinchZ0 = this.cam.zoom;
        this.pinchMX = (pts[0].x + pts[1].x) / 2;
        this.pinchMY = (pts[0].y + pts[1].y) / 2;
        this.gesture = 'pinch';
        this.rectStart = null;
        this.rectCur = null;
      }
    });
    c.addEventListener('pointermove', (e) => {
      const prev = this.pointers.get(e.pointerId);
      if (!prev) return;
      this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (this.gesture === 'pinch' && this.pointers.size >= 2) {
        const pts = [...this.pointers.values()];
        const d = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        const mx = (pts[0].x + pts[1].x) / 2;
        const my = (pts[0].y + pts[1].y) / 2;
        if (this.pinchD0 > 10) {
          this.cam.setZoom(this.pinchZ0 * (d / this.pinchD0));
          this.cam.x -= (mx - this.pinchMX) / this.cam.zoom;
          this.cam.y -= (my - this.pinchMY) / this.cam.zoom;
          this.cam.clampToMap();
        }
        this.pinchMX = mx;
        this.pinchMY = my;
        this.cam.followId = null;
        return;
      }
      const dx = e.clientX - this.lastX;
      const dy = e.clientY - this.lastY;
      const dDown = Math.hypot(e.clientX - this.downX, e.clientY - this.downY);
      if (this.gesture === 'maybePan' && dDown > 8) this.gesture = 'panning';
      if (this.gesture === 'panning') {
        this.cam.x -= dx / this.cam.zoom;
        this.cam.y -= dy / this.cam.zoom;
        this.cam.clampToMap();
        this.cam.followId = null;
      }
      if (this.gesture === 'maybeDrag' && dDown > 8) {
        this.gesture = 'dragging';
        const rect = this.canvas.getBoundingClientRect();
        this.rectStart = { x: this.downX - rect.left, y: this.downY - rect.top };
      }
      if (this.gesture === 'dragging') {
        const rect = this.canvas.getBoundingClientRect();
        this.rectCur = { x: e.clientX - rect.left, y: e.clientY - rect.top };
      }
      this.lastX = e.clientX;
      this.lastY = e.clientY;
    });
    const up = (e: PointerEvent) => {
      if (!this.pointers.has(e.pointerId)) return;
      this.pointers.delete(e.pointerId);
      if (this.gesture === 'pinch') {
        if (this.pointers.size === 0) this.gesture = 'none';
        return;
      }
      const dt = performance.now() - this.downT;
      if (this.gesture === 'maybePan' && dt < 400) {
        const rect = this.canvas.getBoundingClientRect();
        const sx = e.clientX - rect.left;
        const sy = e.clientY - rect.top;
        // двойной тап
        const now = performance.now();
        if (now - this.lastTapT < 320 && Math.hypot(sx - this.lastTapX, sy - this.lastTapY) < 26) {
          this.cam.setZoom(this.cam.zoom * 1.6, sx, sy, this.viewW, this.viewH);
          this.lastTapT = 0;
        } else {
          this.lastTapT = now;
          this.lastTapX = sx;
          this.lastTapY = sy;
          const wpt = this.cam.screenToWorld(sx, sy, this.viewW, this.viewH);
          this.game.applyTap(wpt.x / TILE, wpt.y / TILE);
        }
      } else if (this.gesture === 'maybeDrag' && dt < 400) {
        // короткий тап с активным инструментом — приказ на одну клетку
        const rect = this.canvas.getBoundingClientRect();
        const sx = e.clientX - rect.left;
        const sy = e.clientY - rect.top;
        const wpt = this.cam.screenToWorld(sx, sy, this.viewW, this.viewH);
        this.game.applyTap(wpt.x / TILE, wpt.y / TILE);
      } else if (this.gesture === 'dragging' && this.rectStart && this.rectCur) {
        const a = this.cam.screenToWorld(Math.min(this.rectStart.x, this.rectCur.x), Math.min(this.rectStart.y, this.rectCur.y), this.viewW, this.viewH);
        const bpt = this.cam.screenToWorld(Math.max(this.rectStart.x, this.rectCur.x), Math.max(this.rectStart.y, this.rectCur.y), this.viewW, this.viewH);
        // screenToWorld даёт мировые ПИКСЕЛИ — приказы ждут координаты клеток
        this.game.applyRect(Math.floor(a.x / TILE), Math.floor(a.y / TILE), Math.floor(bpt.x / TILE), Math.floor(bpt.y / TILE));
      }
      this.gesture = 'none';
      this.rectStart = null;
      this.rectCur = null;
    };
    c.addEventListener('pointerup', up);
    c.addEventListener('pointercancel', up);
    c.addEventListener(
      'wheel',
      (e) => {
        e.preventDefault();
        const rect = this.canvas.getBoundingClientRect();
        const sx = e.clientX - rect.left;
        const sy = e.clientY - rect.top;
        this.cam.setZoom(this.cam.zoom * Math.pow(1.0015, -e.deltaY), sx, sy, this.viewW, this.viewH);
        this.cam.followId = null;
      },
      { passive: false },
    );
  }
}

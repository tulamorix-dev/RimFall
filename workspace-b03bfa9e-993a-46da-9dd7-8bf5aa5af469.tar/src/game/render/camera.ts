// Камера: панорама, зум, слежение за пешкой

import { MAP, TILE } from '../data/defs';
import { clamp } from '../core/util';

export class Camera {
  x = (MAP / 2) * TILE; // центр во мировых пикселях
  y = (MAP / 2) * TILE;
  zoom = 1;
  minZoom = 0.55;
  maxZoom = 3.0;
  followId: number | null = null;
  lastViewW = 800;
  lastViewH = 600;

  clampToMap() {
    const lim = MAP * TILE;
    this.x = clamp(this.x, 0, lim);
    this.y = clamp(this.y, 0, lim);
  }

  setZoom(z: number, focusScreenX?: number, focusScreenY?: number, viewW = 0, viewH = 0) {
    const old = this.zoom;
    const nz = clamp(z, this.minZoom, this.maxZoom);
    if (focusScreenX !== undefined && focusScreenY !== undefined && viewW > 0 && viewH > 0) {
      // мировая точка под курсором до зума
      const wx = this.x + (focusScreenX - viewW / 2) / old;
      const wy = this.y + (focusScreenY - viewH / 2) / old;
      this.zoom = nz;
      // удержать точку под курсором
      this.x = wx - (focusScreenX - viewW / 2) / nz;
      this.y = wy - (focusScreenY - viewH / 2) / nz;
    } else {
      this.zoom = nz;
    }
    this.clampToMap();
  }

  screenToWorld(sx: number, sy: number, viewW: number, viewH: number): { x: number; y: number } {
    return {
      x: this.x + (sx - viewW / 2) / this.zoom,
      y: this.y + (sy - viewH / 2) / this.zoom,
    };
  }
}

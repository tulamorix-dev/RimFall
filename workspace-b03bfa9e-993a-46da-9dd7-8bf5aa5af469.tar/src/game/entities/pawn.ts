// Пешка: данные колониста (нужды, навыки, черты, инвентарь, состояние)
// Логика поведения — в ai/pawnAI.ts, чтобы симуляция была отделена от всего остального.

import { CARRY_CAP, PAWN_COLORS, SKILLS, SkillId, WorkCat, HUNGER_RATE, WeaponKind, ArmorKind } from '../data/defs';
import type { PathNode } from '../world/pathfinding';
import { clamp } from '../core/util';

export type PawnState = 'idle' | 'move' | 'work' | 'eat' | 'sleep' | 'fight' | 'flee' | 'break';

// Тип срыва: оскорбляет всех подряд / плачет у костра / бродит в оцепенении
export type BreakKind = 'insult' | 'sob' | 'daze';

export interface ActiveJob {
  kind: 'chop' | 'mine' | 'harvest' | 'till' | 'plant' | 'crop' | 'build' | 'haul' | 'loot' | 'bury' | 'cook' | 'craft' | 'hunt' | 'expedition' | 'equip' | 'eat' | 'sleep' | 'doctor' | 'warm';
  tile: number;
  itemId?: number;
  buildingId?: number;
  recipe?: number; // для craft: индекс рецепта в RECIPES
  stage: number;
  progress: number;
  jobRef?: number;
  ground?: boolean; // спит на земле
}

export interface MoodMod {
  id: string;
  label: string;
  delta: number;
  until: number; // игровое время окончания (0 = пока действует условие)
}

export interface SkillState {
  lvl: number;
  xp: number;
}

export class Pawn {
  id: number;
  name: string;
  gender: 'м' | 'ж';
  age: number;
  color: string;
  traits: string[];

  x: number;
  y: number;

  hp = 100;
  food = 100; // сытость
  rest = 100; // бодрость

  skills: Record<SkillId, SkillState>;
  priorities: WorkCat[];
  inv: { type: number; qty: number } | null = null;
  bedId: number | null = null;
  weapon: WeaponKind | null = null; // копьё, лук или меч (смерть роняет оружие на землю)
  cloth: 'coat' | null = null; // тёплая куртка: зима не страшна (смерть роняет на землю)
  armor: ArmorKind | null = null; // броня: гасит часть урона зверей

  state: PawnState = 'idle';
  job: ActiveJob | null = null;
  path: PathNode[] | null = null;
  pathI = 0;
  repathCd = 0;

  combatTargetId: number | null = null; // id животного
  resumeRef?: number; // ref задачи с доски, к которой пешка вернётся после сна/бегства/трапезы
  unreachN = 0; // подряд неуспешных попыток пути к цели боя (разрыв боя после 3)
  huntFailN = 0; // подряд неуспешных попыток пути к помеченной дичи (снятие метки после 4)
  atkCd = 0;
  aiT = 0;
  talkCd = 0;
  fleeT = 0;
  eatT = 0;
  wanderT = 0;
  mods: MoodMod[] = [];
  sickMin = 0; // игровых минут болезни; лечится сном, медицина ускоряет
  breakMin = 0; // игровых минут срыва (0 — пешка в норме)
  breakKind: BreakKind | null = null;
  breakCd = 0; // кулдаун до возможного следующего срыва
  insultT = 0; // таймер следующей вспышки оскорблений
  noRegen = false; // игра ставит при обморожении: регенерация отключена
  underground = false; // пешка в шахтной экспедиции: скрыта, звери её не чуют
  dead = false;

  constructor(id: number, name: string, x: number, y: number, colorIdx: number, traits: string[], gender: 'м' | 'ж', age: number) {
    this.id = id;
    this.name = name;
    this.x = x;
    this.y = y;
    this.color = PAWN_COLORS[colorIdx % PAWN_COLORS.length];
    this.traits = traits;
    this.gender = gender;
    this.age = age;
    this.skills = Object.fromEntries(SKILLS.map((s) => [s.id, { lvl: 0, xp: 0 }])) as Record<SkillId, SkillState>;
    // Приоритеты: готовка наверху (сытая колония важнее запасов), переноска — внизу.
    // Игрок может переставить в карточке пешки (▲/▼).
    this.priorities = ['cook', 'build', 'farm', 'lumber', 'hunt', 'mine', 'haul'];
  }

  hasTrait(id: string): boolean {
    return this.traits.includes(id);
  }

  skillLvl(id: SkillId): number {
    return this.skills[id].lvl;
  }

  addXp(id: SkillId, amount = 2) {
    const s = this.skills[id];
    if (s.lvl >= 20) return;
    s.xp += amount;
    const need = (s.lvl + 1) * 12;
    if (s.xp >= need) {
      s.xp -= need;
      s.lvl = Math.min(20, s.lvl + 1);
    }
  }

  // Множитель скорости работы: навык, черта, настроение
  workMult(skill: SkillId, mood: number): number {
    let m = 1 + this.skillLvl(skill) * 0.03;
    if (this.hasTrait('hardworker')) m *= 1.15;
    if (mood < 25) m *= 0.8;
    else if (mood > 75) m *= 1.1;
    if (this.rest < 10) m *= 0.6;
    if (this.sickMin > 0) m *= 0.65; // болеет — работает через силу
    return m;
  }

  walkMult(): number {
    return this.hasTrait('fidget') ? 1.2 : 1;
  }

  addMod(id: string, label: string, delta: number, durationMin: number, now: number) {
    this.removeMod(id);
    this.mods.push({ id, label, delta, until: now + durationMin });
  }

  removeMod(id: string) {
    const k = this.mods.findIndex((m) => m.id === id);
    if (k >= 0) this.mods.splice(k, 1);
  }

  hasMod(id: string): boolean {
    return this.mods.some((m) => m.id === id);
  }

  // Базовое обновление нужд (вызывается каждый тик)
  decay(dtG: number, sleeping: boolean, sleepRate: number) {
    if (dtG <= 0) return;
    if (this.breakCd > 0) this.breakCd = Math.max(0, this.breakCd - dtG);
    if (!sleeping) {
      this.food = clamp(this.food - HUNGER_RATE * dtG, 0, 100);
      let drain = 100 / 1080;
      if (this.hasTrait('sleeper')) drain *= 0.85;
      this.rest = clamp(this.rest - drain * dtG, 0, 100);
    } else {
      this.rest = clamp(this.rest + sleepRate * dtG, 0, 100);
      this.food = clamp(this.food - HUNGER_RATE * 0.6 * dtG, 0, 100); // во сне тратим меньше
    }
    // голод убивает
    if (this.food <= 0) {
      this.hp = clamp(this.hp - 0.02 * dtG, 0, 100);
    }
    // регенерация: сон лечит заметно лучше; навык «Медицина» ускоряет (мёрзнущее тело не лечится)
    if (!this.noRegen && this.food > 40 && this.rest > 25 && this.hp < 100 && this.hp > 0) {
      const med = 1 + this.skillLvl('medicine') * 0.06;
      const rate = (sleeping ? 0.055 : 0.012) * med;
      this.hp = clamp(this.hp + rate * dtG, 0, 100);
      if (sleeping) this.addXp('medicine', dtG / 10); // перевязка и уход за собой во сне
    }
    // истёкшие модификаторы настроения
    if (this.mods.length > 0) {
      const now = this.modsNow;
      this.mods = this.mods.filter((m) => m.until === 0 || m.until > now);
    }
  }

  modsNow = 0; // устанавливается игрой перед decay

  canCarryMore(type: number): boolean {
    if (!this.inv) return true;
    return this.inv.type === type && this.inv.qty < CARRY_CAP;
  }
}

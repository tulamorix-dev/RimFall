// Животные: волк (опасность), кролик и олень (источники еды),
// кабан (свирепая дичь, дерётся в ответ), медведь (редкая угроза)
// и торговец (караван: мирно ждёт у лагеря, ходит по своим делам).
// Тоже AI-сущности.

import type { PathNode } from '../world/pathfinding';

export type AnimalKind = 'wolf' | 'rabbit' | 'deer' | 'boar' | 'bear' | 'trader';
// 'siege' — волк идёт на штурм лагеря: путь к костру/складу, стены ломает специально
export type AnimalState = 'wander' | 'hunt' | 'attackWall' | 'flee' | 'siege' | 'arrive' | 'wait' | 'leave';

export class Animal {
  id: number;
  kind: AnimalKind;
  x: number;
  y: number;
  hp: number;
  maxHp: number;

  state: AnimalState = 'wander';
  targetPawnId: number | null = null;
  targetBuildingId: number | null = null;
  path: PathNode[] | null = null;
  pathI = 0;
  atkCd = 0;
  wanderT = 0;
  aiT = 0;
  dead = false;
  siege = false; // участник стаи-штурма: цель — центр лагеря, стены ломает нарочно

  constructor(id: number, kind: AnimalKind, x: number, y: number) {
    this.id = id;
    this.kind = kind;
    this.x = x;
    this.y = y;
    this.maxHp = kind === 'bear' ? 90 : kind === 'wolf' ? 40 : kind === 'boar' ? 45 : kind === 'deer' ? 30 : kind === 'trader' ? 55 : 8;
    this.hp = this.maxHp;
  }

  get speed(): number {
    if (this.kind === 'bear') return 0.8; // тяжёлый, но не отстанет
    if (this.kind === 'boar') return 0.95; // чуть быстрее пешки — убежать сложно
    if (this.kind === 'wolf') return 1.05; // клеток за игровую минуту
    if (this.kind === 'deer') return 1.2; // быстрый, но пугливый bursts-беглец
    if (this.kind === 'trader') return 0.8; // караван не спешит — везёт товар
    return 1.35;
  }

  get name(): string {
    switch (this.kind) {
      case 'wolf':
        return 'Волк';
      case 'deer':
        return 'Олень';
      case 'boar':
        return 'Кабан';
      case 'bear':
        return 'Медведь';
      case 'trader':
        return 'Торговец';
      default:
        return 'Кролик';
    }
  }
}

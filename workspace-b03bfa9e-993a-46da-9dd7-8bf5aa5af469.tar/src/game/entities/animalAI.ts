// Поведение животных: волк охотится (или ломает стены), кролик и олень пасутся и убегают,
// кабан мирно бродит, но ответным уроном взбешивается, медведь защищает свои угодья

import { BEAR_ATK, BEAR_ATK_RAND, BEAR_TERRITORY, BOAR_ATK, BOAR_ATK_RAND, BType, TRAP_DMG, TRAP_RAND, MAP } from '../data/defs';
import type { Game } from '../core/game';
import type { Animal } from './animal';
import { dist } from '../core/util';
import { pathToTile } from '../world/pathfinding';

function setPath(animal: Animal, path: { x: number; y: number }[] | null): boolean {
  if (!path) return false;
  animal.path = path;
  animal.pathI = 0;
  return true;
}

function step(animal: Animal, dtG: number): boolean {
  if (!animal.path || animal.pathI >= animal.path.length) return true;
  let budget = animal.speed * dtG;
  while (budget > 0 && animal.path && animal.pathI < animal.path.length) {
    const node = animal.path[animal.pathI];
    const tx = node.x + 0.5;
    const ty = node.y + 0.5;
    const dx = tx - animal.x;
    const dy = ty - animal.y;
    const d = Math.hypot(dx, dy);
    if (d <= budget) {
      animal.x = tx;
      animal.y = ty;
      budget -= d;
      animal.pathI++;
    } else {
      animal.x += (dx / d) * budget;
      animal.y += (dy / d) * budget;
      budget = 0;
    }
  }
  return !animal.path || animal.pathI >= animal.path.length;
}

// Зверь, представляющий угрозу лагерю (напорется в ловушку)
function isHostile(a: Animal): boolean {
  if (a.kind === 'wolf') return true;
  if (a.kind === 'boar') return a.state === 'hunt';
  if (a.kind === 'bear') return a.state === 'hunt';
  return false;
}

function checkTrap(game: Game, a: Animal) {
  const b = game.world.buildingAt(Math.floor(a.x), Math.floor(a.y));
  if (!b || b.blueprint || b.type !== BType.Trap) return;
  if (!isHostile(a)) return;
  game.world.removeBuilding(b);
  game.renderDirtyTile(b.x, b.y);
  game.events.log(`${a.name} угодил(а) в ловушку из кольев!`, 'good');
  game.damageAnimal(a, TRAP_DMG + Math.random() * TRAP_RAND);
}

export function updateAnimal(game: Game, animal: Animal, dtG: number) {
  if (animal.dead) return;
  animal.atkCd = Math.max(0, animal.atkCd - dtG);
  animal.aiT -= dtG;

  // ловушка из кольев: зверь наступил — колья вонзаются и ломаются
  if (animal.kind !== 'trader' && animal.kind !== 'rabbit' && animal.kind !== 'deer') checkTrap(game, animal);
  if (animal.dead) return;

  if (animal.kind === 'trader') {
    updateTrader(game, animal, dtG);
    return;
  }
  if (animal.kind === 'rabbit') {
    updateRabbit(game, animal, dtG);
    return;
  }
  if (animal.kind === 'deer') {
    updateDeer(game, animal, dtG);
    return;
  }
  if (animal.kind === 'boar') {
    updateBoar(game, animal, dtG);
    return;
  }
  if (animal.kind === 'bear') {
    updateBear(game, animal, dtG);
    return;
  }
  updateWolf(game, animal, dtG);
}
// ================= Олень =================
// Пасётся дальше от лагеря, пугливее кролика, но бегает короткими рывками —
// упорная погоня или загон в угол позволяют добыть много мяса.
function updateDeer(game: Game, animal: Animal, dtG: number) {
  if (animal.state === 'flee') {
    if (step(animal, dtG)) {
      animal.state = 'wander';
      animal.path = null;
    }
    return;
  }
  // пугливость: пешка ближе 4 клеток — бегство
  if (animal.aiT <= 0) {
    animal.aiT = 0.5;
    for (const p of game.pawns) {
      if (p.dead || p.underground) continue;
      if (dist(animal.x, animal.y, p.x, p.y) < 4) {
        deerFleeFrom(game, animal, p.x, p.y, 7);
        break;
      }
    }
  }
  // если испугались — сразу бежим (состояние читаем через вызов — без сужения типов)
  if (isFleeing(animal)) {
    step(animal, dtG);
    return;
  }
  if (!animal.path || animal.pathI >= animal.path.length) {
    animal.wanderT -= 0.5;
    if (animal.wanderT <= 0) {
      animal.wanderT = 8 + Math.random() * 12;
      const tx = Math.max(1, Math.min(62, Math.floor(animal.x + (Math.random() * 16 - 8))));
      const ty = Math.max(1, Math.min(62, Math.floor(animal.y + (Math.random() * 16 - 8))));
      if (game.world.passAnimal(tx, ty)) {
        setPath(animal, pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), tx, ty, true));
      }
    }
  } else {
    step(animal, dtG);
  }
}

function deerFleeFrom(game: Game, animal: Animal, fx: number, fy: number, runLen: number) {
  animal.state = 'flee';
  const dx = Math.sign(animal.x - fx || (Math.random() < 0.5 ? -1 : 1)) * runLen;
  const dy = Math.sign(animal.y - fy || (Math.random() < 0.5 ? -1 : 1)) * runLen;
  const tx = Math.max(1, Math.min(62, Math.floor(animal.x + dx)));
  const ty = Math.max(1, Math.min(62, Math.floor(animal.y + dy)));
  if (game.world.passAnimal(tx, ty)) {
    setPath(animal, pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), tx, ty, true));
  }
}

function isFleeing(a: Animal): boolean {
  return a.state === 'flee';
}

// ================= Торговец (караван) =================
// Мирный человек с поклажей: приходит к складу, ждёт несколько часов
// (можно поторговать), затем уходит туда, откуда пришёл. Волки его не чуют.
const TRADER_STAY = 360; // игровых минут на торговлю (6 часов)

function updateTrader(game: Game, animal: Animal, dtG: number) {
  switch (animal.state) {
    case 'arrive': {
      if (!animal.path || animal.pathI >= animal.path.length) {
        // путь кончился/не построен: пробуем дойти до склада, иначе ждём где стоим
        const c = game.world.stockpileCenter() ?? game.centerBase();
        const p = pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), Math.floor(c.x), Math.floor(c.y), true);
        if (p && p.length > 0) {
          animal.path = p;
          animal.pathI = 0;
        } else {
          animal.state = 'wait';
          animal.wanderT = TRADER_STAY;
        }
        return;
      }
      if (step(animal, dtG)) {
        animal.state = 'wait';
        animal.wanderT = TRADER_STAY;
        game.events.log('Караван расположился у лагеря. Пора поторговать — серебро звенит в мешках.', 'good');
      }
      return;
    }
    case 'leave': {
      if (step(animal, dtG)) {
        game.events.log('Караван ушёл за горизонт — серебро и товары с ним. Ждём следующего.', 'info');
        game.removeAnimal(animal);
      }
      return;
    }
    case 'wait':
    default: {
      animal.wanderT -= dtG;
      if (animal.wanderT <= 0) {
        // время вышло — домой, к ближайшему краю
        animal.state = 'leave';
        const ex = animal.x < MAP / 2 ? 1 : MAP - 2;
        const ey = animal.y < MAP / 2 ? 1 : MAP - 2;
        const tx = Math.abs(animal.x - ex) < Math.abs(animal.y - ey) ? ex : Math.floor(animal.x);
        const ty = Math.abs(animal.x - ex) < Math.abs(animal.y - ey) ? Math.floor(animal.y) : ey;
        const p = pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), tx, ty, true);
        animal.path = p ?? [];
        animal.pathI = 0;
        game.closeTrade(animal.id);
        return;
      }
      // лёгкое переминание на месте, чтобы караван жил
      return;
    }
  }
}

// ================= Волк =================
// Обычный волк охотится на того, кого учуял. Волк-штурмовик (siege) идёт к центру
// лагеря: если путь свободен — рвётся к костру и складу, если путь закрыт стеной —
// целенаправленно проломает её и продолжает штурм.
function updateWolf(game: Game, animal: Animal, dtG: number) {
  const night = game.clock.light < 0.45;
  const sense = night ? 13 : 7;

  if (animal.state === 'flee') {
    if (step(animal, dtG)) {
      // добежал до края карты — уходит
      game.removeAnimal(animal);
      game.events.log('Волк убежал в темноту леса.', 'info');
    }
    return;
  }

  // поиск добычи (штурмовик тоже не упустит жертву прямо перед носом; торговца не трогаем)
  if (animal.aiT <= 0) {
    animal.aiT = 0.6;
    let prey = null;
    let pd = Infinity;
    for (const p of game.pawns) {
      if (p.dead || p.underground) continue;
      const d = dist(animal.x, animal.y, p.x, p.y);
      if (d < pd) {
        pd = d;
        prey = p;
      }
    }
    const huntRange = animal.siege ? Math.min(sense, 8) : sense;
    if (prey && pd <= huntRange) {
      if (animal.state !== 'hunt' || animal.targetPawnId !== prey.id || !animal.path) {
        animal.state = 'hunt';
        animal.targetPawnId = prey.id;
        const p = pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), Math.floor(prey.x), Math.floor(prey.y), true);
        if (p) {
          setPath(animal, p);
        } else {
          // путь заблокирован стенами — ищем стену/дверь, чтобы проломить
          const b = nearestBlocker(game, animal, Math.floor(prey.x), Math.floor(prey.y));
          if (b) {
            animal.state = 'attackWall';
            animal.targetBuildingId = b.id;
            const pb = pathToAdjacentAnimal(game, animal, b.x, b.y);
            setPath(animal, pb);
          } else {
            animal.state = 'wander';
            animal.path = null;
          }
        }
      }
    } else if (animal.state === 'hunt') {
      // добыча потеряна: штурмовик возвращается к штурму, обычный — блуждает
      animal.state = animal.siege ? 'siege' : 'wander';
      animal.targetPawnId = null;
      animal.path = null;
    } else if (animal.siege && animal.state !== 'siege' && animal.state !== 'attackWall') {
      // штурмовик без добычи — снова к лагерю
      animal.state = 'siege';
      animal.path = null;
    }
  }

  switch (animal.state) {
    case 'hunt': {
      const prey = game.pawns.find((p) => p.id === animal.targetPawnId && !p.dead);
      if (!prey) {
        animal.state = animal.siege ? 'siege' : 'wander';
        animal.path = null;
        return;
      }
      const c = Math.max(Math.abs(Math.floor(animal.x) - Math.floor(prey.x)), Math.abs(Math.floor(animal.y) - Math.floor(prey.y)));
      if (c <= 1) {
        animal.path = null;
        if (animal.atkCd <= 0) {
          animal.atkCd = 1.0;
          game.damagePawn(prey, 5 + Math.random() * 4, animal);
        }
        return;
      }
      // если путь кончился, но не дошли — перестроить
      if (!animal.path || animal.pathI >= animal.path.length) {
        const p = pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), Math.floor(prey.x), Math.floor(prey.y), true);
        if (p) setPath(animal, p);
        else {
          const b = nearestBlocker(game, animal, Math.floor(prey.x), Math.floor(prey.y));
          if (b) {
            animal.state = 'attackWall';
            animal.targetBuildingId = b.id;
            setPath(animal, pathToAdjacentAnimal(game, animal, b.x, b.y));
          }
        }
      }
      step(animal, dtG);
      return;
    }
    case 'attackWall': {
      const b = game.world.buildings.find((bb) => bb.id === animal.targetBuildingId);
      if (!b || b.blueprint) {
        // стена пала (или снесена) — штурмовик продолжит путь к лагерю
        animal.targetBuildingId = null;
        animal.path = null;
        animal.state = animal.siege ? 'siege' : 'wander';
        return;
      }
      const c = Math.max(Math.abs(Math.floor(animal.x) - b.x), Math.abs(Math.floor(animal.y) - b.y));
      if (c <= 1) {
        animal.path = null;
        if (animal.atkCd <= 0) {
          animal.atkCd = 1.1;
          game.damageBuilding(b, 6 + Math.random() * 4, animal);
        }
        return;
      }
      if (!animal.path || animal.pathI >= animal.path.length) {
        const pb = pathToAdjacentAnimal(game, animal, b.x, b.y);
        if (pb && pb.length > 0) {
          setPath(animal, pb);
        } else {
          // пути к стене нет (волк зажат/застрял) — штурмовик вернётся к марш-броску,
          // обычный волк заблудится
          animal.targetBuildingId = null;
          animal.path = null;
          animal.state = animal.siege ? 'siege' : 'wander';
        }
      }
      step(animal, dtG);
      return;
    }
    case 'siege': {
      // штурм: путь к центру лагеря; стена на пути -> ломать её
      const center = game.centerBase();
      const c = Math.max(Math.abs(Math.floor(animal.x) - Math.floor(center.x)), Math.abs(Math.floor(animal.y) - Math.floor(center.y)));
      if (c <= 2) {
        // добрался до лагеря: рыщет между постройками в поисках жертвы
        animal.state = 'wander';
        animal.path = null;
        return;
      }
      if (!animal.path || animal.pathI >= animal.path.length) {
        const p = pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), Math.floor(center.x), Math.floor(center.y), true);
        if (p) setPath(animal, p);
        else {
          const b = nearestBlocker(game, animal, Math.floor(center.x), Math.floor(center.y));
          if (b) {
            animal.state = 'attackWall';
            animal.targetBuildingId = b.id;
            setPath(animal, pathToAdjacentAnimal(game, animal, b.x, b.y));
          } else {
            animal.state = 'wander';
          }
        }
      }
      step(animal, dtG);
      return;
    }
    case 'wander':
    default: {
      if (!animal.path || animal.pathI >= animal.path.length) {
        animal.wanderT -= 0.6;
        if (animal.wanderT <= 0) {
          animal.wanderT = 10 + Math.random() * 14;
          const tx = Math.max(1, Math.min(62, Math.floor(animal.x + (Math.random() * 14 - 7))));
          const ty = Math.max(1, Math.min(62, Math.floor(animal.y + (Math.random() * 14 - 7))));
          if (game.world.passAnimal(tx, ty)) {
            setPath(animal, pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), tx, ty, true));
          }
        }
      }
      step(animal, dtG);
      return;
    }
  }
}

function nearestBlocker(game: Game, animal: Animal, tx: number, ty: number): { id: number; x: number; y: number } | null {
  let best: { id: number; x: number; y: number } | null = null;
  let bestD = Infinity;
  for (const b of game.world.buildings) {
    if (b.blueprint) continue;
    if (b.type !== BType.Wall && b.type !== BType.Door && b.type !== BType.StoneWall) continue;
    const d = dist(animal.x, animal.y, b.x + 0.5, b.y + 0.5) + dist(b.x, b.y, tx, ty) * 0.5;
    if (d < bestD) {
      bestD = d;
      best = b;
    }
  }
  return best;
}

function pathToAdjacentAnimal(game: Game, animal: Animal, tx: number, ty: number) {
  const ax = Math.floor(animal.x);
  const ay = Math.floor(animal.y);
  const c = Math.max(Math.abs(ax - tx), Math.abs(ay - ty));
  if (c <= 1) return [];
  return pathToTile(game.world, ax, ay, tx, ty, true);
}

// ================= Кролик =================
function updateRabbit(game: Game, animal: Animal, dtG: number) {
  // испуг
  if (animal.state !== 'flee') {
    for (const p of game.pawns) {
      if (p.dead) continue;
      if (dist(animal.x, animal.y, p.x, p.y) < 3.5) {
        animal.state = 'flee';
        // убежать в противоположную сторону
        const dx = Math.sign(animal.x - p.x) * 6;
        const dy = Math.sign(animal.y - p.y) * 6;
        const tx = Math.max(1, Math.min(62, Math.floor(animal.x + dx)));
        const ty = Math.max(1, Math.min(62, Math.floor(animal.y + dy)));
        if (game.world.passAnimal(tx, ty)) {
          setPath(animal, pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), tx, ty, true));
        }
        break;
      }
    }
  }
  if (animal.state === 'flee') {
    if (step(animal, dtG)) {
      animal.state = 'wander';
      animal.path = null;
    }
    return;
  }
  if (!animal.path || animal.pathI >= animal.path.length) {
    animal.wanderT -= 0.5;
    if (animal.wanderT <= 0) {
      animal.wanderT = 6 + Math.random() * 10;
      const tx = Math.max(1, Math.min(62, Math.floor(animal.x + (Math.random() * 8 - 4))));
      const ty = Math.max(1, Math.min(62, Math.floor(animal.y + (Math.random() * 8 - 4))));
      if (game.world.passAnimal(tx, ty)) {
        setPath(animal, pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), tx, ty, true));
      }
    }
  } else {
    step(animal, dtG);
  }
}

// ================= Кабан =================
// Мирно бродит и не боится людей, но стоит ударить — взбешивается: бьёт обидчика
// и не отступает до конца. Опасная, но самая мясистая дичь со шкурой.
function updateBoar(game: Game, animal: Animal, dtG: number) {
  // взбешён: преследуем обидчика
  if (animal.state === 'hunt') {
    const prey = game.pawns.find((p) => p.id === animal.targetPawnId && !p.dead);
    if (!prey) {
      animal.state = 'wander';
      animal.targetPawnId = null;
      animal.path = null;
      return;
    }
    const c = Math.max(Math.abs(Math.floor(animal.x) - Math.floor(prey.x)), Math.abs(Math.floor(animal.y) - Math.floor(prey.y)));
    if (c <= 1) {
      animal.path = null;
      if (animal.atkCd <= 0) {
        animal.atkCd = 1.1;
        game.damagePawn(prey, BOAR_ATK + Math.random() * BOAR_ATK_RAND, animal);
      }
      return;
    }
    // даже взбешённый кабан не бежит до края мира — остыл и ушёл в чащу
    if (dist(animal.x, animal.y, prey.x, prey.y) > 16) {
      animal.state = 'wander';
      animal.targetPawnId = null;
      animal.path = null;
      game.events.log('Кабан выдохся и ушёл в чащу.', 'info');
      return;
    }
    if (!animal.path || animal.pathI >= animal.path.length) {
      // стены кабан не ломает: если путь закрыт — рычит и уходит
      const p = pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), Math.floor(prey.x), Math.floor(prey.y), true);
      if (!p) {
        animal.state = 'wander';
        animal.targetPawnId = null;
        game.events.log('Кабан повозмущался и ушёл в чащу.', 'info');
        return;
      }
      setPath(animal, p);
    }
    step(animal, dtG);
    return;
  }
  // обычная жизнь: медленно бродит
  if (!animal.path || animal.pathI >= animal.path.length) {
    animal.wanderT -= 0.5;
    if (animal.wanderT <= 0) {
      animal.wanderT = 7 + Math.random() * 11;
      const tx = Math.max(1, Math.min(62, Math.floor(animal.x + (Math.random() * 12 - 6))));
      const ty = Math.max(1, Math.min(62, Math.floor(animal.y + (Math.random() * 12 - 6))));
      if (game.world.passAnimal(tx, ty)) {
        setPath(animal, pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), tx, ty, true));
      }
    }
  } else {
    step(animal, dtG);
  }
}

// ================= Медведь =================
// Хозяин леса: бродит по своим угодьям, но каждого, кто подошёл вплотную,
// гонит прочь когтями. Раненый медведь страшнее всего. Отбегает, лишь когда совсем плох.
function updateBear(game: Game, animal: Animal, dtG: number) {
  if (animal.state === 'flee') {
    if (step(animal, dtG)) {
      animal.state = 'wander';
      animal.path = null;
    }
    return;
  }
  // выбор жертвы: обидчик приоритетнее, иначе — слишком близко подошедший
  if (animal.aiT <= 0) {
    animal.aiT = 0.5;
    if (animal.state !== 'hunt') {
      const intruder = game.pawns.find((p) => !p.dead && !p.underground && dist(animal.x, animal.y, p.x, p.y) < BEAR_TERRITORY);
      if (intruder) {
        animal.state = 'hunt';
        animal.targetPawnId = intruder.id;
        animal.path = null;
        game.events.log(`Медведь встал на дыбы — ${intruder.name} забрёл в его угодья!`, 'bad');
        // хищник у лагеря — тревога: колонисты готовятся, игрок при автопаузе успевает среагировать
        const base = game.centerBase();
        if (dist(animal.x, animal.y, base.x, base.y) < 14) game.raiseAlarm(90);
      }
    }
  }
  if (animal.state === 'hunt') {
    const prey = game.pawns.find((p) => p.id === animal.targetPawnId && !p.dead);
    if (!prey) {
      animal.state = 'wander';
      animal.targetPawnId = null;
      animal.path = null;
      return;
    }
    const c = Math.max(Math.abs(Math.floor(animal.x) - Math.floor(prey.x)), Math.abs(Math.floor(animal.y) - Math.floor(prey.y)));
    if (c <= 1) {
      animal.path = null;
      if (animal.atkCd <= 0) {
        animal.atkCd = 1.4;
        game.damagePawn(prey, BEAR_ATK + Math.random() * BEAR_ATK_RAND, animal);
      }
      return;
    }
    // жертва убежала далеко — медведь не преследует до края мира: вернулся в чащу
    if (dist(animal.x, animal.y, prey.x, prey.y) > 14) {
      animal.state = 'wander';
      animal.targetPawnId = null;
      animal.path = null;
      game.events.log('Медведь поворчал и вернулся в свои угодья.', 'info');
      return;
    }
    if (!animal.path || animal.pathI >= animal.path.length) {
      const p = pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), Math.floor(prey.x), Math.floor(prey.y), true);
      if (!p) {
        // до обидчика не пробраться — ворчливо уходит
        animal.state = 'wander';
        animal.targetPawnId = null;
        return;
      }
      setPath(animal, p);
    }
    step(animal, dtG);
    return;
  }
  // обычная жизнь: неспешно патрулирует чащу
  if (!animal.path || animal.pathI >= animal.path.length) {
    animal.wanderT -= 0.5;
    if (animal.wanderT <= 0) {
      animal.wanderT = 9 + Math.random() * 13;
      const tx = Math.max(1, Math.min(62, Math.floor(animal.x + (Math.random() * 14 - 7))));
      const ty = Math.max(1, Math.min(62, Math.floor(animal.y + (Math.random() * 14 - 7))));
      if (game.world.passAnimal(tx, ty)) {
        setPath(animal, pathToTile(game.world, Math.floor(animal.x), Math.floor(animal.y), tx, ty, true));
      }
    }
  } else {
    step(animal, dtG);
  }
}

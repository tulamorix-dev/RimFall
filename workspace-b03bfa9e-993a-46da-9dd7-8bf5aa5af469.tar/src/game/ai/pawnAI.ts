// AI пешек: оценка состояния -> угрозы -> потребности -> приоритеты -> работа.
// Логика отделена от данных Pawn и от рендера (правило архитектуры).

import { BType, Terrain, BOW_RANGE, CARRY_CAP, DINED_MIN, DINED_MOOD, DINE_SEARCH_R, EAT_QTY, EAT_SATIETY, FIRE_WARM_R, MAP, MEAL_EAT_QTY, MEAL_RAW, MEAL_SATIETY, Obj, RECIPES, Res, SPEAR_DMG_BONUS, SWORD_ATK_CD, SWORD_DMG, SWORD_DMG_RAND, WEAPON_NAMES, WEAPON_RES, WORK_TIME, WALK, XP_PER_ACTION, YIELDS, Zone, FarmStage, craftMat, craftNeed } from '../data/defs';
import type { Game } from '../core/game';
import type { Pawn, ActiveJob, BreakKind } from '../entities/pawn';
import type { Animal } from '../entities/animal';
import type { Building } from '../buildings/buildings';
import { cheb, dist } from '../core/util';
import { pathToTile, pathToAdjacent, type PathNode } from '../world/pathfinding';
import type { Job, JobExt } from './jobs';
import { hunterCapable } from './jobs';

// ===================== Вспомогательные =====================

function setPath(game: Game, pawn: Pawn, path: PathNode[] | null): boolean {
  if (path === null) return false;
  pawn.path = path;
  pawn.pathI = 0;
  pawn.state = 'move';
  return true;
}

// Тир оружия для авто-апгрейда: пешка меняет снаряжение только на более сильное.
// Меч — лучший ближний бой, лук — дальний (и единственный против бегущей дичи), копьё — начало пути.
export const WEAPON_TIER: Record<string, number> = { sword: 3, bow: 2, spear: 1 };

// Пешка запоминает задачу с доски: после сна/бегства/трапезы/мороза она вернётся к ней,
// а не «забудет, что делала» (RimWorld-style resume). Перезаписываем только когда
// пешка несла задачу с доски — иначе затрём память о прежней задаче (бегство -> бой).
function rememberBoardJob(pawn: Pawn) {
  if (pawn.job?.jobRef !== undefined) pawn.resumeRef = pawn.job.jobRef;
}

export function releaseBoardJob(game: Game, pawn: Pawn) {
  if (pawn.job && pawn.job.jobRef !== undefined) {
    const job = game.jobs.jobs.get(pawn.job.jobRef);
    if (job) game.jobs.release(job, pawn.id);
  }
  pawn.job = null;
}

function nearestWolf(game: Game, pawn: Pawn): { wolf: Animal | null; d: number } {
  let best: Animal | null = null;
  let bestD = Infinity;
  for (const a of game.animals) {
    if (a.dead || a.kind !== 'wolf') continue;
    const d = dist(pawn.x, pawn.y, a.x, a.y);
    if (d < bestD) {
      bestD = d;
      best = a;
    }
  }
  return { wolf: best, d: bestD };
}

// Хищник, опасный для пешки: волк чует кровь всегда, медведь и кабан — когда
// преследуют (state hunt). Живот, идущий именно на нас, опаснее расстояния.
function isPredator(a: Animal): boolean {
  if (a.dead) return false;
  if (a.kind === 'wolf') return true;
  return a.state === 'hunt' && (a.kind === 'bear' || a.kind === 'boar');
}

export function nearestThreat(game: Game, pawn: Pawn, maxD = 7): { beast: Animal | null; d: number } {
  let best: Animal | null = null;
  let bestD = Infinity;
  for (const a of game.animals) {
    if (!isPredator(a)) continue;
    const d = dist(pawn.x, pawn.y, a.x, a.y);
    const targeted = a.targetPawnId === pawn.id;
    // идущий на нас зверь важен на любом расстоянии; прочие — только вблизи
    if (!targeted && d >= maxD) continue;
    if (d < bestD) {
      bestD = d;
      best = a;
    }
  }
  return { beast: best, d: bestD };
}

// Охотник не паникует от СВОЕЙ помеченной дичи: он сам идёт её добывать.
// Чужой зверь рядом — как раньше: бой или бегство.
function isHuntingTarget(pawn: Pawn, animalId: number): boolean {
  return pawn.weapon !== null && pawn.job !== null && pawn.job.kind === 'hunt' && pawn.job.itemId === animalId;
}

export function moodList(game: Game, pawn: Pawn): { label: string; delta: number }[] {
  const out: { label: string; delta: number }[] = [];
  const greedy = pawn.hasTrait('greedy');
  if (pawn.food > 85) out.push({ label: 'Сыт и доволен', delta: 4 });
  else if (pawn.food < 12) out.push({ label: 'На грани голода', delta: greedy ? -20 : -15 });
  else if (pawn.food < 30) out.push({ label: 'Голодает', delta: greedy ? -12 : -8 });
  if (pawn.rest < 25) out.push({ label: 'Усталость', delta: -6 });
  if (pawn.hp < 40) out.push({ label: 'Тяжёлая рана', delta: -15 });
  else if (pawn.hp < 70) out.push({ label: 'Ранение', delta: -10 });
  if (pawn.sickMin > 0) out.push({ label: 'Болезнь', delta: -8 });
  if (game.weather.rain) out.push({ label: 'Дождь', delta: -3 });
  if (game.weather.blizzard) out.push({ label: 'Буран', delta: -4 });
  const { beast: fear, d: fd } = nearestThreat(game, pawn);
  if (fear && fd < 7) {
    if (fear.targetPawnId === pawn.id) out.push({ label: 'Хищник охотится на меня', delta: -10 });
    else out.push({ label: 'Страх', delta: -6 });
  }
  let friend = false;
  for (const r of game.relationPairs(pawn.id)) if (r.score >= 25) friend = true;
  if (friend) out.push({ label: 'Дружба', delta: 3 });
  for (const m of pawn.mods) out.push({ label: m.label, delta: m.delta });
  return out;
}

export function moodOf(game: Game, pawn: Pawn): number {
  let m = 50;
  for (const mm of moodList(game, pawn)) m += mm.delta;
  return Math.max(0, Math.min(100, Math.round(m)));
}

function sleepRateFor(pawn: Pawn, inBed: boolean): number {
  let r = 100 / 390;
  if (inBed) r *= 1.2;
  else r *= 0.85;
  if (pawn.hasTrait('sleeper')) r *= 1.15;
  if (pawn.hasTrait('fidget')) r *= 0.9;
  return r;
}

function activityLabel(game: Game, pawn: Pawn): string {
  switch (pawn.state) {
    case 'break': {
      switch (pawn.breakKind) {
        case 'insult':
          return 'Срыв: бросается с оскорблениями';
        case 'sob':
          return 'Срыв: плачет у костра';
        default:
          return 'Срыв: бродит в оцепенении';
      }
    }
    case 'sleep':
      return pawn.job?.ground ? 'Спит на земле' : 'Спит';
    case 'eat':
      return 'Ест';
    case 'fight':
      return 'Сражается';
    case 'flee':
      return 'Убегает!';
    case 'move':
    case 'work':
    case 'idle': {
      const j = pawn.job;
      if (!j) return pawn.state === 'idle' ? 'Отдыхает' : 'Идёт';
      switch (j.kind) {
        case 'chop':
          return pawn.state === 'work' ? 'Рубит дерево' : 'Идёт к дереву';
        case 'mine':
          if (pawn.state !== 'work') return 'Идёт добывать';
          return game.world.obj[j.tile] === Obj.None && game.world.terrain[j.tile] === Terrain.Rock ? 'Вгрызается в скалу' : 'Добывает камень';
        case 'expedition':
          if (j.stage === 0) return 'Идёт к шахте';
          return j.stage === 1 ? 'В шахте: бьёт жилу' : 'Возвращается из шахты';
        case 'harvest':
        case 'crop':
          return pawn.state === 'work' ? 'Собирает урожай' : 'Идёт собирать';
        case 'till':
          return 'Копает грядку';
        case 'plant':
          return 'Сеет';
        case 'build':
          return 'Строит';
        case 'haul':
          return 'Переносит груз';
        case 'loot':
          return 'Обследует находку';
        case 'bury':
          return pawn.state === 'work' ? 'Хоронит погибшего' : 'Идёт хоронить';
        case 'cook':
          return pawn.state === 'work' ? 'Готовит похлёбку' : 'Идёт готовить';
        case 'craft': {
          const rec = RECIPES[j.recipe ?? 0];
          return pawn.state === 'work' ? `Мастерит ${rec ? rec.name.toLowerCase() : 'оружие'}` : 'Идёт к верстаку';
        }
        case 'equip':
          return 'Подбирает снаряжение';
        case 'hunt': {
          const prey = game.animals.find((an) => an.id === j.itemId);
          if (pawn.state !== 'work') return `Идёт на охоту: ${prey?.name.toLowerCase() ?? 'дичь'}`;
          return pawn.weapon === 'bow' ? `Стреляет: ${prey?.name.toLowerCase() ?? 'дичь'}` : `Добывает ${prey?.name.toLowerCase() ?? 'дичь'}`;
        }
        case 'eat':
          return 'Идёт к еде';
        case 'sleep':
          return 'Идёт спать';
        case 'doctor': {
          const patient = game.pawns.find((q) => q.id === j.itemId);
          return pawn.state === 'work' ? `Лечит ${patient?.name ?? 'больного'}` : 'Идёт лечить';
        }
        case 'warm':
          return pawn.state === 'idle' ? 'Греется у костра' : 'Идёт греться';
      }
      return 'Занят';
    }
  }
}

export function activityOf(game: Game, pawn: Pawn): string {
  const base = activityLabel(game, pawn);
  return pawn.sickMin > 0 ? `${base} · болеет` : base;
}

// ===================== Главный цикл =====================

export function updatePawn(game: Game, pawn: Pawn, dtG: number) {
  if (pawn.dead) return;
  pawn.modsNow = game.clock.totalMin;
  const inBed = pawn.state === 'sleep' && pawn.job && !pawn.job.ground;
  let sr = inBed ? sleepRateFor(pawn, true) : sleepRateFor(pawn, false);
  if (pawn.hasMod('cold')) sr *= 0.8; // мёрзнет даже во сне — отдых хуже
  pawn.decay(dtG, pawn.state === 'sleep', sr);
  if (pawn.dead) return;
  pawn.atkCd = Math.max(0, pawn.atkCd - dtG);
  pawn.talkCd = Math.max(0, pawn.talkCd - dtG);
  pawn.repathCd = Math.max(0, pawn.repathCd - dtG);

  // болезнь: во сне проходит в разы быстрее, медицина помогает
  if (pawn.sickMin > 0) {
    const rate = pawn.state === 'sleep' ? 2 : 0.35;
    const med = 1 + pawn.skillLvl('medicine') * 0.12;
    pawn.sickMin -= dtG * rate * med;
    if (pawn.sickMin <= 0) {
      pawn.sickMin = 0;
      pawn.addMod('recovered', 'Выздоровел(а)', 6, 480, game.clock.totalMin);
      pawn.addXp('medicine', 3); // уход за собой во время хвори
      game.events.log(`${pawn.name} выздоровел(а).`, 'good');
    }
  }

  // --- Мгновенная реакция на хищника: зверь рядом — решатель не ждёт своего тика ---
  // Рубящая дерево или несущая груз пешка бросает всё, как только хищник совсем близко.
  if (pawn.state === 'work' || pawn.state === 'move' || pawn.state === 'idle' || pawn.state === 'eat') {
    const near = nearestThreat(game, pawn, 3.2);
    if (near.beast && near.d < 3.2 && !isHuntingTarget(pawn, near.beast.id)) {
      const stand = pawn.weapon !== null && pawn.hp > 40 && !pawn.hasTrait('coward');
      if (stand) startFight(game, pawn, near.beast.id);
      else startFlee(game, pawn);
    }
  }
  // --- Спящий чует хищника вплотную и вскакивает (иначе его загрызут во сне) ---
  if (pawn.state === 'sleep') {
    const near = nearestThreat(game, pawn, 2.4);
    if (near.beast && near.d < 2.4) {
      pawn.state = 'idle';
      pawn.job = null;
      pawn.path = null;
    }
  }
  // --- Безоружный не гоняется за зверем: зверь отстал — снова бегство, а не самоубийство ---
  if (pawn.state === 'fight' && pawn.weapon === null) {
    const fa = game.animals.find((an) => an.id === pawn.combatTargetId && !an.dead);
    if (fa && dist(pawn.x, pawn.y, fa.x, fa.y) > 3.5) {
      pawn.combatTargetId = null;
      startFlee(game, pawn);
    }
  }

  switch (pawn.state) {
    case 'move':
      moveUpdate(game, pawn, dtG);
      break;
    case 'work':
      workUpdate(game, pawn, dtG);
      break;
    case 'eat':
      eatUpdate(game, pawn, dtG);
      break;
    case 'sleep':
      sleepUpdate(game, pawn);
      break;
    case 'fight':
      fightUpdate(game, pawn, dtG);
      break;
    case 'flee':
      fleeUpdate(game, pawn, dtG);
      break;
    case 'break':
      breakUpdate(game, pawn, dtG);
      break;
    case 'idle':
      idleUpdate(game, pawn, dtG);
      break;
  }
}

// ---- Движение по пути ----
function moveUpdate(game: Game, pawn: Pawn, dtG: number) {
  const path = pawn.path;
  if (!path || pawn.pathI >= path.length) {
    arrive(game, pawn);
    return;
  }
  let budget = WALK * pawn.walkMult() * game.walkPenalty() * dtG;
  while (budget > 0) {
    const node = path[pawn.pathI];
    if (!node) break;
    // внезапная блокировка пути
    if (!game.world.passPawn(node.x, node.y)) {
      if (pawn.repathCd <= 0) {
        pawn.repathCd = 0.6;
        repathPawn(game, pawn);
      }
      return;
    }
    const tx = node.x + 0.5;
    const ty = node.y + 0.5;
    const dx = tx - pawn.x;
    const dy = ty - pawn.y;
    const d = Math.hypot(dx, dy);
    if (d <= budget) {
      pawn.x = tx;
      pawn.y = ty;
      budget -= d;
      pawn.pathI++;
      if (pawn.pathI >= pawn.path.length) {
        arrive(game, pawn);
        return;
      }
    } else {
      pawn.x += (dx / d) * budget;
      pawn.y += (dy / d) * budget;
      budget = 0;
    }
  }
}

function repathPawn(game: Game, pawn: Pawn) {
  const j = pawn.job;
  if (!j) {
    pawn.path = null;
    pawn.state = 'idle';
    return;
  }
  startJobMove(game, pawn, j);
}

// Приход в конец пути
function arrive(game: Game, pawn: Pawn) {
  pawn.path = null;
  const j = pawn.job;
  if (!j) {
    pawn.state = 'idle';
    return;
  }
  switch (j.kind) {
    case 'eat': {
      // этап 0: приходим к еде. Если планируем есть за столом — берём с собой и идём к стулу (этап 1)
      let food = game.world.items.find((it) => it.id === j.itemId && (it.type === Res.Food || it.type === Res.Meal));
      if (j.stage === 0) {
        if (!food) {
          // еду унесла переноска — ищем замену рядом (в радиусе 6 клеток)
          let bd = 6;
          for (const it of game.world.items) {
            if (it.type !== Res.Food && it.type !== Res.Meal) continue;
            const d = dist(pawn.x, pawn.y, it.x + 0.5, it.y + 0.5);
            if (d < bd) {
              bd = d;
              food = it;
            }
          }
          if (food) {
            j.itemId = food.id;
            j.tile = game.world.idx(food.x, food.y);
            const p = pathToTile(game.world, Math.floor(pawn.x), Math.floor(pawn.y), food.x, food.y, false);
            if (setPath(game, pawn, p)) return;
            food = undefined;
          }
        }
        if (!food) {
          releaseBoardJob(game, pawn);
          pawn.state = 'idle';
          return;
        }
        if (j.buildingId !== undefined && !pawn.inv) {
          // трапеза за столом: берём порцию с собой и идём к стулу
          const take = Math.min(food.type === Res.Meal ? MEAL_EAT_QTY : EAT_QTY, food.qty);
          food.qty -= take;
          if (food.qty <= 0) game.world.removeItem(food);
          pawn.inv = { type: food.type, qty: take };
          const chair = game.world.buildings.find((bb) => bb.id === j.buildingId);
          if (!chair) {
            // стула больше нет — едим здесь
            j.buildingId = undefined;
            pawn.state = 'eat';
            pawn.eatT = 10;
            return;
          }
          j.stage = 1;
          j.tile = game.world.idx(chair.x, chair.y);
          startJobMove(game, pawn, j);
          return;
        }
        // обычная трапеза на месте
        pawn.state = 'eat';
        pawn.eatT = 10;
        return;
      }
      // этап 1: дошли до стула — едим
      pawn.state = 'eat';
      pawn.eatT = 10;
      return;
    }
    case 'sleep':
      pawn.state = 'sleep';
      return;
    case 'warm':
      // дошли до костра — стоим и греемся, job оставляем (решатель держит у огня)
      pawn.state = 'idle';
      return;
    case 'expedition': {
      const mine = game.world.buildings.find((bb) => bb.id === j.buildingId);
      if (!mine || mine.blueprint || mine.type !== BType.Mine) {
        pawn.state = 'idle';
        pawn.job = null;
        return;
      }
      if (j.stage === 0) {
        // пришли к шахте — спускаемся в глубины (дальше управляёт Game.updateExpeditions)
        pawn.underground = true;
        pawn.x = mine.x + 0.5;
        pawn.y = mine.y + 0.5;
        pawn.path = null;
        j.stage = 1;
        pawn.state = 'work';
        return;
      }
      // stage 1/2: стоим в выработке — таймер идёт в игре
      pawn.state = 'work';
      return;
    }
    case 'cook': {
      if (j.stage === 0) {
        // взять сырую еду (та ещё на месте?)
        const item = game.world.items.find((it) => it.id === j.itemId && it.type === Res.Food);
        if (!item) {
          releaseBoardJob(game, pawn);
          pawn.state = 'idle';
          return;
        }
        const take = Math.min(MEAL_RAW, item.qty);
        if (pawn.inv) {
          // несли что-то другое — сдать нельзя, просто меняем груз (еды ≤ 4, потери не будет: бросим на месте)
          game.world.addItem(pawn.inv.type as Res, pawn.inv.qty, Math.floor(pawn.x), Math.floor(pawn.y));
        }
        pawn.inv = { type: Res.Food, qty: take };
        item.qty -= take;
        if (item.qty <= 0) game.world.removeItem(item);
        const fire = game.world.buildings.find((bb) => bb.id === j.buildingId);
        if (!fire) {
          releaseBoardJob(game, pawn);
          pawn.state = 'idle';
          return;
        }
        j.stage = 1;
        j.tile = game.world.idx(fire.x, fire.y);
        startJobMove(game, pawn, j);
        return;
      }
      pawn.state = 'work';
      return;
    }
    case 'craft': {
      const wb = game.world.buildings.find((bb) => bb.id === j.buildingId);
      if (!wb || wb.blueprint) {
        pawn.state = 'idle';
        pawn.job = null;
        return;
      }
      if (j.stage === 0) {
        // взять материал со клетки (меч и железная броня — железо, одежда — шкуры, остальное — дерево)
        const rec = RECIPES[j.recipe ?? 0];
        const matRes = rec ? craftMat(rec) : Res.Wood;
        const item = game.world.items.find((it) => it.id === j.itemId && it.type === matRes);
        if (!item) {
          releaseBoardJob(game, pawn);
          pawn.state = 'idle';
          return;
        }
        const need = rec ? craftNeed(rec) : 0;
        if (pawn.inv && pawn.inv.type !== matRes) {
          // несли другое — бросаем на месте, снаряжение важнее
          game.world.addItem(pawn.inv.type as Res, pawn.inv.qty, Math.floor(pawn.x), Math.floor(pawn.y));
          pawn.inv = null;
        }
        const take = Math.min(need, item.qty, CARRY_CAP - (pawn.inv ? pawn.inv.qty : 0));
        if (take <= 0 || need <= 0) {
          releaseBoardJob(game, pawn);
          pawn.state = 'idle';
          return;
        }
        pawn.inv = { type: matRes, qty: take };
        item.qty -= take;
        if (item.qty <= 0) game.world.removeItem(item);
        j.stage = 1;
        j.tile = game.world.idx(wb.x, wb.y);
        startJobMove(game, pawn, j);
        return;
      }
      pawn.state = 'work';
      return;
    }
    case 'equip': {
      const item = game.world.items.find((it) => it.id === j.itemId && (it.type === Res.Spear || it.type === Res.Bow || it.type === Res.Sword || it.type === Res.Coat || it.type === Res.LeatherArmor || it.type === Res.IronArmor));
      if (!item) {
        pawn.state = 'idle';
        pawn.job = null;
        return;
      }
      game.world.removeItem(item);
      game.renderDirtyTile(item.x, item.y);
      const px = Math.floor(pawn.x);
      const py = Math.floor(pawn.y);
      if (item.type === Res.Spear || item.type === Res.Bow || item.type === Res.Sword) {
        const kind = item.type === Res.Spear ? 'spear' : item.type === Res.Bow ? 'bow' : 'sword';
        if (pawn.weapon && pawn.weapon !== kind) {
          // апгрейд: старое оружие падает на землю — пригодится следующему колонисту
          game.world.addItem(WEAPON_RES[pawn.weapon], 1, px, py);
          game.events.log(`${pawn.name} меняет ${WEAPON_NAMES[pawn.weapon].toLowerCase()} на ${WEAPON_NAMES[kind].toLowerCase()}.`, 'info');
          game.renderDirtyTile(px, py);
        } else if (!pawn.weapon) {
          game.events.log(`${pawn.name} вооружается: ${WEAPON_NAMES[kind].toLowerCase()} теперь в надёжных руках.`, 'info');
        }
        pawn.weapon = kind;
      } else if (item.type === Res.Coat) {
        pawn.cloth = 'coat';
        game.events.log(`${pawn.name} надевает тёплую куртку. Зима не страшна.`, 'good');
      } else {
        const ak = item.type === Res.IronArmor ? 'iron' : 'leather';
        if (pawn.armor === 'leather' && ak === 'iron') {
          game.world.addItem(Res.LeatherArmor, 1, px, py);
          game.events.log(`${pawn.name} меняет кожаную броню на железную.`, 'good');
          game.renderDirtyTile(px, py);
        } else if (!pawn.armor) {
          game.events.log(`${pawn.name} надевает ${ak === 'iron' ? 'железную' : 'кожаную'} броню. Звериный клык теперь не так страшен.`, 'good');
        }
        pawn.armor = ak;
      }
      pawn.state = 'idle';
      pawn.job = null;
      return;
    }
    case 'haul': {
      if (j.stage === 0) {
        // взять предмет
        const item = game.world.items.find((it) => it.id === j.itemId);
        if (!item) {
          releaseBoardJob(game, pawn);
          pawn.state = 'idle';
          return;
        }
        const take = Math.min(CARRY_CAP - (pawn.inv ? pawn.inv.qty : 0), item.qty);
        if (take <= 0) {
          releaseBoardJob(game, pawn);
          pawn.state = 'idle';
          return;
        }
        pawn.inv = { type: item.type, qty: take };
        item.qty -= take;
        if (item.qty <= 0) game.world.removeItem(item);
        // цель: склад или чертёж
        j.stage = 1;
        startJobMove(game, pawn, j);
        return;
      }
      // stage 1: выгрузить
      dropCarried(game, pawn, j.tile);
      pawn.state = 'idle';
      pawn.job = null;
      finishBoardJob(game, pawn, j);
      return;
    }
    case 'build': {
      const b = game.world.buildings.find((bb) => bb.id === j.buildingId);
      if (!b || !b.blueprint) {
        // чертёж исчез: материалы сдать на склад
        if (pawn.inv) {
          const tile = game.world.findStockpileTile(pawn.inv.type as Res, Math.floor(pawn.x), Math.floor(pawn.y));
          if (tile) game.world.addItem(pawn.inv.type as Res, pawn.inv.qty, tile.x, tile.y);
          else game.world.addItem(pawn.inv.type as Res, pawn.inv.qty, Math.floor(pawn.x), Math.floor(pawn.y));
          pawn.inv = null;
        }
        pawn.state = 'idle';
        pawn.job = null;
        finishBoardJob(game, pawn, j);
        return;
      }
      if (j.stage === 0) {
        // взять материал со клетки
        const item = game.world.items.find((it) => it.id === j.itemId);
        if (!item) {
          // материала нет на карте: сдать то, что несёт, и отпустить задачу
          if (pawn.inv) {
            const tile = game.world.findStockpileTile(pawn.inv.type as Res, Math.floor(pawn.x), Math.floor(pawn.y));
            if (tile) game.world.addItem(pawn.inv.type as Res, pawn.inv.qty, tile.x, tile.y);
            else game.world.addItem(pawn.inv.type as Res, pawn.inv.qty, Math.floor(pawn.x), Math.floor(pawn.y));
            pawn.inv = null;
          }
          releaseBoardJob(game, pawn);
          pawn.state = 'idle';
          return;
        }
        const b2 = game.world.buildings.find((bb) => bb.id === j.buildingId);
        const need = b2 ? b2.matNeed - b2.matHave : 0;
        const take = Math.min(item.qty, need, CARRY_CAP - (pawn.inv ? pawn.inv.qty : 0));
        if (take <= 0 || !b2) {
          releaseBoardJob(game, pawn);
          pawn.state = 'idle';
          return;
        }
        pawn.inv = { type: item.type, qty: take };
        item.qty -= take;
        if (item.qty <= 0) game.world.removeItem(item);
        j.stage = 1;
        j.tile = game.world.idx(b2.x, b2.y);
        startJobMove(game, pawn, j);
        return;
      }
      // stage 1: выгрузить материалы в чертёж
      if (pawn.inv && pawn.inv.type === b.matType) {
        const take = Math.min(pawn.inv.qty, b.matNeed - b.matHave);
        if (take > 0) {
          b.matHave += take;
          pawn.inv.qty -= take;
          game.renderDirtyTile(b.x, b.y);
        }
        if (pawn.inv.qty <= 0) pawn.inv = null;
      }
      if (b.matHave >= b.matNeed) {
        pawn.state = 'work';
      } else {
        // не хватает — остальное несёт другой или сходим ещё раз
        j.stage = 0;
        startJobMove(game, pawn, j);
      }
      return;
    }
    default:
      pawn.state = 'work';
      return;
  }
}

function findMatFor(game: Game, pawn: Pawn, type: Res): { id: number; x: number; y: number } | null {
  let best: { id: number; x: number; y: number } | null = null;
  let bestD = Infinity;
  for (const it of game.world.items) {
    if (it.type !== type) continue;
    const d = dist(pawn.x, pawn.y, it.x + 0.5, it.y + 0.5);
    if (d < bestD) {
      bestD = d;
      best = it;
    }
  }
  return best;
}

function dropCarried(game: Game, pawn: Pawn, preferTile: number) {
  if (!pawn.inv) return;
  const b = pawn.inv.type !== undefined ? game.world.buildings.find((bb) => bb.id === buildingAtTile(game, preferTile)) : undefined;
  if (b && b.blueprint && b.matType === pawn.inv.type) {
    const take = Math.min(pawn.inv.qty, b.matNeed - b.matHave);
    b.matHave += take;
    pawn.inv.qty -= take;
    if (pawn.inv.qty <= 0) {
      pawn.inv = null;
      return;
    }
  }
  const tile = game.world.findStockpileTile(pawn.inv.type as Res, Math.floor(pawn.x), Math.floor(pawn.y));
  if (tile) {
    game.world.addItem(pawn.inv.type as Res, pawn.inv.qty, tile.x, tile.y);
    game.renderDirtyTile(tile.x, tile.y);
    pawn.inv = null;
  } else {
    // бросить на месте
    game.world.addItem(pawn.inv.type as Res, pawn.inv.qty, Math.floor(pawn.x), Math.floor(pawn.y));
    pawn.inv = null;
  }
}

function buildingAtTile(game: Game, tile: number): number | null {
  const b = game.world.buildingMap.get(tile);
  return b ? b.id : null;
}

function finishBoardJob(game: Game, pawn: Pawn, j: ActiveJob) {
  if (j.jobRef !== undefined) {
    const job = game.jobs.jobs.get(j.jobRef);
    if (job) game.jobs.remove(job);
  }
  void pawn;
}

// ---- Работа ----
function workUpdate(game: Game, pawn: Pawn, dtG: number) {
  const j = pawn.job;
  if (!j) {
    pawn.state = 'idle';
    return;
  }
  if (j.kind === 'hunt') return huntUpdate(game, pawn, dtG); // дичь двигается — всё делает huntUpdate
  const tx = j.tile % 64;
  const ty = (j.tile / 64) | 0;
  const c = cheb(Math.floor(pawn.x), Math.floor(pawn.y), tx, ty);
  if (c > 1) {
    startJobMove(game, pawn, j);
    return;
  }
  const mood = moodOf(game, pawn);
  let need = 0;
  let skill: 'lumber' | 'mine' | 'farm' | 'build' | 'medicine' | 'cook' = 'farm';

  switch (j.kind) {
    case 'chop':
      if (game.world.obj[j.tile] !== Obj.Tree && game.world.obj[j.tile] !== Obj.BerryBush) return jobDone(game, pawn);
      need = game.world.obj[j.tile] === Obj.BerryBush ? WORK_TIME.clear : WORK_TIME.chop;
      skill = 'lumber';
      break;
    case 'mine': {
      const o = game.world.obj[j.tile];
      if (o !== Obj.Rock && o !== Obj.Ore && o !== Obj.SilverOre && game.world.terrain[j.tile] !== Terrain.Rock) return jobDone(game, pawn);
      need = o === Obj.None ? WORK_TIME.dig : WORK_TIME.mine; // сплошная скала поддаётся медленнее
      skill = 'mine';
      break;
    }
    case 'harvest':
      if (!((game.world.obj[j.tile] === Obj.BerryBush && game.world.berryRegrow[j.tile] <= 0) ||
            (game.world.zone[j.tile] === Zone.Farm && game.world.farmStage[j.tile] === FarmStage.Ready)))
        return jobDone(game, pawn);
      need = WORK_TIME.harvest;
      skill = 'farm';
      break;
    case 'till':
      if (game.world.farmStage[j.tile] !== FarmStage.None) return jobDone(game, pawn);
      need = WORK_TIME.till;
      skill = 'farm';
      break;
    case 'plant':
      if (game.world.farmStage[j.tile] !== FarmStage.Tilled) return jobDone(game, pawn);
      need = WORK_TIME.plant;
      skill = 'farm';
      break;
    case 'crop':
      if (game.world.farmStage[j.tile] !== FarmStage.Ready) return jobDone(game, pawn);
      need = WORK_TIME.crop;
      skill = 'farm';
      break;
    case 'loot': {
      const item = game.world.items.find((it) => it.id === j.itemId);
      if (!item) return jobDone(game, pawn);
      need = WORK_TIME.loot;
      skill = 'farm';
      break;
    }
    case 'bury': {
      const corpse = game.world.items.find((it) => it.id === j.itemId && it.type === Res.Corpse);
      if (!corpse) return jobDone(game, pawn);
      need = WORK_TIME.bury;
      skill = 'farm';
      break;
    }
    case 'doctor': {
      const patient = game.pawns.find((q) => q.id === j.itemId && !q.dead);
      if (!patient || patient.sickMin <= 0) return jobDone(game, pawn);
      need = WORK_TIME.doctor;
      skill = 'medicine';
      break;
    }
    case 'cook': {
      const fire = game.world.buildings.find((bb) => bb.id === j.buildingId);
      if (!fire || fire.blueprint || fire.type !== BType.Campfire) return jobDone(game, pawn);
      if (!pawn.inv || pawn.inv.type !== Res.Food || pawn.inv.qty <= 0) return jobDone(game, pawn);
      need = WORK_TIME.cook;
      skill = 'cook';
      break;
    }
    case 'expedition':
      // экспедицией управляет Game.updateExpeditions (таймер и сюрпризы под землёй)
      return;
    case 'craft': {
      const wb = game.world.buildings.find((bb) => bb.id === j.buildingId);
      const rec = RECIPES[j.recipe ?? 0];
      if (!wb || wb.blueprint || wb.type !== BType.Workbench || !rec) return jobDone(game, pawn);
      // заказ ещё жив?
      const bill = wb.bills?.find((bl) => bl.recipe === (j.recipe ?? -1) && bl.done < bl.count);
      if (!bill) return jobDone(game, pawn);
      const matRes = craftMat(rec);
      const matNeed = craftNeed(rec);
      if (!pawn.inv || pawn.inv.type !== matRes || pawn.inv.qty < matNeed) return jobDone(game, pawn);
      need = rec.work;
      skill = 'build';
      break;
    }
    case 'build': {
      const b = game.world.buildings.find((bb) => bb.id === j.buildingId);
      if (!b) return jobDone(game, pawn);
      if (!b.blueprint) return jobDone(game, pawn);
      if (b.matHave < b.matNeed) {
        j.stage = 0;
        startJobMove(game, pawn, j);
        return;
      }
      need = b.workNeed;
      skill = 'build';
      break;
    }
    default:
      pawn.state = 'idle';
      return;
  }

  j.progress += dtG * pawn.workMult(skill, mood);
  if (j.progress >= need) {
    completeWork(game, pawn, j);
  }
}

function completeWork(game: Game, pawn: Pawn, j: ActiveJob) {
  const w = game.world;
  switch (j.kind) {
    case 'chop': {
      const wasBush = w.obj[j.tile] === Obj.BerryBush;
      w.obj[j.tile] = Obj.None;
      w.berryRegrow[j.tile] = 0;
      game.desigClear('chop', j.tile);
      const x = j.tile % 64;
      const y = (j.tile / 64) | 0;
      w.addItem(Res.Wood, wasBush ? YIELDS.bush : YIELDS.tree, x, y);
      game.renderDirtyTile(x, y);
      pawn.addXp('lumber', XP_PER_ACTION);
      if (wasBush) {
        game.events.log(`${pawn.name} выкорчевал(а) куст ягод.`, 'info');
      } else {
        game.stats.treesChopped++;
        if (game.stats.treesChopped === 1) game.events.log(`${pawn.name} срубил(а) первое дерево.`, 'story');
      }
      break;
    }
    case 'mine': {
      const x = j.tile % 64;
      const y = (j.tile / 64) | 0;
      const o = w.obj[j.tile];
      const t = w.terrain[j.tile];
      if (o === Obj.Ore) {
        w.obj[j.tile] = Obj.None;
        if (t === Terrain.Rock) w.terrain[j.tile] = Terrain.Dirt; // вскрыли толщу — появился проход
        w.addItem(Res.Iron, YIELDS.ore, x, y);
        if (!game.stats.firstIron) {
          game.stats.firstIron = true;
          game.events.log(`${pawn.name} добыл(а) первое железо. Теперь можно ковать настоящие мечи.`, 'story');
        }
      } else if (o === Obj.SilverOre) {
        w.obj[j.tile] = Obj.None;
        if (t === Terrain.Rock) w.terrain[j.tile] = Terrain.Dirt;
        w.addItem(Res.Silver, YIELDS.silver, x, y);
        if (!game.stats.firstSilver) {
          game.stats.firstSilver = true;
          game.events.log(`${pawn.name} нашёл(ла) серебро! Блестящий металл ценят караванные торговцы.`, 'story');
        }
      } else if (o === Obj.Rock) {
        w.obj[j.tile] = Obj.None;
        w.addItem(Res.Stone, YIELDS.rock, x, y);
        game.stats.rocksMined++;
      } else if (t === Terrain.Rock) {
        // вгрызлись в сплошную скалу: туннель + камень, иногда попутное железо
        w.terrain[j.tile] = Terrain.Dirt;
        w.addItem(Res.Stone, YIELDS.dig, x, y);
        if (game.rng.chance(0.3)) w.addItem(Res.Iron, 1 + game.rng.int(0, 2), x, y);
        game.stats.rocksMined++;
      } else {
        break;
      }
      game.desigClear('mine', j.tile);
      game.renderDirtyTile(x, y);
      pawn.addXp('mine', XP_PER_ACTION);
      break;
    }
    case 'harvest': {
      const x = j.tile % 64;
      const y = (j.tile / 64) | 0;
      if (w.obj[j.tile] === Obj.BerryBush) {
        w.berryRegrow[j.tile] = 1440;
        w.addItem(Res.Food, YIELDS.berry, x, y);
      } else {
        w.farmStage[j.tile] = FarmStage.Tilled;
        w.addItem(Res.Food, YIELDS.crop, x, y);
      }
      game.renderDirtyTile(x, y);
      pawn.addXp('farm', XP_PER_ACTION);
      game.stats.harvests++;
      if (game.stats.harvests === 1) game.events.log(`Первый урожай собран: ${pawn.name} радуется.`, 'good');
      break;
    }
    case 'till':
      w.farmStage[j.tile] = FarmStage.Tilled;
      pawn.addXp('farm');
      break;
    case 'plant':
      w.farmStage[j.tile] = FarmStage.Planted;
      w.farmGrowth[j.tile] = 0;
      pawn.addXp('farm');
      break;
    case 'crop':
      w.farmStage[j.tile] = FarmStage.Tilled;
      {
        const x = j.tile % 64;
        const y = (j.tile / 64) | 0;
        w.addItem(Res.Food, YIELDS.crop, x, y);
        game.renderDirtyTile(x, y);
      }
      pawn.addXp('farm', XP_PER_ACTION);
      game.stats.harvests++;
      if (game.stats.harvests === 1) game.events.log(`Первый урожай собран: ${pawn.name} радуется.`, 'good');
      break;
    case 'loot': {
      const item = w.items.find((it) => it.id === j.itemId);
      if (item) {
        w.removeItem(item);
        const x = Math.floor(pawn.x);
        const y = Math.floor(pawn.y);
        w.addItem(Res.Food, 12, x, y);
        w.addItem(Res.Wood, 8, x, y);
        game.events.log(`${pawn.name} нашёл(ла) старый рюкзак: еда и припасы!`, 'good');
        game.renderDirtyTile(x, y);
      }
      break;
    }
    case 'bury': {
      const corpse = w.items.find((it) => it.id === j.itemId && it.type === Res.Corpse);
      if (corpse) {
        const name = corpse.name ?? 'погибшего';
        w.removeItem(corpse);
        game.renderDirtyTile(corpse.x, corpse.y);
        pawn.addMod('burial', 'Похоронил(а) товарища', 5, 2880, game.clock.totalMin);
        // ближайшая свободная могила: тело обретает надгробие с именем
        let grave: Building | null = null;
        let gd = Infinity;
        for (const b of w.buildings) {
          if (b.blueprint || b.type !== BType.Grave || b.graveName) continue;
          const d = dist(corpse.x, corpse.y, b.x, b.y);
          if (d < gd) {
            gd = d;
            grave = b;
          }
        }
        if (grave) {
          grave.graveName = name;
          game.renderDirtyTile(grave.x, grave.y);
          game.events.log(`${pawn.name} похоронил(а) ${name} в могиле. Надгробие поставлено — память живёт.`, 'story');
        } else {
          game.events.log(`${pawn.name} похоронил(а) ${name}. Можно прощаться и помнить.`, 'story');
        }
      }
      break;
    }
    case 'doctor': {
      const patient = game.pawns.find((q) => q.id === j.itemId && !q.dead);
      if (patient && patient.sickMin > 0) {
        patient.sickMin = Math.max(0, patient.sickMin * 0.55);
        patient.addMod('treated', 'Медпомощь', 6, 720, game.clock.totalMin);
        pawn.addXp('medicine', 5);
        game.events.log(`${pawn.name} выходил(а) ${patient.name}: лекарство из трав и уход.`, 'good');
      }
      break;
    }
    case 'build': {
      const b = w.buildings.find((bb) => bb.id === j.buildingId);
      if (b && b.blueprint) {
        game.completeBuilding(b, pawn);
      }
      break;
    }
    case 'cook': {
      const qty = pawn.inv ? pawn.inv.qty : 0;
      pawn.inv = null;
      if (qty > 0) {
        const x = Math.floor(pawn.x);
        const y = Math.floor(pawn.y);
        w.addItem(Res.Meal, qty, x, y);
        game.renderDirtyTile(x, y);
        pawn.addXp('cook', 3);
        if (!game.stats.firstMeal) {
          game.stats.firstMeal = true;
          game.events.log(`${pawn.name} сварил(а) первую похлёбку. Горячая еда — маленькое счастье осколка.`, 'story');
        } else {
          game.events.log(`${pawn.name} сварил(а) похлёбку на ${qty} порций.`, 'info');
        }
      }
      break;
    }
    case 'craft': {
      const rec = RECIPES[j.recipe ?? 0];
      const matRes = rec ? craftMat(rec) : Res.Wood;
      const matNeed = rec ? craftNeed(rec) : 0;
      if (rec && pawn.inv && pawn.inv.type === matRes && pawn.inv.qty >= matNeed) {
        pawn.inv.qty -= matNeed;
        if (pawn.inv.qty <= 0) pawn.inv = null;
        const x = Math.floor(pawn.x);
        const y = Math.floor(pawn.y);
        w.addItem(rec.res, 1, x, y);
        game.renderDirtyTile(x, y);
        pawn.addXp('build', 3);
        // заказ выполнен — закрываем один пункт bill на верстаке
        const wb = w.buildings.find((bb) => bb.id === j.buildingId);
        const bill = wb?.bills?.find((bl) => bl.recipe === (j.recipe ?? -1) && bl.done < bl.count);
        if (bill) bill.done++;
        if (rec.res === Res.Sword) {
          if (!game.stats.firstSword) {
            game.stats.firstSword = true;
            game.events.log(`${pawn.name} выковал(а) первый меч. Лес замолкает при виде такой стали.`, 'story');
          } else {
            game.events.log(`${pawn.name} выковал(а) меч — теперь волкам не поздоровится.`, 'good');
          }
        } else if (rec.res === Res.Coat) {
          game.events.log(`${pawn.name} сшил(а) тёплую куртку из шкур. Кто-то из колонистов её сразу наденет.`, 'good');
        } else if (rec.res === Res.LeatherArmor || rec.res === Res.IronArmor) {
          game.events.log(`${pawn.name} сделал(а) ${rec.name.toLowerCase()} — колонист в ней выживет там, где без неё погиб бы.`, 'good');
        } else {
          game.events.log(`${pawn.name} смастерил(а) ${rec.name.toLowerCase()}. Безоружный колонист сам возьмёт оружие.`, 'good');
        }
      }
      break;
    }
    default:
      break;
  }
  jobDone(game, pawn);
}

function jobDone(game: Game, pawn: Pawn) {
  const j = pawn.job!;
  const selfHarvest = j.kind === 'harvest' && j.jobRef === undefined;
  finishBoardJob(game, pawn, j);
  pawn.job = null;
  pawn.state = 'idle';
  if (selfHarvest) afterSelfHarvest(game, pawn, j.tile);
}

// Замерзающая пешка сама идёт к ближайшему костру греться (зимний ИИ).
// Возвращает false, если костров нет или до них не дойти — тогда пешка живёт как раньше.
export function startWarm(game: Game, pawn: Pawn): boolean {
  rememberBoardJob(pawn);
  const fires = game.campfires();
  if (fires.length === 0) return false;
  let best: { x: number; y: number } | null = null;
  let bestD = Infinity;
  for (const f of fires) {
    const d = dist(pawn.x, pawn.y, f.x + 0.5, f.y + 0.5);
    if (d < bestD) {
      bestD = d;
      best = f;
    }
  }
  if (!best) return false;
  // уже в тепле — мод вот-вот снимет updateCold, достаточно стоять
  if (bestD <= FIRE_WARM_R + 0.2) {
    releaseBoardJob(game, pawn);
    pawn.job = { kind: 'warm', tile: game.world.idx(best.x, best.y), stage: 0, progress: 0 };
    pawn.state = 'idle';
    pawn.path = null;
    return true;
  }
  const p = pathToTile(game.world, Math.floor(pawn.x), Math.floor(pawn.y), best.x, best.y, true);
  if (!p || p.length === 0) return false;
  releaseBoardJob(game, pawn);
  pawn.job = { kind: 'warm', tile: game.world.idx(best.x, best.y), stage: 0, progress: 0 };
  if (!setPath(game, pawn, p)) return false;
  return true;
}

// ---- Еда ----
export function startEat(game: Game, pawn: Pawn): boolean {
  rememberBoardJob(pawn);
  // Уже держим еду в руках (например, взяли раньше и сбились) — сесть за стол или есть здесь
  if (pawn.inv && (pawn.inv.type === Res.Meal || pawn.inv.type === Res.Food) && pawn.inv.qty > 0) {
    releaseBoardJob(game, pawn);
    const chair = findDiningChair(game, pawn);
    if (chair) {
      pawn.job = { kind: 'eat', tile: game.world.idx(chair.x, chair.y), stage: 1, progress: 0, buildingId: chair.id };
      const pc = pathToTile(game.world, Math.floor(pawn.x), Math.floor(pawn.y), chair.x, chair.y, false);
      if (setPath(game, pawn, pc)) return true;
      // до стола не дойти — едим где стоим
    }
    pawn.job = { kind: 'eat', tile: game.world.idx(Math.floor(pawn.x), Math.floor(pawn.y)), stage: 1, progress: 0 };
    pawn.state = 'eat';
    pawn.eatT = 10;
    return true;
  }
  // сперва ищем похлёбку (горячая еда сытнее), потом сырую еду
  let best: { id: number; x: number; y: number } | null = null;
  let bestD = Infinity;
  let bestMeal: { id: number; x: number; y: number } | null = null;
  let bestMealD = Infinity;
  for (const it of game.world.items) {
    if (it.type === Res.Meal) {
      const d = dist(pawn.x, pawn.y, it.x + 0.5, it.y + 0.5);
      if (d < bestMealD) {
        bestMealD = d;
        bestMeal = it;
      }
    } else if (it.type === Res.Food) {
      const d = dist(pawn.x, pawn.y, it.x + 0.5, it.y + 0.5);
      if (d < bestD) {
        bestD = d;
        best = it;
      }
    }
  }
  if (bestMeal) best = bestMeal;
  if (best) {
    releaseBoardJob(game, pawn);
    // RimWorld-стиль: если недалеко от пешки есть стул у стола — несём еду туда
    // (этап 0: взять еду, этап 1: дойти до стула и поесть). Руки заняты — едим на месте.
    const chair = !pawn.inv ? findDiningChair(game, pawn) : null;
    pawn.job = {
      kind: 'eat',
      tile: game.world.idx(best.x, best.y),
      itemId: best.id,
      stage: 0,
      progress: 0,
      ...(chair ? { buildingId: chair.id } : {}),
    };
    const p = pathToTile(game.world, Math.floor(pawn.x), Math.floor(pawn.y), best.x, best.y, false);
    if (!setPath(game, pawn, p)) {
      // еда недостижима
      pawn.job = null;
      pawn.state = 'idle';
      return false;
    }
    return true;
  }
  // ягоды на кустах
  let bush = -1;
  let bd = Infinity;
  for (let i = 0; i < game.world.obj.length; i++) {
    if (game.world.obj[i] !== Obj.BerryBush || game.world.berryRegrow[i] > 0) continue;
    const x = i % 64;
    const y = (i / 64) | 0;
    const d = dist(pawn.x, pawn.y, x + 0.5, y + 0.5);
    if (d < bd) {
      bd = d;
      bush = i;
    }
  }
  if (bush >= 0) {
    releaseBoardJob(game, pawn);
    pawn.job = { kind: 'harvest', tile: bush, stage: 0, progress: 0, ground: false };
    const p = pathToAdjacent(game.world, Math.floor(pawn.x), Math.floor(pawn.y), bush, false);
    if (!setPath(game, pawn, p)) {
      pawn.job = null;
      pawn.state = 'idle';
      return false;
    }
    pawn.state = 'move';
    // после сбора сам придёт есть (см. jobDone -> jobRef undefined, остаётся job.harvest)
    (pawn.job as ActiveJob).jobRef = undefined;
    return true;
  }
  if (!game.warnedNoFood) {
    game.events.log('Еды не осталось! Колонисты в панике ищут ягоды.', 'bad');
    game.warnedNoFood = true;
  }
  game.eatFailCd = 8;
  return false;
}

function eatUpdate(game: Game, pawn: Pawn, dtG: number) {
  pawn.eatT -= dtG;
  if (pawn.eatT > 0) return;
  // трапеза, принесённая с собой (за столом)
  if (pawn.inv && (pawn.inv.type === Res.Meal || pawn.inv.type === Res.Food)) {
    const isMeal = pawn.inv.type === Res.Meal;
    pawn.inv = null;
    pawn.food = Math.min(100, pawn.food + (isMeal ? MEAL_SATIETY : EAT_SATIETY));
    if (isMeal) pawn.addMod('hotmeal', 'Горячая еда', 6, 360, game.clock.totalMin);
    else pawn.addMod('ate', 'Поел', 4, 180, game.clock.totalMin);
    ateTogether(game, pawn);
    eatAtTable(game, pawn);
    pawn.job = null;
    pawn.state = 'idle';
    return;
  }
  const j = pawn.job;
  const item = j && j.itemId !== undefined ? game.world.items.find((it) => it.id === j.itemId) : undefined;
  if (item && item.type === Res.Meal) {
    // похлёбка: меньше расход, больше сытости и настроение
    item.qty -= MEAL_EAT_QTY;
    if (item.qty <= 0) game.world.removeItem(item);
    pawn.food = Math.min(100, pawn.food + MEAL_SATIETY);
    pawn.addMod('hotmeal', 'Горячая еда', 6, 360, game.clock.totalMin);
    ateTogether(game, pawn);
  } else if (item && item.type === Res.Food) {
    item.qty -= EAT_QTY;
    if (item.qty <= 0) game.world.removeItem(item);
    pawn.food = Math.min(100, pawn.food + EAT_SATIETY);
    pawn.addMod('ate', 'Поел', 4, 180, game.clock.totalMin);
    ateTogether(game, pawn);
  }
  eatAtTable(game, pawn);
  pawn.job = null;
  pawn.state = 'idle';
}

// Совместная трапеза: кто рядом тоже ест — отношения растут
function ateTogether(game: Game, pawn: Pawn) {
  for (const other of game.pawns) {
    if (other === pawn || other.dead) continue;
    if (other.state === 'eat' && dist(pawn.x, pawn.y, other.x, other.y) < 4) {
      game.addRelation(pawn.id, other.id, 3);
    }
  }
}

// Ел ли пешка за столом (рядом стоит стол) — мод «Поел за столом»
function eatAtTable(game: Game, pawn: Pawn) {
  const px = Math.floor(pawn.x);
  const py = Math.floor(pawn.y);
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      const b = game.world.buildingMap.get(game.world.idx(px + dx, py + dy));
      if (b && !b.blueprint && b.type === BType.Table) {
        pawn.addMod('dined', 'Поел за столом', DINED_MOOD, DINED_MIN, game.clock.totalMin);
        return;
      }
    }
  }
}

// Найти стул у стола недалеко от пешки (RimWorld: еду несут к столу)
function findDiningChair(game: Game, pawn: Pawn): { id: number; x: number; y: number } | null {
  let best: { id: number; x: number; y: number } | null = null;
  let bestD = Infinity;
  const px = Math.floor(pawn.x);
  const py = Math.floor(pawn.y);
  for (const c of game.world.buildings) {
    if (c.blueprint || c.type !== BType.Chair) continue;
    // рядом со стулом должен стоять готовый стол
    let hasTable = false;
    for (let dy = -1; dy <= 1 && !hasTable; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        const t = game.world.buildingMap.get(game.world.idx(c.x + dx, c.y + dy));
        if (t && !t.blueprint && t.type === BType.Table) {
          hasTable = true;
          break;
        }
      }
    }
    if (!hasTable) continue;
    const d = cheb(px, py, c.x, c.y);
    if (d <= DINE_SEARCH_R && d < bestD) {
      bestD = d;
      best = { id: c.id, x: c.x, y: c.y };
    }
  }
  return best;
}

// ---- Сон ----
export function startSleep(game: Game, pawn: Pawn, collapse: boolean) {
  rememberBoardJob(pawn);
  releaseBoardJob(game, pawn);
  // своя кровать -> ближайшая свободная -> земля.
  // Кровать используется и при обморочной усталости — если она не слишком далеко.
  let bed: { x: number; y: number; id: number } | null = null;
  let bd = Infinity;
  for (const b of game.world.buildings) {
    if (b.type !== BType.Bed || b.blueprint) continue;
    if (b.ownerId !== null && b.ownerId !== pawn.id) continue;
    const d = dist(pawn.x, pawn.y, b.x + 0.5, b.y + 0.5);
    const own = b.ownerId === pawn.id;
    if (own) {
      if (d < bd) {
        bd = d;
        bed = { x: b.x, y: b.y, id: b.id };
      }
    } else if (!bed && d < bd) {
      bd = d;
      bed = { x: b.x, y: b.y, id: b.id };
    }
  }
  if (bed && (!collapse || bd < 12)) {
    pawn.bedId = bed.id;
    pawn.job = { kind: 'sleep', tile: game.world.idx(bed.x, bed.y), buildingId: bed.id, stage: 0, progress: 0 };
    const p = pathToTile(game.world, Math.floor(pawn.x), Math.floor(pawn.y), bed.x, bed.y, false);
    if (setPath(game, pawn, p)) {
      const bb = game.world.buildings.find((q) => q.id === bed!.id);
      if (bb) bb.ownerId = pawn.id;
      return;
    }
    pawn.job = null;
  }
  // сон на земле
  pawn.job = { kind: 'sleep', tile: game.world.idx(Math.floor(pawn.x), Math.floor(pawn.y)), stage: 0, progress: 0, ground: true };
  pawn.addMod('sleptGround', 'Сон на земле', -4, 480, game.clock.totalMin);
  pawn.state = 'sleep';
}

function sleepUpdate(game: Game, pawn: Pawn) {
  const h = game.clock.hour;
  const rested = pawn.rest >= 98;
  const morning = h >= 6 && h < 10 && pawn.rest > 65;
  if (rested || morning) {
    if (pawn.job && !pawn.job.ground) {
      pawn.addMod('sleptBed', 'Выспался в кровати', 6, 480, game.clock.totalMin);
      // уют: кровать в круге света костра
      for (const f of game.world.campfires()) {
        if (pawn.job && dist(f.x + 0.5, f.y + 0.5, (pawn.job.tile % 64) + 0.5, ((pawn.job.tile / 64) | 0) + 0.5) <= 5.5) {
          pawn.addMod('cozy', 'Уютно у огня', 4, 480, game.clock.totalMin);
          break;
        }
      }
    }
    pawn.job = null;
    pawn.state = 'idle';
  }
}

// ---- Бой ----
export function startFight(game: Game, pawn: Pawn, animalId: number) {
  rememberBoardJob(pawn);
  releaseBoardJob(game, pawn);
  pawn.combatTargetId = animalId;
  pawn.path = null;
  pawn.state = 'fight';
}

// Один удар/выстрел по зверю (общий для боя и охоты)
function strikeAnimal(game: Game, pawn: Pawn, a: Animal) {
  const ranged = pawn.weapon === 'bow';
  if (ranged) {
    // стрела летит — урон и навык Стрельбы
    pawn.atkCd = 1.2;
    const dmg = 3 + Math.random() * 3 + pawn.skillLvl('ranged') * 0.3;
    game.spawnArrow(pawn.x, pawn.y, a.x, a.y);
    game.damageAnimal(a, dmg, pawn.id);
    pawn.addXp('ranged', 1);
  } else if (pawn.weapon === 'sword') {
    // меч: самое сильное оружие ближнего боя, бьёт чаще копья
    pawn.atkCd = SWORD_ATK_CD;
    const dmg = SWORD_DMG + Math.random() * SWORD_DMG_RAND + pawn.skillLvl('melee') * 0.35;
    game.damageAnimal(a, dmg, pawn.id);
    pawn.addXp('melee', 1);
  } else if (pawn.weapon === null) {
    // безоружное сопротивление: кулаки слабы, но лучше смерти в спину
    pawn.atkCd = 1.2;
    const dmg = 2 + Math.random() * 2 + pawn.skillLvl('melee') * 0.15;
    game.damageAnimal(a, dmg, pawn.id);
    pawn.addXp('melee', 1);
  } else {
    pawn.atkCd = 1.0;
    const spear = pawn.weapon === 'spear' ? SPEAR_DMG_BONUS : 0;
    const dmg = 4 + Math.random() * 4 + pawn.skillLvl('melee') * 0.25 + spear;
    game.damageAnimal(a, dmg, pawn.id);
    pawn.addXp('melee', 1);
  }
}

function fightUpdate(game: Game, pawn: Pawn, dtG: number) {
  const a = game.animals.find((an) => an.id === pawn.combatTargetId);
  if (!a || a.dead) {
    pawn.combatTargetId = null;
    pawn.state = 'idle';
    pawn.unreachN = 0;
    pawn.addXp('melee', XP_PER_ACTION);
    return;
  }
  const c = cheb(Math.floor(pawn.x), Math.floor(pawn.y), Math.floor(a.x), Math.floor(a.y));
  const ranged = pawn.weapon === 'bow';
  const range = ranged ? BOW_RANGE : 1;
  if (c <= range) {
    pawn.path = null;
    pawn.unreachN = 0;
    if (pawn.atkCd <= 0) strikeAnimal(game, pawn, a);
    return;
  }
  if (pawn.repathCd <= 0 || !pawn.path) {
    pawn.repathCd = 0.7;
    const p = pathToAdjacent(game.world, Math.floor(pawn.x), Math.floor(pawn.y), game.world.idx(Math.floor(a.x), Math.floor(a.y)), false);
    if (p) {
      pawn.path = p;
      pawn.pathI = 0;
      pawn.unreachN = 0;
    } else {
      // цель недостижима (заперта деревьями/скалами): висеть в бою вечно нельзя —
      // после трёх неудач разрываем бой, пешка возвращается к жизни
      pawn.unreachN++;
      if (pawn.unreachN >= 3) {
        pawn.unreachN = 0;
        pawn.combatTargetId = null;
        pawn.path = null;
        pawn.state = 'idle';
        return;
      }
    }
  }
  stepAlong(pawn, dtG, WALK * pawn.walkMult() * game.walkPenalty());
}

// ---- Охота (RimWorld-стиль): помеченный зверь, один охотник, добыча сама ----
// Лук останавливается на дистанции выстрела; ближний боец подходит вплотную.
// Убитая дичь оставляет мясо и шкуру — их отнесут на склад переносчики.
function huntUpdate(game: Game, pawn: Pawn, dtG: number) {
  const j = pawn.job!;
  const a = game.animals.find((an) => an.id === j.itemId && !an.dead);
  // дичь убита кем-то другим, убежала из метки или охоту отменили:
  // освобождаем задачу на доске — иначе клейм протухнет и зверя никто не возьмёт
  if (!a || !game.huntList.has(a.id)) {
    pawn.huntFailN = 0;
    dropJob(game, pawn, j);
    return;
  }
  // пешка не справится с такой дичью (подобрал лук — может, теперь возьмётся другой)
  if (!hunterCapable(pawn.weapon, a.kind)) {
    if (pawn.repathCd <= 0) {
      pawn.repathCd = 5;
      const fast = a.kind === 'deer' || a.kind === 'rabbit';
      game.events.log(`${pawn.name}: ${fast ? 'без лука такую дичь не догнать' : 'на такого зверя без оружия идти нельзя'}.`, 'info');
    }
    dropJob(game, pawn, j);
    return;
  }
  const ranged = pawn.weapon === 'bow';
  const range = ranged ? BOW_RANGE : 1;
  const c = cheb(Math.floor(pawn.x), Math.floor(pawn.y), Math.floor(a.x), Math.floor(a.y));
  if (c <= range) {
    pawn.path = null;
    pawn.state = 'work';
    if (pawn.atkCd <= 0) strikeAnimal(game, pawn, a);
    return;
  }
  // догоняем дичь (путь перестраивается — зверь двигается)
  if (pawn.repathCd <= 0 || !pawn.path) {
    pawn.repathCd = 0.7;
    const p = pathToAdjacent(game.world, Math.floor(pawn.x), Math.floor(pawn.y), game.world.idx(Math.floor(a.x), Math.floor(a.y)), false);
    if (!p) {
      // дичь заперта деревьями/скалами: несколько попыток — и снимаем метку,
      // иначе охотник вечно топчется перед невидимой стеной
      pawn.huntFailN++;
      if (pawn.huntFailN >= 4) {
        pawn.huntFailN = 0;
        game.huntList.delete(a.id);
        game.events.log(`Охота на «${a.name}» отменена: зверь недостижим — заперт скалами или буреломом.`, 'info');
      }
      dropJob(game, pawn, j);
      return;
    }
    pawn.huntFailN = 0;
    pawn.path = p;
    pawn.pathI = 0;
  }
  pawn.state = 'move';
  stepAlong(pawn, dtG, WALK * pawn.walkMult() * game.walkPenalty());
  // лучник дошёл до дистанции выстрела — остановиться и целиться
  if (ranged && cheb(Math.floor(pawn.x), Math.floor(pawn.y), Math.floor(a.x), Math.floor(a.y)) <= BOW_RANGE) {
    pawn.path = null;
    pawn.state = 'work';
  }
}

// ---- Бегство ----
export function startFlee(game: Game, pawn: Pawn) {
  rememberBoardJob(pawn);
  releaseBoardJob(game, pawn);
  pawn.state = 'flee';
  pawn.fleeT = 0;
  pawn.path = null;
}

// Бегство ОТ зверя, а не «к базе сквозь зверя»: веер направлений от вектора
// в противоположную сторону. Зажатый в угол пешка перестаёт бежать и дерётся —
// даже безоружная: сопротивление лучше смерти в спину.
function fleeUpdate(game: Game, pawn: Pawn, dtG: number) {
  const { beast, d } = nearestThreat(game, pawn, 11);
  if (!beast || (d > 11 && beast.targetPawnId !== pawn.id)) {
    pawn.state = 'idle';
    pawn.path = null;
    return;
  }
  const c = cheb(Math.floor(pawn.x), Math.floor(pawn.y), Math.floor(beast.x), Math.floor(beast.y));
  if (c <= 1 && pawn.atkCd <= 0 && (pawn.weapon !== null || !pawn.path)) {
    // зверь вплотную: вооружённый даёт отпор, безоружный — только если бежать некуда
    startFight(game, pawn, beast.id);
    return;
  }
  pawn.fleeT -= dtG;
  if (pawn.fleeT <= 0 || !pawn.path) {
    pawn.fleeT = 1.2;
    const px = Math.floor(pawn.x);
    const py = Math.floor(pawn.y);
    const bx = Math.floor(beast.x);
    const by = Math.floor(beast.y);
    let ux = px - bx;
    let uy = py - by;
    const L = Math.hypot(ux, uy) || 1;
    ux /= L;
    uy /= L;
    // веер: прямо от зверя, потом ±30°, ±60°, вбок ±90°
    const angles = [0, 0.5, -0.5, 1.05, -1.05, 1.57, -1.57];
    let found: PathNode[] | null = null;
    for (const ang of angles) {
      const ca = Math.cos(ang);
      const sa = Math.sin(ang);
      const rx = ux * ca - uy * sa;
      const ry = ux * sa + uy * ca;
      const tx = Math.max(1, Math.min(MAP - 2, Math.round(px + rx * 8)));
      const ty = Math.max(1, Math.min(MAP - 2, Math.round(py + ry * 8)));
      const p = pathToTile(game.world, px, py, tx, ty, false);
      if (p) {
        found = p;
        break;
      }
    }
    if (found) {
      pawn.path = found;
      pawn.pathI = 0;
    } else {
      // бежать некуда — зажат: кулаки тоже оружие
      startFight(game, pawn, beast.id);
      return;
    }
  }
  stepAlong(pawn, dtG, WALK * pawn.walkMult() * game.walkPenalty() * 1.15);
}

// ---- Срыв (психика сломалась от низкого настроения) ----
function startBreak(game: Game, pawn: Pawn) {
  releaseBoardJob(game, pawn);
  pawn.path = null;
  // выбор типа: рядом есть кто живой — срывается на людей; есть костёр — слёзы; иначе оцепенение
  const others = game.pawns.filter((q) => q !== pawn && !q.dead && dist(pawn.x, pawn.y, q.x, q.y) < 6);
  const fire = nearestCampfire(game, pawn);
  let kind: BreakKind;
  if (others.length > 0 && game.rng.next() < 0.5) kind = 'insult';
  else if (fire && game.rng.next() < 0.6) kind = 'sob';
  else kind = 'daze';

  pawn.breakKind = kind;
  pawn.insultT = 20;
  pawn.state = 'break';
  const name = pawn.name;
  const hasFire = Boolean(fire);
  switch (kind) {
    case 'insult':
      pawn.breakMin = 120;
      game.events.log(`${name} не выдержал(а): настроение сорвалось в злость. ${pawn.gender === 'ж' ? 'Она' : 'Он'} оскорбляет всех подряд!`, 'bad');
      break;
    case 'sob':
      pawn.breakMin = 90;
      game.events.log(`${name} горько плачет${hasFire ? ' у костра' : ''}. Никто не знает, что сказать.`, 'bad');
      if (fire) {
        const p = pathToTile(game.world, Math.floor(pawn.x), Math.floor(pawn.y), fire.x, fire.y, false);
        if (p) setPath(game, pawn, p); // дойти до костра и плакать там
      }
      break;
    default:
      pawn.breakMin = 180;
      game.events.log(`${name} замер(ла) и побрёл(а) в оцепенении, не слыша зова.`, 'bad');
  }
}

function breakUpdate(game: Game, pawn: Pawn, dtG: number) {
  pawn.breakMin -= dtG;
  if (pawn.breakMin <= 0) {
    endBreak(game, pawn);
    return;
  }
  if (pawn.breakKind === 'insult') {
    // вспышки оскорблений раз в ~40 игровых минут
    pawn.insultT -= dtG;
    if (pawn.insultT <= 0) {
      pawn.insultT = 40;
      let hit = 0;
      for (const q of game.pawns) {
        if (q === pawn || q.dead) continue;
        if (dist(pawn.x, pawn.y, q.x, q.y) > 5) continue;
        game.addRelation(pawn.id, q.id, -10);
        q.addMod('insulted', 'Оскорблён(а)', -5, 480, game.clock.totalMin);
        game.events.log(`${pawn.name} кричит на ${q.name} грубые вещи.`, 'bad');
        hit++;
      }
      if (hit === 0) {
        // рядом никого — переходит в блуждание
        pawn.breakKind = 'daze';
      }
    }
    if (!pawn.path) {
      wanderDuringBreak(game, pawn);
      return;
    }
    stepAlong(pawn, dtG, WALK * pawn.walkMult() * game.walkPenalty() * 0.6);
    return;
  }
  if (pawn.breakKind === 'daze') {
    if (!pawn.path) wanderDuringBreak(game, pawn);
    else stepAlong(pawn, dtG, WALK * pawn.walkMult() * game.walkPenalty() * 0.55);
  }
  // 'sob': сидит у костра (или где стоял), дойти по ранее заданному пути
  else if (pawn.path) {
    stepAlong(pawn, dtG, WALK * pawn.walkMult() * game.walkPenalty() * 0.8);
  }
}

function wanderDuringBreak(game: Game, pawn: Pawn) {
  const base = game.world.stockpileCenter() ?? { x: game.spawnX, y: game.spawnY };
  const tx = Math.max(1, Math.min(62, Math.round(base.x + (Math.random() * 12 - 6))));
  const ty = Math.max(1, Math.min(62, Math.round(base.y + (Math.random() * 12 - 6))));
  if (game.world.passPawn(tx, ty)) {
    const p = pathToTile(game.world, Math.floor(pawn.x), Math.floor(pawn.y), tx, ty, false);
    if (p && p.length > 0) setPath(game, pawn, p);
  }
}

function endBreak(game: Game, pawn: Pawn) {
  pawn.breakMin = 0;
  pawn.breakKind = null;
  pawn.breakCd = 2880; // два дня психика держится
  pawn.path = null;
  pawn.job = null;
  pawn.state = 'idle';
  pawn.addMod('composed', 'Пришёл(ла) в себя', 5, 480, game.clock.totalMin);
  game.events.log(`${pawn.name} пришёл(ла) в себя. Колония выдыхает.`, 'good');
}

function nearestCampfire(game: Game, pawn: Pawn): { x: number; y: number } | null {
  let best: { x: number; y: number } | null = null;
  let bd = Infinity;
  for (const f of game.world.campfires()) {
    const d = dist(pawn.x, pawn.y, f.x + 0.5, f.y + 0.5);
    if (d < bd) {
      bd = d;
      best = f;
    }
  }
  return best;
}

// Шанс сорваться за один тик решения, если настроение на дне
function breakChanceFor(pawn: Pawn): number {
  let c = 0.15;
  if (pawn.hasTrait('brave') || pawn.hasTrait('hardworker')) c *= 0.5;
  if (pawn.hasTrait('coward') || pawn.hasTrait('loner')) c *= 1.6;
  return c;
}

// ---- Простой ----
function idleUpdate(game: Game, pawn: Pawn, dtG: number) {
  // разговоры
  if (pawn.talkCd <= 0) {
    for (const other of game.pawns) {
      if (other === pawn || other.dead || other.state !== 'idle') continue;
      if (dist(pawn.x, pawn.y, other.x, other.y) < 2.5) {
        pawn.talkCd = 120;
        other.talkCd = 120;
        const delta = pawn.hasTrait('loner') || other.hasTrait('loner') ? 1 : 2;
        pawn.addMod('talked', 'Разговор', delta, 120, game.clock.totalMin);
        other.addMod('talked', 'Разговор', delta, 120, game.clock.totalMin);
        game.addRelation(pawn.id, other.id, 1);
        break;
      }
    }
  }
  pawn.wanderT -= dtG;
  if (pawn.wanderT <= 0 && !pawn.path) {
    pawn.wanderT = 8 + Math.random() * 10;
    const base = game.world.stockpileCenter() ?? { x: game.spawnX, y: game.spawnY };
    const tx = Math.max(1, Math.min(62, Math.round(base.x + (Math.random() * 10 - 5))));
    const ty = Math.max(1, Math.min(62, Math.round(base.y + (Math.random() * 10 - 5))));
    if (game.world.passPawn(tx, ty)) {
      const p = pathToTile(game.world, Math.floor(pawn.x), Math.floor(pawn.y), tx, ty, false);
      if (p && p.length > 0) {
        pawn.path = p;
        pawn.pathI = 0;
        pawn.state = 'idle'; // гуляем не меняя состояния работ
      }
    }
  }
  if (pawn.path) {
    stepAlong(pawn, dtG, WALK * pawn.walkMult() * game.walkPenalty() * 0.7);
    if (!pawn.path || pawn.pathI >= (pawn.path?.length ?? 0)) pawn.path = null;
  }
}

// Общий шаг без смены состояния
function stepAlong(pawn: Pawn, dtG: number, speed: number) {
  if (!pawn.path) return;
  let budget = speed * dtG;
  while (budget > 0 && pawn.path && pawn.pathI < pawn.path.length) {
    const node = pawn.path[pawn.pathI];
    const tx = node.x + 0.5;
    const ty = node.y + 0.5;
    const dx = tx - pawn.x;
    const dy = ty - pawn.y;
    const d = Math.hypot(dx, dy);
    if (d <= budget) {
      pawn.x = tx;
      pawn.y = ty;
      budget -= d;
      pawn.pathI++;
    } else {
      pawn.x += (dx / d) * budget;
      pawn.y += (dy / d) * budget;
      budget = 0;
    }
  }
}

// ===================== Решение AI (вызывается периодически) =====================

export function decidePawn(game: Game, pawn: Pawn) {
  if (pawn.dead) return;
  if (pawn.underground) return; // шахтёр в глубинах: звери его не чуют, нужды решает Game.updateExpeditions
  pawn.modsNow = game.clock.totalMin;

  // --- 1. Угрозы ---
  const { wolf, d } = nearestWolf(game, pawn);
  if (wolf) {
    const brave = pawn.hasTrait('brave');
    const coward = pawn.hasTrait('coward');
    if (game.attackTargetId === wolf.id) {
      if (!pawn.hasTrait('coward') || brave) {
        startFight(game, pawn, wolf.id);
        return;
      }
    }
    if (brave && d < 8 && pawn.state !== 'fight') {
      startFight(game, pawn, wolf.id);
      return;
    }
    // боевая тревога: смелые и опытные бойцы бегут защищать лагерь (спящих не будим —
    // он встанет, если волк подойдёт вплотную)
    if (game.alarmMin > 0 && pawn.state !== 'sleep' && pawn.state !== 'fight' && pawn.state !== 'flee') {
      const militia = pawn.skillLvl('melee') >= 5 && pawn.hp > 40;
      if ((brave && d < 24) || (militia && !coward && d < 16)) {
        startFight(game, pawn, wolf.id);
        return;
      }
    }
    if (coward && d < 7 && pawn.state !== 'flee') {
      startFlee(game, pawn);
      return;
    }
    if (d < 4.5 || (d < 6 && wolf.targetPawnId === pawn.id)) {
      if (!isHuntingTarget(pawn, wolf.id)) {
        if (!coward && pawn.hp > 45 && cAdj(pawn, wolf)) {
          startFight(game, pawn, wolf.id);
        } else if (pawn.state !== 'flee') {
          startFlee(game, pawn);
        }
        return;
      }
      // охота на волка: не разбегаемся — huntUpdate сам решит, когда бить
    }
  } else if (pawn.state === 'flee') {
    pawn.state = 'idle';
    pawn.path = null;
  }

  // --- 1.5 Медведи и кабаны: хищник в угодьях опаснее любой работы ---
  // (кабан взбешён и идёт на обидчика; медведь защищает угодья; промедление = смерть)
  if (!wolf) {
    const { beast, d: bd } = nearestThreat(game, pawn, 6);
    if (beast && !isHuntingTarget(pawn, beast.id)) {
      const coward = pawn.hasTrait('coward');
      const armed = pawn.weapon !== null || pawn.armor !== null;
      if (game.attackTargetId === beast.id && !coward) {
        startFight(game, pawn, beast.id);
        return;
      }
      if (!coward && armed && bd < 5 && pawn.hp > 45) {
        startFight(game, pawn, beast.id);
        return;
      }
      if (pawn.state !== 'flee') {
        startFlee(game, pawn);
        return;
      }
    }
  }

  // --- Приказ "Атаковать" ---
  if (game.attackTargetId !== null && pawn.state !== 'fight' && !pawn.hasTrait('coward') && pawn.hp > 40) {
    const target = game.animals.find((a) => a.id === game.attackTargetId && !a.dead);
    if (target) {
      startFight(game, pawn, target.id);
      return;
    }
  }

  // --- 2. Критические потребности ---
  if (pawn.food < 12 && pawn.state !== 'eat' && pawn.job?.kind !== 'eat' && !isSelfForaging(pawn) && game.eatFailCd <= 0) {
    if (startEat(game, pawn)) return;
    // еды нет вообще — продолжаем жить/работать, голод медленно убивает
  }
  if (pawn.rest < 10 && pawn.state !== 'sleep') {
    startSleep(game, pawn, true);
    return;
  }

  // --- 3. Спит — не мешать ---
  if (pawn.state === 'sleep') return;
  if (pawn.state === 'eat' && pawn.food < 70) return;
  if (pawn.state === 'fight' || pawn.state === 'flee') return;

  // --- 3.5 Холод: замерзающая пешка сама идёт греться к костру (зимний ИИ) ---
  if (pawn.job?.kind === 'warm') {
    // уже греемся: стоим у огня, пока не отпустит мороз (мод снимет updateCold)
    if (!pawn.hasMod('cold')) pawn.job = null; // отогрелся — вернулись к жизни
    return;
  }
  if (pawn.hasMod('cold') && startWarm(game, pawn)) return;

  // --- 4. Ночной сон (замерзающую пешку не укладываем в снег — сперва огонь) ---
  const h = game.clock.hour;
  const lateNight = h >= 22 || h < 5;
  const evening = h >= 21 && h < 22;
  if (lateNight && pawn.rest < 60 && pawn.state !== 'sleep' && !pawn.hasMod('cold')) {
    startSleep(game, pawn, false);
    return;
  }
  if (evening && pawn.rest < 45 && pawn.state !== 'sleep' && !pawn.hasMod('cold')) {
    startSleep(game, pawn, false);
    return;
  }

  // --- 5. Обычный голод ---
  if (pawn.food < 30 && pawn.state !== 'eat' && pawn.job?.kind !== 'eat' && !isSelfForaging(pawn) && game.eatFailCd <= 0) {
    if (startEat(game, pawn)) return;
    // еды нет — работаем дальше
  }

  // --- 5.2 Срыв: настроение на дне ломает психику ---
  if (pawn.breakMin > 0) {
    // срыв прерван угрозой/сном/едой — возобновляем, пока он не кончился
    if (pawn.state !== 'break') {
      pawn.path = null;
      pawn.state = 'break';
    }
    return;
  }
  if (pawn.breakCd <= 0 && moodOf(game, pawn) < 15) {
    if (game.rng.chance(breakChanceFor(pawn))) {
      startBreak(game, pawn);
      return;
    }
    pawn.breakCd = 90; // проверим снова через полтора часа — не каждый тик
  }

  // --- 5.5 Лечение: медик навещает больного (utility: навык медицины + близость) ---
  if (pawn.state === 'idle' && !pawn.job && pawn.sickMin <= 0 && pawn.skillLvl('medicine') >= 3 && pawn.food > 25 && pawn.rest > 25) {
    let patient: Pawn | null = null;
    let pd = 25;
    for (const q of game.pawns) {
      if (q === pawn || q.dead || q.sickMin <= 0 || q.hasMod('treated')) continue;
      // одного больного навещает только один медик
      if (game.pawns.some((o) => o !== pawn && !o.dead && o.job?.kind === 'doctor' && o.job.itemId === q.id)) continue;
      const d = dist(pawn.x, pawn.y, q.x, q.y);
      if (d < pd) {
        pd = d;
        patient = q;
      }
    }
    if (patient) {
      startDoctor(game, pawn, patient);
      return;
    }
  }

  // --- 6. Несёт груз -> сам донесёт (только в простое) ---
  if (pawn.inv && pawn.state === 'idle') {
    startOwnHaul(game, pawn);
    return;
  }

  // --- 6.5 Снаряжение: безоружный подберёт оружие, слабое — поменяет на лучшее ---
  // (меч > лук > копьё; кожаная броня меняется на железную; старое падает на землю —
  // пригодится следующему колонисту; приоритет: оружие → броня → куртка)
  if (pawn.state === 'idle' && !pawn.job && !pawn.inv) {
    const curTier = pawn.weapon ? WEAPON_TIER[pawn.weapon] : 0;
    let wi: { id: number; x: number; y: number } | null = null;
    let wd = Infinity;
    for (const it of game.world.items) {
      if (it.type !== Res.Spear && it.type !== Res.Bow && it.type !== Res.Sword) continue;
      const tier = WEAPON_TIER[it.type === Res.Sword ? 'sword' : it.type === Res.Bow ? 'bow' : 'spear'];
      if (tier <= curTier) continue; // только апгрейд — никакой карусели обменов
      const d = dist(pawn.x, pawn.y, it.x + 0.5, it.y + 0.5);
      if (d < wd) {
        wd = d;
        wi = it;
      }
    }
    if (wi) {
      startEquip(game, pawn, wi);
      return;
    }
    // броня: кожаная интересна только тем, у кого ничего нет; железная — всем (апгрейд)
    if (pawn.armor !== 'iron') {
      const ironOnGround = game.world.items.some((q) => q.type === Res.IronArmor);
      let ai: { id: number; x: number; y: number } | null = null;
      let ad = Infinity;
      for (const it of game.world.items) {
        if (it.type !== Res.IronArmor && it.type !== Res.LeatherArmor) continue;
        if (it.type === Res.LeatherArmor && (pawn.armor !== null || ironOnGround)) continue;
        const d = dist(pawn.x, pawn.y, it.x + 0.5, it.y + 0.5);
        if (d < ad) {
          ad = d;
          ai = it;
        }
      }
      if (ai) {
        startEquip(game, pawn, ai);
        return;
      }
    }
    // куртка
    if (!pawn.cloth) {
      let ci: { id: number; x: number; y: number } | null = null;
      let cd = Infinity;
      for (const it of game.world.items) {
        if (it.type !== Res.Coat) continue;
        const d = dist(pawn.x, pawn.y, it.x + 0.5, it.y + 0.5);
        if (d < cd) {
          cd = d;
          ci = it;
        }
      }
      if (ci) {
        startEquip(game, pawn, ci);
        return;
      }
    }
  }

  // --- 7. Работа: не прерываем текущую, берём новую только в простое ---
  if (pawn.state === 'idle' && !pawn.job) {
    // сначала — возврат к прерванной задаче (сон, бегство, трапеза, мороз):
    // пешка «помнит», чем занималась, и не бросает дело на полпути
    if (pawn.resumeRef !== undefined) {
      const ref = pawn.resumeRef;
      pawn.resumeRef = undefined;
      const job = game.jobs.jobs.get(ref);
      if (job && job.claimedBy === null) {
        job.claimedBy = pawn.id;
        startBoardJob(game, pawn, job);
        return;
      }
    }
    const job = game.jobs.claim(game.world, pawn, game.realNow, game.jobExt());
    if (job) {
      startBoardJob(game, pawn, job);
    }
  }
}

function cAdj(pawn: Pawn, wolf: { x: number; y: number }): boolean {
  return cheb(Math.floor(pawn.x), Math.floor(pawn.y), Math.floor(wolf.x), Math.floor(wolf.y)) <= 1;
}

// Свободная проходимая клетка рядом с постройкой (выход из шахты, дроп добычи)
export function freeSpotNear(w: Game['world'], bx: number, by: number): { x: number; y: number } {
  for (let r = 1; r <= 2; r++) {
    for (let dy = -r; dy <= r; dy++) {
      for (let dx = -r; dx <= r; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        const x = bx + dx;
        const y = by + dy;
        if (!w.inBounds(x, y)) continue;
        const i = w.idx(x, y);
        if (!w.passPawn(x, y)) continue;
        if (w.buildingMap.has(i)) continue;
        return { x, y };
      }
    }
  }
  return { x: bx, y: by };
}

// ===================== Шахтные экспедиции =====================

// Отправить пешку к шахте: задача + путь до входа
export function startExpeditionWalk(game: Game, pawn: Pawn, mine: Building): boolean {
  const j: ActiveJob = { kind: 'expedition', tile: game.world.idx(mine.x, mine.y), buildingId: mine.id, stage: 0, progress: 0 };
  pawn.job = j;
  const p = pathToAdjacent(game.world, Math.floor(pawn.x), Math.floor(pawn.y), j.tile, false);
  if (!p || p.length === 0 || !setPath(game, pawn, p)) {
    pawn.job = null;
    return false;
  }
  return true;
}

// После загрузки сейва: восстановить экспедицию (в пути или уже под землёй)
export function resumeExpedition(game: Game, pawn: Pawn, mine: Building, stage: number) {
  const j: ActiveJob = { kind: 'expedition', tile: game.world.idx(mine.x, mine.y), buildingId: mine.id, stage, progress: 0 };
  pawn.job = j;
  if (stage >= 1) {
    pawn.underground = true;
    pawn.x = mine.x + 0.5;
    pawn.y = mine.y + 0.5;
    pawn.state = 'work';
    return;
  }
  pawn.state = 'move';
  const p = pathToAdjacent(game.world, Math.floor(pawn.x), Math.floor(pawn.y), j.tile, false);
  if (!p || !setPath(game, pawn, p)) {
    // путь не строится — пусть спустится прямо здесь
    pawn.underground = true;
    pawn.x = mine.x + 0.5;
    pawn.y = mine.y + 0.5;
    pawn.state = 'work';
    j.stage = 1;
  }
}

// Пешка уже идёт/собирает ягоды, чтобы поесть — не перебиваем задачу
function isSelfForaging(pawn: Pawn): boolean {
  return pawn.job !== null && pawn.job.kind === 'harvest' && pawn.job.jobRef === undefined;
}

// Старт задачи с доски
export function startBoardJob(game: Game, pawn: Pawn, job: Job) {
  const w = game.world;
  const px = Math.floor(pawn.x);
  const py = Math.floor(pawn.y);
  const j: ActiveJob = { kind: job.kind as ActiveJob['kind'], tile: job.tile, stage: 0, progress: 0, jobRef: job.id };
  if (job.itemId !== undefined) j.itemId = job.itemId;
  if (job.buildingId !== undefined) j.buildingId = job.buildingId;
  if (job.recipe !== undefined) j.recipe = job.recipe;
  pawn.job = j;

  if (job.kind === 'build') {
    const b = w.buildings.find((bb) => bb.id === job.buildingId);
    if (!b) {
      pawn.job = null;
      return;
    }
    j.stage = b.matHave >= b.matNeed ? 1 : 0;
  }
  startJobMove(game, pawn, j);
}

// Построить путь под текущую задачу
function startJobMove(game: Game, pawn: Pawn, j: ActiveJob) {
  const w = game.world;
  const px = Math.floor(pawn.x);
  const py = Math.floor(pawn.y);
  const tx = j.tile % 64;
  const ty = (j.tile / 64) | 0;
  let p: PathNode[] | null = null;

  switch (j.kind) {
    case 'hunt': {
      // дичь живая и двигается: путь до её текущей клетки; лучник в радиусе — уже «на месте»
      const prey = game.animals.find((an) => an.id === j.itemId && !an.dead);
      if (!prey) return dropJob(game, pawn, j);
      j.tile = w.idx(Math.floor(prey.x), Math.floor(prey.y));
      const cPrey = cheb(px, py, Math.floor(prey.x), Math.floor(prey.y));
      if (pawn.weapon === 'bow' && cPrey <= BOW_RANGE) {
        pawn.state = 'work';
        return;
      }
      p = pathToAdjacent(w, px, py, j.tile, false);
      break;
    }
    case 'chop':
    case 'mine':
    case 'harvest':
    case 'till':
    case 'plant':
    case 'crop':
    case 'expedition':
      if (j.kind === 'expedition') {
        const m = w.buildings.find((bb) => bb.id === j.buildingId);
        if (!m) return dropJob(game, pawn, j);
        j.tile = w.idx(m.x, m.y);
      }
      p = pathToAdjacent(w, px, py, j.tile, false);
      break;
    case 'cook': {
      if (j.stage === 0) {
        const item = w.items.find((it) => it.id === j.itemId);
        if (!item) return dropJob(game, pawn, j);
        j.tile = w.idx(item.x, item.y);
        p = pathToTile(w, px, py, item.x, item.y, false);
        if (!p) p = pathToAdjacent(w, px, py, j.tile, false);
      } else {
        const fire = w.buildings.find((bb) => bb.id === j.buildingId);
        if (!fire) return dropJob(game, pawn, j);
        j.tile = w.idx(fire.x, fire.y);
        p = pathToAdjacent(w, px, py, j.tile, false);
      }
      break;
    }
    case 'craft': {
      const wb = w.buildings.find((bb) => bb.id === j.buildingId);
      if (!wb) return dropJob(game, pawn, j);
      if (j.stage === 1) {
        j.tile = w.idx(wb.x, wb.y);
        p = pathToAdjacent(w, px, py, j.tile, false);
      } else {
        // ищем кучку материала, где хватает на рецепт (железо — на меч/броню, шкуры — на одежду, дерево — на прочее)
        const rec = RECIPES[j.recipe ?? 0];
        const matRes = rec ? craftMat(rec) : Res.Wood;
        const need = rec ? craftNeed(rec) : 4;
        let item: { id: number; x: number; y: number; qty: number } | null = null;
        let bd = Infinity;
        for (const it of w.items) {
          if (it.type !== matRes || it.qty < need) continue;
          const d = dist(pawn.x, pawn.y, it.x + 0.5, it.y + 0.5);
          if (d < bd) {
            bd = d;
            item = it;
          }
        }
        if (!item) return dropJob(game, pawn, j);
        j.itemId = item.id;
        j.tile = w.idx(item.x, item.y);
        p = pathToTile(w, px, py, item.x, item.y, false);
      }
      break;
    }
    case 'equip': {
      const item = w.items.find((it) => it.id === j.itemId && (it.type === Res.Spear || it.type === Res.Bow || it.type === Res.Sword || it.type === Res.Coat || it.type === Res.LeatherArmor || it.type === Res.IronArmor));
      if (!item) return dropJob(game, pawn, j);
      j.tile = w.idx(item.x, item.y);
      p = pathToTile(w, px, py, item.x, item.y, false);
      if (!p) p = pathToAdjacent(w, px, py, j.tile, false);
      break;
    }
    case 'loot':
    case 'eat':
    case 'bury':
      p = pathToTile(w, px, py, tx, ty, false);
      if (!p) p = pathToAdjacent(w, px, py, j.tile, false);
      break;
    case 'doctor':
      p = pathToAdjacent(w, px, py, j.tile, false);
      break;
    case 'haul': {
      if (j.stage === 0) {
        const item = w.items.find((it) => it.id === j.itemId);
        if (!item) return dropJob(game, pawn, j);
        p = pathToTile(w, px, py, item.x, item.y, false);
      } else {
        // к складу или чертежу
        if (pawn.inv) {
          const b = w.buildings.find((bb) => bb.blueprint && bb.matType === pawn.inv!.type && bb.matHave < bb.matNeed);
          if (b) {
            j.buildingId = b.id;
            j.tile = w.idx(b.x, b.y);
            p = pathToTile(w, px, py, b.x, b.y, false);
          }
        }
        if (!p) {
          const tile = w.findStockpileTile((pawn.inv?.type ?? 0) as Res, px, py);
          if (!tile) return dropJob(game, pawn, j);
          j.tile = w.idx(tile.x, tile.y);
          p = pathToTile(w, px, py, tile.x, tile.y, false);
        }
      }
      break;
    }
    case 'build': {
      const b = w.buildings.find((bb) => bb.id === j.buildingId);
      if (!b) return dropJob(game, pawn, j);
      if (j.stage === 1) {
        p = pathToAdjacent(w, px, py, w.idx(b.x, b.y), false);
      } else {
        // за материалом
        const item = findMatFor(game, pawn, b.matType);
        if (!item) return dropJob(game, pawn, j);
        j.itemId = item.id;
        j.tile = w.idx(item.x, item.y);
        p = pathToTile(w, px, py, item.x, item.y, false);
      }
      break;
    }
    case 'sleep': {
      const b = j.buildingId !== undefined ? w.buildings.find((bb) => bb.id === j.buildingId) : undefined;
      if (b) p = pathToTile(w, px, py, b.x, b.y, false);
      else {
        pawn.state = 'sleep';
        return;
      }
      break;
    }
    default:
      p = null;
  }

  if (!setPath(game, pawn, p)) {
    dropJob(game, pawn, j);
  }
}

function dropJob(game: Game, pawn: Pawn, j: ActiveJob) {
  if (j.jobRef !== undefined) {
    game.jobs.failAttempt(pawn.id, j.jobRef, game.realNow);
    const job = game.jobs.jobs.get(j.jobRef);
    if (job) game.jobs.release(job, pawn.id);
  }
  pawn.job = null;
  pawn.state = 'idle';
}

// Лечение больного: прийти и заняться уходом (jobRef нет — внутренняя задача)
export function startDoctor(game: Game, pawn: Pawn, patient: Pawn) {
  releaseBoardJob(game, pawn);
  pawn.job = { kind: 'doctor', tile: game.world.idx(Math.floor(patient.x), Math.floor(patient.y)), itemId: patient.id, stage: 0, progress: 0 };
  const p = pathToAdjacent(game.world, Math.floor(pawn.x), Math.floor(pawn.y), pawn.job.tile, false);
  if (!setPath(game, pawn, p)) {
    pawn.job = null;
    pawn.state = 'idle';
  }
}

// Безоружная пешка идёт за лежащим оружием (jobRef нет — внутренняя задача)
export function startEquip(game: Game, pawn: Pawn, item: { id: number; x: number; y: number }) {
  releaseBoardJob(game, pawn);
  pawn.job = { kind: 'equip', tile: game.world.idx(item.x, item.y), itemId: item.id, stage: 0, progress: 0 };
  const p = pathToTile(game.world, Math.floor(pawn.x), Math.floor(pawn.y), item.x, item.y, false);
  if (!setPath(game, pawn, p)) {
    pawn.job = null;
    pawn.state = 'idle';
  }
}

// Собственная переноска (уже что-то несёт)
export function startOwnHaul(game: Game, pawn: Pawn) {
  if (!pawn.inv) return;
  releaseBoardJob(game, pawn);
  const j: ActiveJob = { kind: 'haul', tile: 0, stage: 1, progress: 0 };
  pawn.job = j;
  startJobMove(game, pawn, j);
}

// Прибытие к ягодному кусту, собранному "для себя": сразу есть (за столом, если он рядом)
export function afterSelfHarvest(game: Game, pawn: Pawn, tile: number) {
  const items = game.world.itemsAt(tile % 64, (tile / 64) | 0);
  const food = items.find((it) => it.type === Res.Food);
  if (food && pawn.food < 75) {
    // как и в обычной трапезе: если недалеко есть стул у стола — несём еду туда
    const chair = !pawn.inv ? findDiningChair(game, pawn) : null;
    pawn.job = {
      kind: 'eat',
      tile,
      itemId: food.id,
      stage: 0,
      progress: 0,
      ...(chair ? { buildingId: chair.id } : {}),
    };
    const p = pathToTile(game.world, Math.floor(pawn.x), Math.floor(pawn.y), food.x, food.y, false);
    if (setPath(game, pawn, p)) return;
  }
  pawn.job = null;
  pawn.state = 'idle';
}

// ---- Ночные волки ----
export function nightWolfChance(day: number): number {
  return Math.min(0.35 + 0.12 * (day - 1), 0.85);
}

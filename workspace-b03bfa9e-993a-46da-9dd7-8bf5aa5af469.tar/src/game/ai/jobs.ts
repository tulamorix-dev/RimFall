// Доска работ: игрок отдаёт приказы -> задачи -> AI сам выбирает исполнителя

import { BType, HUNT_BOW_ONLY, HUNT_DANGEROUS, MAP, MIN_FOOD_TO_COOK, Obj, RECIPES, Res, Zone, FarmStage, WorkCat, craftMat, craftNeed } from '../data/defs';
import type { Item, World } from '../world/world';

export type JobKind = 'chop' | 'mine' | 'harvest' | 'till' | 'plant' | 'crop' | 'build' | 'haul' | 'loot' | 'bury' | 'cook' | 'craft' | 'hunt';

export interface Job {
  id: number;
  kind: JobKind;
  tile: number;
  cat: WorkCat;
  itemId?: number;
  buildingId?: number;
  recipe?: number; // для craft: индекс рецепта в RECIPES
  claimedBy: number | null;
}

const CAT_OF: Record<JobKind, WorkCat> = {
  chop: 'lumber',
  mine: 'mine',
  harvest: 'farm',
  till: 'farm',
  plant: 'farm',
  crop: 'farm',
  build: 'build',
  haul: 'haul',
  loot: 'haul',
  bury: 'haul',
  cook: 'cook',
  craft: 'build',
  hunt: 'hunt',
};

// Навык, влияющий на выбор задачи (для переноски навыка нет — всегда 0)
const SKILL_OF: Record<JobKind, string> = {
  chop: 'lumber',
  mine: 'mine',
  harvest: 'farm',
  till: 'farm',
  plant: 'farm',
  crop: 'farm',
  build: 'build',
  haul: 'haul',
  loot: 'haul',
  bury: 'haul',
  cook: 'cook',
  craft: 'build',
  hunt: 'ranged',
};

// Данные извне (из Game) для генерации задач готовки, крафта и охоты
export interface JobExt {
  alive: number;
  meals: number; // похлёбки в мире (склад + земля)
  food: number; // сырой еды в мире
  spears: number; // копий (на земле + в руках)
  bows: number; // луков (на земле + в руках)
  swords: number; // мечей (на земле + в руках)
  coats: number; // тёплых курток (на земле + на пешках)
  leathers: number; // кожаной брони
  irons: number; // железной брони
  hunt: { id: number; kind: string; x: number; y: number }[]; // звери, помеченные для охоты
}

// Сможет ли этот охотник добыть такую дичь (лук обязателен для убегающей дичи,
// оружие — для той, что может ответить)
export function hunterCapable(weapon: string | null | undefined, kind: string): boolean {
  if (kind === 'trader') return false;
  if (HUNT_BOW_ONLY.includes(kind)) return weapon === 'bow';
  if (HUNT_DANGEROUS.includes(kind)) return weapon !== null && weapon !== undefined;
  return true;
}

export class JobSystem {
  jobs = new Map<number, Job>();
  private nextId = 1;
  private byKey = new Map<string, number>();
  private failed = new Map<string, number>(); // "pawnId:jobId" -> до какого реального времени не пробовать

  key(kind: JobKind, ref: number): string {
    return `${kind}:${ref}`;
  }

  add(kind: JobKind, tile: number, ref: number, itemId?: number, buildingId?: number): Job {
    const job: Job = { id: this.nextId++, kind, tile, cat: CAT_OF[kind], itemId, buildingId, claimedBy: null };
    this.jobs.set(job.id, job);
    this.byKey.set(this.key(kind, ref), job.id);
    return job;
  }

  remove(job: Job) {
    this.jobs.delete(job.id);
    for (const [k, id] of this.byKey) if (id === job.id) this.byKey.delete(k);
  }

  removeByTile(kind: JobKind, tile: number) {
    const id = this.byKey.get(this.key(kind, tile));
    if (id) {
      const job = this.jobs.get(id);
      if (job) this.remove(job);
    }
  }

  removeByRef(kind: JobKind, ref: number) {
    this.removeByTile(kind, ref);
  }

  hasJob(kind: JobKind, ref: number): boolean {
    return this.byKey.has(this.key(kind, ref));
  }

  failAttempt(pawnId: number, jobId: number, nowReal: number) {
    this.failed.set(`${pawnId}:${jobId}`, nowReal + 4); // 4 секунды не претендовать
  }

  wasFailed(pawnId: number, jobId: number, nowReal: number): boolean {
    const t = this.failed.get(`${pawnId}:${jobId}`);
    return t !== undefined && t > nowReal;
  }

  // Пересборка доски: проверка валидности + добавление новых задач
  refresh(world: World, desig: { chop: Uint8Array; mine: Uint8Array; harvest: Uint8Array }, realNow: number, canHaul: boolean, ext: JobExt) {
    // --- Валидация существующих ---
    for (const job of [...this.jobs.values()]) {
      if (!this.valid(world, job, canHaul, ext)) {
        this.remove(job);
      }
    }
    // --- Рубка (деревья и кусты) ---
    for (let i = 0; i < desig.chop.length; i++) {
      if (desig.chop[i] && (world.obj[i] === Obj.Tree || world.obj[i] === Obj.BerryBush) && !this.hasJob('chop', i)) this.add('chop', i, i);
    }
    // --- Добыча (камень, железная руда, серебро и сплошная скала — вгрызаемся в горы) ---
    for (let i = 0; i < desig.mine.length; i++) {
      if (!desig.mine[i]) continue;
      const o = world.obj[i];
      const mineable = o === Obj.Rock || o === Obj.Ore || o === Obj.SilverOre || world.terrain[i] === 5 /* Terrain.Rock */;
      if (mineable && !this.hasJob('mine', i)) this.add('mine', i, i);
    }
    // --- Сбор ягод/урожая ---
    for (let i = 0; i < desig.harvest.length; i++) {
      if (!desig.harvest[i]) continue;
      const berry = world.obj[i] === Obj.BerryBush && world.berryRegrow[i] <= 0;
      const crop = world.zone[i] === Zone.Farm && world.farmStage[i] === FarmStage.Ready;
      if ((berry || crop) && !this.hasJob('harvest', i)) this.add('harvest', i, i);
    }
    // --- Ферма: вспахать / посадить ---
    for (let i = 0; i < world.zone.length; i++) {
      if (world.zone[i] !== Zone.Farm) continue;
      const st = world.farmStage[i] as FarmStage;
      if (st === FarmStage.None && !this.hasJob('till', i)) this.add('till', i, i);
      else if (st === FarmStage.Tilled && !this.hasJob('plant', i)) this.add('plant', i, i);
      else if (st === FarmStage.Ready && !this.hasJob('crop', i)) this.add('crop', i, i);
    }
    // --- Стройка ---
    for (const b of world.buildings) {
      if (!b.blueprint) continue;
      if (!this.hasJob('build', b.id)) this.add('build', world.idx(b.x, b.y), b.id, undefined, b.id);
    }
    // --- Переноска на склад (учитывает фильтры зон: ресурс несут только туда, где он разрешён) ---
    if (canHaul) {
      const HAULABLE: number[] = [Res.Wood, Res.Stone, Res.Food, Res.Meal, Res.Iron, Res.Hide, Res.Coat, Res.LeatherArmor, Res.IronArmor];
      for (const item of [...world.items]) {
        if (!HAULABLE.includes(item.type)) continue;
        const ti = world.idx(item.x, item.y);
        // уже на разрешённом складе — не трогаем; на запрещённом — унесём в другой
        const zd = world.zoneDefOf(ti);
        if (world.zone[ti] === Zone.Stockpile && zd && zd.filters[item.type]) continue;
        if (this.hasJob('haul', item.id)) continue;
        if (!world.stockpileHasSpaceFor(item.type)) continue;
        this.add('haul', ti, item.id, item.id);
      }
      // --- Находки ---
      if (world.stockpileHasSpaceFor(Res.Loot)) {
        for (const item of world.items) {
          if (item.type !== Res.Loot) continue;
          if (!this.hasJob('loot', item.id)) this.add('loot', world.idx(item.x, item.y), item.id, item.id);
        }
      }
    }
    // --- Готовка: костёр есть, цель по похлёбке задана (заказ игрока), порций меньше цели, сырой еды достаточно ---
    if (ext.food >= MIN_FOOD_TO_COOK) {
      for (const b of world.buildings) {
        if (b.type !== BType.Campfire || b.blueprint) continue;
        const target = b.mealTarget ?? 8;
        if (target <= 0 || ext.meals >= target) continue;
        if (this.hasJob('cook', b.id)) continue;
        // берём самую большую кучку сырой еды
        let food: Item | null = null;
        for (const it of world.items) {
          if (it.type !== Res.Food) continue;
          if (!food || it.qty > food.qty) food = it;
        }
        if (!food) break;
        this.add('cook', world.idx(b.x, b.y), b.id, food.id, b.id);
      }
    }
    // --- Крафт: верстак работает по заказам игрока (bills, RimWorld-стиль) ---
    // Заказы обрабатываются по порядку; берём первый невыполненный, на который
    // хватает материалов. Готовое засчитывается в bill при завершении работы.
    for (const b of world.buildings) {
      if (b.type !== BType.Workbench || b.blueprint || !b.bills) continue;
      if (this.hasJob('craft', b.id)) continue;
      for (const bill of b.bills) {
        if (bill.done >= bill.count) continue;
        const rec = RECIPES[bill.recipe];
        if (!rec) continue;
        if (world.countRes(craftMat(rec)) < craftNeed(rec)) continue; // материалов не хватает
        const job = this.add('craft', world.idx(b.x, b.y), b.id, undefined, b.id);
        job.recipe = bill.recipe;
        break;
      }
    }
    // --- Охота: помеченные игроком звери (дичь двигается — путь перестраивается на ходу) ---
    for (const prey of ext.hunt) {
      if (this.hasJob('hunt', prey.id)) continue;
      this.add('hunt', world.idx(Math.floor(prey.x), Math.floor(prey.y)), prey.id, prey.id);
    }
    void realNow;
    void MAP;
  }

  private valid(world: World, job: Job, canHaul: boolean, ext: JobExt): boolean {
    const i = job.tile;
    switch (job.kind) {
      case 'chop':
        return world.obj[i] === Obj.Tree || world.obj[i] === Obj.BerryBush;
      case 'mine': {
        const o = world.obj[i];
        return o === Obj.Rock || o === Obj.Ore || o === Obj.SilverOre || world.terrain[i] === 5 /* Terrain.Rock */;
      }
      case 'harvest':
        return (world.obj[i] === Obj.BerryBush && world.berryRegrow[i] <= 0) || (world.zone[i] === Zone.Farm && world.farmStage[i] === FarmStage.Ready);
      case 'till':
        return world.zone[i] === Zone.Farm && world.farmStage[i] === FarmStage.None;
      case 'plant':
        return world.zone[i] === Zone.Farm && world.farmStage[i] === FarmStage.Tilled;
      case 'crop':
        return world.zone[i] === Zone.Farm && world.farmStage[i] === FarmStage.Ready;
      case 'build': {
        const b = world.buildings.find((bb) => bb.id === job.buildingId);
        return !!b && b.blueprint;
      }
      case 'haul': {
        if (!canHaul) return false;
        const item = world.items.find((it) => it.id === job.itemId);
        if (!item) return false;
        const ti = world.idx(item.x, item.y);
        const zd = world.zoneDefOf(ti);
        // на разрешённом складе задача не нужна
        if (world.zone[ti] === Zone.Stockpile && zd && zd.filters[item.type]) return false;
        return world.stockpileHasSpaceFor(item.type);
      }
      case 'loot': {
        if (!canHaul) return false;
        return world.items.some((it) => it.id === job.itemId && it.type === Res.Loot);
      }
      case 'bury': {
        if (!canHaul) return false;
        return world.items.some((it) => it.id === job.itemId && it.type === Res.Corpse);
      }
      case 'cook': {
        // костёр жив, цель варки ещё не достигнута, взятая кучка еды на месте
        const fire = world.buildings.find((bb) => bb.id === job.buildingId);
        if (!fire || fire.blueprint || fire.type !== BType.Campfire) return false;
        if ((fire.mealTarget ?? 8) <= 0) return false;
        return world.items.some((it) => it.id === job.itemId && it.type === Res.Food);
      }
      case 'craft': {
        const wb = world.buildings.find((bb) => bb.id === job.buildingId);
        if (!wb || wb.blueprint || wb.type !== BType.Workbench) return false;
        if (job.recipe === undefined || RECIPES[job.recipe] === undefined) return false;
        // заказ должен быть жив: кто-то уже сделал всё нужное — снимаем
        const bill = wb.bills?.find((bl) => bl.recipe === job.recipe && bl.done < bl.count);
        return !!bill;
      }
      case 'hunt':
        // дичь жива и всё ещё помечена для охоты
        return ext.hunt.some((h) => h.id === job.itemId);
    }
  }

  release(job: Job, pawnId: number) {
    if (job.claimedBy === pawnId) job.claimedBy = null;
  }

  // Выбор задачи: utility-оценка по ВСЕЙ доске работ.
  // Приоритет игрока задаёт бонус категории; навык добавляет очки, усталость
  // увеличивает цену дальнего пути. Пешка берёт задачу с максимальной пользой,
  // а не первую попавшуюся в старшей категории.
  claim(
    world: World,
    pawn: { id: number; x: number; y: number; rest?: number; weapon?: string | null; priorities: WorkCat[]; skills?: Record<string, { lvl: number; xp: number }> },
    realNow: number,
    ext: JobExt,
  ): Job | null {
    const n = pawn.priorities.length;
    // усталая (или голодная до сонливости) пешка дорожит временем: дальний путь дороже
    const distW = pawn.rest !== undefined && pawn.rest < 30 ? 1.6 : 1;
    let best: Job | null = null;
    let bestScore = -Infinity;
    for (const job of this.jobs.values()) {
      // чужая задача — мимо; СВОЙ протухший клейм (баг старых версий, сон/бегство)
      // пешка перезабирает — иначе задача навсегда зависает «занятой»
      if (job.claimedBy !== null && job.claimedBy !== pawn.id) continue;
      if (this.wasFailed(pawn.id, job.id, realNow)) continue;
      // задача на воде недостижима (протухший тайл) — пропускаем, не блокируя остальные
      if (world.terrain[job.tile] === 2 /* Water */) continue;
      // охотник не берёт дичь, с которой ему не справиться (нет лука/оружия)
      if (job.kind === 'hunt') {
        const prey = ext.hunt.find((h) => h.id === job.itemId);
        if (!prey || !hunterCapable(pawn.weapon, prey.kind)) continue;
      }
      const prioIdx = pawn.priorities.indexOf(job.cat);
      if (prioIdx < 0) continue;
      const tx = job.tile % MAP;
      const ty = (job.tile / MAP) | 0;
      const d = Math.hypot(tx - pawn.x, ty - pawn.y);
      const lvl = pawn.skills ? (pawn.skills[SKILL_OF[job.kind]]?.lvl ?? 0) : 0;
      // utility = бонус приоритета (шаг категории ~ 2.5 клетки пути) + навык*2 − дистанция
      const tiebreak = ((pawn.id * 7 + job.id * 13) % 97) * 0.01; // стабильный разброс при равенстве
      let score = (n - prioIdx) * 2.5 + lvl * 2 - d * distW + tiebreak;
      // дичь помечена игроком — дело не терпит: capable охотник идёт на охоту раньше переноски
      if (job.kind === 'hunt') score += 3;
      if (score > bestScore) {
        bestScore = score;
        best = job;
      }
    }
    if (best) {
      // Проверка достижимости (грубая): цель должна быть на суше
      const ti = best.tile;
      if (world.terrain[ti] === 2 /* Water */) return null;
      best.claimedBy = pawn.id;
      return best;
    }
    return null;
  }
}

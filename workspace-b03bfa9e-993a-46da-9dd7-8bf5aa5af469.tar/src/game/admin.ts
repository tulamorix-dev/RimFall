// ============================================================
// ОСКОЛОК — админ-панель: прямой доступ к состоянию игры.
// Песочница для тестов и баланса: пешки, звери, мир, рецепты.
// Не влияет на симуляцию: только правит состояние и пишет в журнал.
// ============================================================

import {
  BType, BUILDINGS, EXTRA_NAMES, MAP, Obj, RECIPES, Res, SEASON_DAYS, Terrain, TRAITS,
  type RecipeDef, type WeaponKind, type ArmorKind, type SkillId,
} from './data/defs';
import type { Game } from './core/game';
import { Pawn } from './entities/pawn';
import type { AnimalKind } from './entities/animal';
import { freeSpotNear } from './ai/pawnAI';
import { completeBuilding, createBlueprint } from './buildings/buildings';

export type TerraformKind = 'forest' | 'berries' | 'vein' | 'rock' | 'water' | 'clear';

export interface RecipePatch {
  name?: string;
  res?: Res;
  work?: number;
  wood?: number;
  iron?: number;
  hide?: number;
}

export class AdminAPI {
  constructor(private g: Game) {}

  private log(text: string) {
    this.g.events.log(text, 'info');
  }

  private baseSpot(): { x: number; y: number } {
    const c = this.g.world.stockpileCenter() ?? this.g.centerBase();
    return { x: Math.floor(c.x), y: Math.floor(c.y) };
  }

  // ============ КОЛОНИЯ: ресурсы, время, погода, события ============

  // Задать точное количество ресурса в мире (склад + земля)
  setRes(res: Res, qty: number) {
    const g = this.g;
    const target = Math.max(0, Math.floor(qty));
    const cur = g.world.countRes(res);
    if (target === cur) return;
    if (target > cur) {
      const c = this.baseSpot();
      const spot = freeSpotNear(g.world, c.x, c.y);
      g.world.addItem(res, target - cur, spot.x, spot.y);
      g.renderDirtyTile(spot.x, spot.y);
    } else {
      g['takeRes'](res, cur - target);
    }
    this.log(`Админ: ${RES_NAME[res]} → ${target}.`);
  }

  // Время: задать день и время суток
  setTime(day: number, h: number, m: number) {
    const d = Math.max(1, Math.floor(day));
    const hh = Math.min(23, Math.max(0, Math.floor(h)));
    const mm = Math.min(59, Math.max(0, Math.floor(m)));
    this.g.clock.totalMin = (d - 1) * 1440 + hh * 60 + mm;
    this.log(`Админ: время → День ${d}, ${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}.`);
  }

  addTime(min: number) {
    this.g.clock.totalMin = Math.max(0, this.g.clock.totalMin + min);
  }

  // Сезон: перейти к первому дню сезона (0 лето … 3 весна)
  setSeason(idx: 0 | 1 | 2 | 3) {
    const tod = this.g.clock.totalMin % 1440;
    this.g.clock.totalMin = idx * SEASON_DAYS * 1440 + tod;
    this.log(`Админ: сезон → ${['Лето', 'Осень', 'Зима', 'Весна'][idx]}.`);
  }

  setWeather(rain: boolean, blizzard: boolean) {
    const w = this.g.weather;
    const now = this.g.clock.totalMin;
    w.rain = rain;
    w.rainUntil = rain ? now + 720 : 0;
    w.blizzard = blizzard;
    w.blizzardUntil = blizzard ? now + 480 : 0;
    this.log(`Админ: погода → ${blizzard ? 'буран' : rain ? 'дождь' : 'ясно'}.`);
  }

  // Событие: караван прямо сейчас
  forceCaravan(): boolean {
    if (this.g.animals.some((a) => a.kind === 'trader' && !a.dead)) {
      this.log('Админ: торговец уже в лагере.');
      return false;
    }
    this.g.spawnCaravan();
    return true;
  }

  // Событие: стая волков идёт на лагерь
  callWolves(n: number) {
    const g = this.g;
    let spawned = 0;
    for (let i = 0; i < n; i++) {
      for (let tries = 0; tries < 60; tries++) {
        const c = this.baseSpot();
        const ang = g.rng.next() * Math.PI * 2;
        const r = g.rng.int(9, 15);
        const x = Math.round(c.x + Math.cos(ang) * r);
        const y = Math.round(c.y + Math.sin(ang) * r);
        if (x < 1 || y < 1 || x >= MAP - 1 || y >= MAP - 1) continue;
        if (!g.world.passAnimal(x, y)) continue;
        if (!g.animalReachable(x, y)) continue;
        const a = g.spawnAnimal('wolf', x + 0.5, y + 0.5);
        a.siege = true;
        a.state = 'siege';
        spawned++;
        break;
      }
    }
    if (spawned > 0) {
      g.raiseAlarm(180);
      this.log(`Админ: стая из ${spawned} волков идёт на лагерь!`);
    } else {
      this.log('Админ: не нашлось места для волков.');
    }
  }

  // Событие: странник просит приюта (новый колонист сразу)
  addWanderer(): boolean {
    const g = this.g;
    const used = new Set(g.pawns.map((p) => p.name));
    const free = EXTRA_NAMES.filter((e) => !used.has(e.name));
    const pick = free.length > 0 ? free[g.rng.int(0, free.length - 1)] : { name: `Гость ${g.nextPawnId}`, gender: 'м' as const };
    const p = g.addColonyMember(pick.name, pick.gender);
    if (!p) {
      this.log('Админ: предел колонии достигнут (6).');
      return false;
    }
    return true;
  }

  // Событие: болезнь у случайной пешки
  makeSick() {
    const p = this.g.randomAlivePawn();
    if (!p) return;
    p.sickMin = 1200;
    this.log(`Админ: ${p.name} слёг(ла) с лихорадкой.`);
  }

  healAll() {
    for (const p of this.g.pawns) {
      if (p.dead) continue;
      p.hp = 100;
      p.sickMin = 0;
      p.noRegen = false;
      p.removeMod('cold');
    }
    this.log('Админ: все колонисты здоровы.');
  }

  feedAll() {
    for (const p of this.g.pawns) {
      if (p.dead) continue;
      p.food = 100;
      p.rest = Math.max(p.rest, 60);
    }
    this.log('Админ: все сыты и бодры.');
  }

  resetGameOver() {
    this.g.gameOver = false;
    this.log('Админ: колония снова жива (Game Over сброшен).');
  }

  resetAlarm() {
    this.g.alarmMin = 0;
  }

  killAllWolves(): number {
    const wolves = this.g.animals.filter((a) => a.kind === 'wolf');
    for (const w of wolves) this.g.damageAnimal(w, 99999);
    if (wolves.length > 0) this.log(`Админ: волки убиты (${wolves.length}).`);
    return wolves.length;
  }

  writeLog(text: string) {
    if (text.trim()) this.g.events.log(text.trim(), 'story');
  }

  // ============ ПЕШКИ ============

  // Новая пешка у склада (случайные черты и навыки)
  addPawn(): Pawn | null {
    const g = this.g;
    const alive = g.pawns.filter((p) => !p.dead);
    if (alive.length >= 12) {
      this.log('Админ: слишком много пешек (12).');
      return null;
    }
    const c = this.baseSpot();
    const spot = freeSpotNear(g.world, c.x, c.y);
    const id = g.nextPawnId++;
    const used = new Set(g.pawns.map((p) => p.name));
    const free = EXTRA_NAMES.filter((e) => !used.has(e.name));
    const name = free.length > 0 ? free[g.rng.int(0, free.length - 1)].name : `Пешка ${id}`;
    const gender: 'м' | 'ж' = g.rng.chance(0.5) ? 'м' : 'ж';
    const traits = [TRAITS[g.rng.int(0, TRAITS.length - 1)].id];
    const p = new Pawn(id, name, spot.x + 0.5, spot.y + 0.5, id - 1, traits, gender, g.rng.int(19, 45));
    for (const s of Object.keys(p.skills) as SkillId[]) p.skills[s] = { lvl: g.rng.int(0, 5), xp: 0 };
    g.pawns.push(p);
    g.renderDirtyTile(spot.x, spot.y);
    this.log(`Админ: ${p.name} появился(лась) у склада.`);
    return p;
  }

  pawnById(id: number): Pawn | null {
    return this.g.pawns.find((p) => p.id === id) ?? null;
  }

  // Убить пешку (через штатный damagePawn: выпадает снаряжение, появляется тело)
  killPawn(id: number) {
    const p = this.pawnById(id);
    if (!p || p.dead) return;
    this.g.damagePawn(p, 9999);
  }

  // Убрать погибшую пешку из списка совсем
  purgePawn(id: number) {
    const p = this.pawnById(id);
    if (!p || !p.dead) return;
    const k = this.g.pawns.indexOf(p);
    if (k >= 0) this.g.pawns.splice(k, 1);
  }

  // Оживить погибшую пешку (тело рядом убирается)
  revivePawn(id: number): boolean {
    const p = this.pawnById(id);
    if (!p) return false;
    if (!p.dead) return false;
    const g = this.g;
    p.dead = false;
    p.hp = 60;
    p.food = Math.max(p.food, 50);
    p.rest = Math.max(p.rest, 50);
    p.state = 'idle';
    p.job = null;
    p.path = null;
    p.sickMin = 0;
    p.breakMin = 0;
    p.breakKind = null;
    p.underground = false;
    // убрать труп рядом (если ещё не похоронен)
    const tx = Math.floor(p.x);
    const ty = Math.floor(p.y);
    const corpse = g.world.items.find(
      (it) => it.type === Res.Corpse && Math.abs(Math.floor(it.x) - tx) <= 2 && Math.abs(Math.floor(it.y) - ty) <= 2,
    );
    if (corpse) g.world.removeItem(corpse);
    g.renderDirtyTile(tx, ty);
    this.log(`Админ: ${p.name} вернулся(лась) к жизни!`);
    return true;
  }

  setPawnName(id: number, name: string) {
    const p = this.pawnById(id);
    if (!p) return;
    p.name = name.slice(0, 16) || p.name;
  }

  setPawnAge(id: number, age: number) {
    const p = this.pawnById(id);
    if (!p) return;
    p.age = Math.min(90, Math.max(14, Math.floor(age)));
  }

  setPawnGender(id: number, gender: 'м' | 'ж') {
    const p = this.pawnById(id);
    if (!p) return;
    p.gender = gender;
  }

  setPawnTraits(id: number, traits: string[]) {
    const p = this.pawnById(id);
    if (!p) return;
    p.traits = [...traits];
  }

  setNeed(id: number, key: 'hp' | 'food' | 'rest', v: number) {
    const p = this.pawnById(id);
    if (!p) return;
    p[key] = Math.min(100, Math.max(0, v));
  }

  setSkill(id: number, skill: SkillId, lvl: number) {
    const p = this.pawnById(id);
    if (!p) return;
    p.skills[skill] = { lvl: Math.min(20, Math.max(0, Math.floor(lvl))), xp: 0 };
  }

  setWeapon(id: number, w: WeaponKind | 'none') {
    const p = this.pawnById(id);
    if (!p) return;
    p.weapon = w === 'none' ? null : w;
  }

  setCloth(id: number, v: 'coat' | 'none') {
    const p = this.pawnById(id);
    if (!p) return;
    p.cloth = v === 'coat' ? 'coat' : null;
  }

  setArmor(id: number, v: ArmorKind | 'none') {
    const p = this.pawnById(id);
    if (!p) return;
    p.armor = v === 'none' ? null : v;
  }

  // Действия над пешкой
  pawnAction(id: number, act: 'heal' | 'wake' | 'base' | 'clearJob') {
    const g = this.g;
    const p = this.pawnById(id);
    if (!p || p.dead) return;
    if (p.underground) {
      this.log('Админ: пешка в шахте — дождитесь возвращения.');
      return;
    }
    switch (act) {
      case 'heal':
        p.hp = 100;
        p.sickMin = 0;
        p.noRegen = false;
        break;
      case 'wake':
        if (p.state === 'sleep') {
          p.state = 'idle';
          p.job = null;
          p.path = null;
        }
        break;
      case 'base': {
        const c = this.baseSpot();
        const spot = freeSpotNear(g.world, c.x, c.y);
        p.x = spot.x + 0.5;
        p.y = spot.y + 0.5;
        p.path = null;
        p.state = 'idle';
        p.job = null;
        g.renderDirtyTile(spot.x, spot.y);
        break;
      }
      case 'clearJob':
        p.state = 'idle';
        p.job = null;
        p.path = null;
        p.combatTargetId = null;
        p.resumeRef = undefined;
        break;
    }
  }

  // ============ ЗВЕРИ ============

  // Спавн зверя у лагеря (достижимое место)
  spawnAnimal(kind: AnimalKind): boolean {
    const g = this.g;
    const c = this.baseSpot();
    for (let tries = 0; tries < 120; tries++) {
      const ang = g.rng.next() * Math.PI * 2;
      const r = g.rng.int(4, 14);
      const x = Math.round(c.x + Math.cos(ang) * r);
      const y = Math.round(c.y + Math.sin(ang) * r);
      if (x < 1 || y < 1 || x >= MAP - 1 || y >= MAP - 1) continue;
      if (!g.world.passAnimal(x, y)) continue;
      if (!g.animalReachable(x, y)) continue;
      const a = g.spawnAnimal(kind, x + 0.5, y + 0.5);
      this.log(`Админ: ${a.name} появился(лась) у лагеря.`);
      return true;
    }
    this.log('Админ: не нашлось места для зверя.');
    return false;
  }

  killAnimal(id: number) {
    const a = this.g.animals.find((aa) => aa.id === id);
    if (!a) return;
    this.g.damageAnimal(a, 99999);
  }

  despawnAnimal(id: number) {
    const a = this.g.animals.find((aa) => aa.id === id);
    if (!a) return;
    this.g.removeAnimal(a);
  }

  clearHuntMarks() {
    this.g.huntList.clear();
  }

  // ============ МИР: терраформ, здания, приказы ============

  private canEditTile(x: number, y: number): boolean {
    const g = this.g;
    const w = g.world;
    if (!w.inBounds(x, y)) return false;
    const i = w.idx(x, y);
    if (w.buildingMap.has(i)) return false;
    if (w.zone[i] !== 0) return false;
    for (const p of g.pawns) {
      if (p.dead || p.underground) continue;
      if (Math.floor(p.x) === x && Math.floor(p.y) === y) return false;
    }
    return true;
  }

  // Терраформ вокруг лагеря (радиус r): лес, ягоды, рудная жила, скалы, озеро, расчистка
  terraform(kind: TerraformKind, r: number): number {
    const g = this.g;
    const w = g.world;
    const c = this.baseSpot();
    let n = 0;
    for (let dy = -r; dy <= r; dy++) {
      for (let dx = -r; dx <= r; dx++) {
        if (Math.hypot(dx, dy) > r) continue;
        const x = c.x + dx;
        const y = c.y + dy;
        if (!this.canEditTile(x, y)) continue;
        const i = w.idx(x, y);
        const t = w.terrain[i];
        switch (kind) {
          case 'forest':
            if ((t === Terrain.Grass || t === Terrain.Dirt || t === Terrain.Forest) && w.obj[i] === Obj.None) {
              w.obj[i] = Obj.Tree;
              n++;
            }
            break;
          case 'berries':
            if ((t === Terrain.Grass || t === Terrain.Forest) && w.obj[i] === Obj.None) {
              w.obj[i] = Obj.BerryBush;
              n++;
            }
            break;
          case 'vein':
            if (t !== Terrain.Water && t !== Terrain.Rock && w.obj[i] === Obj.None) {
              w.obj[i] = g.rng.chance(0.15) ? Obj.SilverOre : Obj.Ore;
              n++;
            }
            break;
          case 'rock':
            if (t !== Terrain.Water && t !== Terrain.Rock) {
              w.terrain[i] = Terrain.Rock;
              w.obj[i] = Obj.None;
              n++;
            }
            break;
          case 'water':
            if (t !== Terrain.Water && t !== Terrain.Rock) {
              w.terrain[i] = Terrain.Water;
              w.obj[i] = Obj.None;
              n++;
            }
            break;
          case 'clear':
            if (w.obj[i] !== Obj.None) {
              w.obj[i] = Obj.None;
              n++;
            }
            break;
        }
      }
    }
    // метки приказов на изменённых клетках сбросим — доска сама пересоберётся
    for (let dy = -r; dy <= r; dy++) {
      for (let dx = -r; dx <= r; dx++) {
        const x = c.x + dx;
        const y = c.y + dy;
        if (!w.inBounds(x, y)) continue;
        g.renderDirtyTile(x, y);
      }
    }
    const names: Record<TerraformKind, string> = {
      forest: 'Лес посажен', berries: 'Ягодные кусты посажены', vein: 'Рудная жила вскрыта',
      rock: 'Скалы воздвигнуты', water: 'Озеро разлито', clear: 'Местность расчищена',
    };
    this.log(`Админ: ${names[kind].toLowerCase()} (${n} клеток).`);
    return n;
  }

  // Все чертежи достроить мгновенно
  completeAllBlueprints(): number {
    let n = 0;
    for (const b of this.g.world.buildings) {
      if (!b.blueprint) continue;
      b.matHave = b.matNeed;
      completeBuilding(b);
      this.g.renderDirtyTile(b.x, b.y);
      n++;
    }
    if (n > 0) this.log(`Админ: достроено построек — ${n}.`);
    return n;
  }

  repairAll(): number {
    let n = 0;
    for (const b of this.g.world.buildings) {
      if (b.blueprint || b.hp >= b.maxHp) continue;
      b.hp = b.maxHp;
      this.g.renderDirtyTile(b.x, b.y);
      n++;
    }
    if (n > 0) this.log(`Админ: отремонтировано — ${n}.`);
    return n;
  }

  // Снести все чертежи (вернуть материалы нельзя)
  destroyBlueprints(): number {
    const g = this.g;
    const bp = g.world.buildings.filter((b) => b.blueprint);
    for (const b of bp) {
      g.jobs.removeByRef('build', b.id);
      g.world.removeBuilding(b);
      g.renderDirtyTile(b.x, b.y);
    }
    if (bp.length > 0) this.log(`Админ: чертежей снесено — ${bp.length}.`);
    return bp.length;
  }

  // Готовая постройка рядом со складом
  grantBuilding(type: BType): boolean {
    const g = this.g;
    const c = this.baseSpot();
    for (let tries = 0; tries < 200; tries++) {
      const ang = g.rng.next() * Math.PI * 2;
      const r = g.rng.int(2, 9);
      const x = Math.round(c.x + Math.cos(ang) * r);
      const y = Math.round(c.y + Math.sin(ang) * r);
      if (!g.world.inBounds(x, y)) continue;
      if (!g.world.passPawn(x, y) || g.world.terrain[g.world.idx(x, y)] === Terrain.Water) continue;
      if (g.world.buildingAt(x, y)) continue;
      const b = createBlueprint(type, x, y);
      g.world.placeBuilding(b);
      completeBuilding(b);
      g.renderDirtyTile(x, y);
      this.log(`Админ: построено — ${BUILDINGS[type].name}.`);
      return true;
    }
    this.log('Админ: нет места для постройки.');
    return false;
  }

  // Очистить все метки приказов (рубка/копать/собрать)
  clearDesig(): number {
    const d = this.g.desig;
    let n = 0;
    for (let i = 0; i < d.chop.length; i++) {
      if (d.chop[i]) { d.chop[i] = 0; n++; }
      if (d.mine[i]) { d.mine[i] = 0; n++; }
      if (d.harvest[i]) { d.harvest[i] = 0; n++; }
    }
    this.log(`Админ: метки приказов сняты (${n}).`);
    return n;
  }

  // ============ РЕЦЕПТЫ ============

  recipes(): RecipeDef[] {
    return RECIPES;
  }

  // Правка рецепта на месте (индексы заказов не меняются)
  updateRecipe(idx: number, patch: RecipePatch) {
    const rec = RECIPES[idx];
    if (!rec) return;
    if (patch.name !== undefined) rec.name = patch.name.slice(0, 24) || rec.name;
    if (patch.res !== undefined) rec.res = patch.res;
    if (patch.work !== undefined) rec.work = Math.min(999, Math.max(1, Math.floor(patch.work)));
    if (patch.wood !== undefined) rec.wood = Math.min(30, Math.max(0, Math.floor(patch.wood)));
    if (patch.iron !== undefined) rec.iron = Math.min(30, Math.max(0, Math.floor(patch.iron)));
    if (patch.hide !== undefined) rec.hide = Math.min(30, Math.max(0, Math.floor(patch.hide)));
    this.log(`Админ: рецепт «${rec.name}» обновлён.`);
  }

  // Новый рецепт (добавляется в конец каталога)
  addRecipe(def: RecipePatch): number {
    const name = (def.name ?? '').trim() || 'Новое изделие';
    const rec: RecipeDef = {
      id: RECIPES.length > 0 ? Math.max(...RECIPES.map((r) => r.id)) + 1 : 0,
      res: def.res ?? Res.Spear,
      name,
      work: Math.min(999, Math.max(1, Math.floor(def.work ?? 40))),
      wood: Math.min(30, Math.max(0, Math.floor(def.wood ?? 0))),
      iron: Math.min(30, Math.max(0, Math.floor(def.iron ?? 0))),
      hide: Math.min(30, Math.max(0, Math.floor(def.hide ?? 0))),
    };
    RECIPES.push(rec);
    this.log(`Админ: новый рецепт «${rec.name}» на верстаке.`);
    return RECIPES.length - 1;
  }

  // Удалить рецепт: заказы на верстаках и задачи крафта переиндексируются
  deleteRecipe(idx: number): boolean {
    if (idx < 0 || idx >= RECIPES.length) return false;
    const name = RECIPES[idx].name;
    RECIPES.splice(idx, 1);
    const g = this.g;
    // 1) заказы на верстаках
    for (const b of g.world.buildings) {
      if (!b.bills) continue;
      const before = b.bills.length;
      b.bills = b.bills
        .filter((bl) => bl.recipe !== idx)
        .map((bl) => (bl.recipe > idx ? { ...bl, recipe: bl.recipe - 1 } : bl));
      if (b.bills.length !== before) this.log(`Админ: заказы верстака обновлены (${before - b.bills.length} удалено).`);
    }
    // 2) задачи крафта на доске
    for (const job of [...g.jobs.jobs.values()]) {
      if (job.kind !== 'craft') continue;
      if (job.recipe === undefined) continue;
      if (job.recipe === idx) g.jobs.remove(job);
      else if (job.recipe > idx) job.recipe--;
    }
    // 3) активные задания пешек с этим рецептом
    for (const p of g.pawns) {
      if (p.dead || !p.job || p.job.kind !== 'craft') continue;
      if (p.job.recipe === idx) {
        p.job = null;
        p.state = 'idle';
        p.resumeRef = undefined;
      } else if (p.job.recipe !== undefined && p.job.recipe > idx) {
        p.job.recipe--;
      }
    }
    this.log(`Админ: рецепт «${name}» удалён.`);
    return true;
  }
}

const RES_NAME: Record<number, string> = {
  [Res.Wood]: 'Дерево', [Res.Stone]: 'Камень', [Res.Food]: 'Еда', [Res.Meal]: 'Похлёбка',
  [Res.Iron]: 'Железо', [Res.Silver]: 'Серебро',
};

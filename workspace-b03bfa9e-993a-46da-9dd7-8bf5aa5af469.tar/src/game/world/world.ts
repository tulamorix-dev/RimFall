// Мир: сетка клеток 64x64, проходимость, предметы, постройки, зоны

import { MAP, Obj, Res, Terrain, Zone, FarmStage, BType, BUILDINGS, RES_INFO, STOCKPILE_RES, ZONE_KIND_NAMES, MAX_ZONE_ID, FILTER_LEN, type ZoneDef, type ZoneKind } from '../data/defs';
import type { Building } from '../buildings/buildings';

export interface Item {
  id: number;
  type: Res;
  qty: number;
  x: number; // клетка
  y: number;
  decay?: number; // для трупов (минут до исчезновения)
  name?: string; // имя погибшего (для погребения и истории)
}

export class World {
  terrain = new Uint8Array(MAP * MAP);
  obj = new Uint8Array(MAP * MAP);
  objHp = new Float32Array(MAP * MAP);
  zone = new Uint8Array(MAP * MAP);
  zoneId = new Uint8Array(MAP * MAP); // номер зоны с настройками (0 — нет)
  farmStage = new Uint8Array(MAP * MAP);
  farmGrowth = new Float32Array(MAP * MAP);
  berryRegrow = new Float32Array(MAP * MAP); // таймер отрастания ягод
  explored = new Uint8Array(MAP * MAP);
  visible = new Uint8Array(MAP * MAP);

  // Реестр зон с настройками (RimWorld-стиль)
  zoneDefs = new Map<number, ZoneDef>();
  nextZoneId = 1;
  private zoneCounters: Record<ZoneKind, number> = { stockpile: 0, farm: 0 };

  items: Item[] = [];
  itemMap = new Map<number, Item[]>(); // tileIdx -> items
  buildings: Building[] = [];
  buildingMap = new Map<number, Building>(); // tileIdx -> building

  nextItemId = 1;

  idx(x: number, y: number): number {
    return y * MAP + x;
  }
  inBounds(x: number, y: number): boolean {
    return x >= 0 && y >= 0 && x < MAP && y < MAP;
  }

  // --- Проходимость ---
  blockedTerrain(i: number): boolean {
    const t = this.terrain[i];
    return t === Terrain.Water || t === Terrain.Rock; // сплошная скала непроходима — только копать
  }
  blockedObj(i: number): boolean {
    const o = this.obj[i];
    return o === Obj.Tree || o === Obj.Rock || o === Obj.RuinWall || o === Obj.Ore || o === Obj.SilverOre;
  }
  passPawn(x: number, y: number): boolean {
    if (!this.inBounds(x, y)) return false;
    const i = this.idx(x, y);
    if (this.blockedTerrain(i) || this.blockedObj(i)) return false;
    const b = this.buildingMap.get(i);
    if (b && !BUILDINGS[b.type].passPawn) return false;
    return true;
  }
  passAnimal(x: number, y: number): boolean {
    if (!this.inBounds(x, y)) return false;
    const i = this.idx(x, y);
    if (this.blockedTerrain(i) || this.blockedObj(i)) return false;
    const b = this.buildingMap.get(i);
    if (b && !BUILDINGS[b.type].passAnimal) return false;
    return true;
  }

  // --- Предметы ---
  itemsAt(x: number, y: number): Item[] {
    return this.itemMap.get(this.idx(x, y)) ?? [];
  }
  addItem(type: Res, qty: number, x: number, y: number): Item {
    const i = this.idx(x, y);
    const list = this.itemMap.get(i);
    const info = RES_INFO[type];
    if (list && info.stack > 1) {
      for (const it of list) {
        if (it.type === type && it.qty < info.stack) {
          const take = Math.min(qty, info.stack - it.qty);
          it.qty += take;
          qty -= take;
          if (qty <= 0) return it;
        }
      }
    }
    const item: Item = { id: this.nextItemId++, type, qty, x, y };
    this.items.push(item);
    if (!this.itemMap.has(i)) this.itemMap.set(i, []);
    this.itemMap.get(i)!.push(item);
    return item;
  }
  removeItem(item: Item) {
    const i = this.idx(item.x, item.y);
    const list = this.itemMap.get(i);
    if (list) {
      const k = list.indexOf(item);
      if (k >= 0) list.splice(k, 1);
      if (list.length === 0) this.itemMap.delete(i);
    }
    const k = this.items.indexOf(item);
    if (k >= 0) this.items.splice(k, 1);
  }
  // Общий запас ресурса в мире (склад + земля + у пешек считается отдельно)
  countRes(type: Res): number {
    let n = 0;
    for (const it of this.items) if (it.type === type) n += it.qty;
    return n;
  }

  // --- Постройки ---
  placeBuilding(b: Building) {
    this.buildings.push(b);
    this.buildingMap.set(this.idx(b.x, b.y), b);
  }
  removeBuilding(b: Building) {
    this.buildingMap.delete(this.idx(b.x, b.y));
    const k = this.buildings.indexOf(b);
    if (k >= 0) this.buildings.splice(k, 1);
  }
  buildingAt(x: number, y: number): Building | undefined {
    return this.buildingMap.get(this.idx(x, y));
  }

  // --- Зоны ---
  zoneAt(x: number, y: number): Zone {
    return this.zone[this.idx(x, y)] as Zone;
  }

  // Сброс реестра зон (при генерации нового мира)
  resetZones() {
    this.zoneId.fill(0);
    this.zoneDefs.clear();
    this.nextZoneId = 1;
    this.zoneCounters = { stockpile: 0, farm: 0 };
  }

  // Новая зона с настройками: имя по счётчику («Склад 2»), фильтры — все разрешены
  createZone(kind: ZoneKind, name?: string): ZoneDef | null {
    let id = this.nextZoneId;
    if (id > MAX_ZONE_ID) {
      id = 0;
      for (let t = 1; t <= MAX_ZONE_ID; t++) {
        if (!this.zoneDefs.has(t)) {
          id = t;
          break;
        }
      }
      if (id === 0) return null; // предел зон — создаём только расширения
    } else {
      this.nextZoneId = id + 1;
    }
    this.zoneCounters[kind]++;
    const n = this.zoneCounters[kind];
    const filters = new Array(FILTER_LEN).fill(false);
    if (kind === 'stockpile') for (const r of STOCKPILE_RES) filters[r] = true;
    const zd: ZoneDef = { id, kind, name: name ?? `${ZONE_KIND_NAMES[kind]}${n > 1 ? ` ${n}` : ''}`, filters };
    this.zoneDefs.set(id, zd);
    return zd;
  }

  zoneDefOf(i: number): ZoneDef | null {
    return this.zoneDefs.get(this.zoneId[i]) ?? null;
  }

  // Если на зону не осталось ни одной клетки — убираем её из реестра
  deleteZoneIfEmpty(id: number) {
    if (!id || !this.zoneDefs.has(id)) return;
    for (let i = 0; i < this.zoneId.length; i++) {
      if (this.zoneId[i] === id) return;
    }
    this.zoneDefs.delete(id);
  }

  // Подписи зон: центр каждой зоны для рендера (лёгкий проход по карте)
  zoneCenters(): { id: number; x: number; y: number; name: string; kind: ZoneKind }[] {
    const acc = new Map<number, { sx: number; sy: number; n: number }>();
    for (let i = 0; i < this.zoneId.length; i++) {
      const id = this.zoneId[i];
      if (!id) continue;
      let a = acc.get(id);
      if (!a) {
        a = { sx: 0, sy: 0, n: 0 };
        acc.set(id, a);
      }
      a.sx += i % MAP;
      a.sy += (i / MAP) | 0;
      a.n++;
    }
    const out: { id: number; x: number; y: number; name: string; kind: ZoneKind }[] = [];
    for (const [id, a] of acc) {
      const zd = this.zoneDefs.get(id);
      if (!zd) continue;
      out.push({ id, x: a.sx / a.n + 0.5, y: a.sy / a.n + 0.5, name: zd.name, kind: zd.kind });
    }
    return out;
  }

  // Найти свободную клетку склада для ресурса (та же стопка или пустая).
  // Учитывает фильтры зон: носильщики несут только туда, где ресурс разрешён.
  findStockpileTile(type: Res, fromX: number, fromY: number): { x: number; y: number } | null {
    let best: { x: number; y: number } | null = null;
    let bestD = Infinity;
    const info = RES_INFO[type];
    for (let y = 0; y < MAP; y++) {
      for (let x = 0; x < MAP; x++) {
        const i = this.idx(x, y);
        if (this.zone[i] !== Zone.Stockpile) continue;
        const zd = this.zoneDefs.get(this.zoneId[i]);
        if (!zd || !zd.filters[type]) continue; // зона не принимает этот ресурс
        if (this.blockedTerrain(i) || this.blockedObj(i)) continue;
        if (this.buildingMap.has(i)) continue;
        const list = this.itemMap.get(i);
        let occupied = false;
        if (list && list.length > 0) {
          // одна стопка на клетку: только тот же тип с местом
          const top = list[0];
          if (top.type !== type || top.qty >= info.stack) occupied = true;
        }
        if (occupied) continue;
        const d = (x - fromX) * (x - fromX) + (y - fromY) * (y - fromY);
        if (d < bestD) {
          bestD = d;
          best = { x, y };
        }
      }
    }
    return best;
  }

  // Есть ли место на складах вообще
  stockpileHasSpace(): boolean {
    for (let i = 0; i < this.zone.length; i++) {
      if (this.zone[i] !== Zone.Stockpile) continue;
      const list = this.itemMap.get(i);
      if (!list || list.length === 0) return true;
    }
    return false;
  }

  // Есть ли на складах место именно под этот ресурс (с учётом фильтров зон)
  stockpileHasSpaceFor(type: Res): boolean {
    const info = RES_INFO[type];
    for (let i = 0; i < this.zone.length; i++) {
      if (this.zone[i] !== Zone.Stockpile) continue;
      const zd = this.zoneDefs.get(this.zoneId[i]);
      if (!zd || !zd.filters[type]) continue;
      const list = this.itemMap.get(i);
      if (!list || list.length === 0) return true;
      const top = list[0];
      if (top.type === type && top.qty < info.stack) return true;
    }
    return false;
  }

  // Центр зоны склада (для "к базе")
  stockpileCenter(): { x: number; y: number } | null {
    let sx = 0;
    let sy = 0;
    let n = 0;
    for (let i = 0; i < this.zone.length; i++) {
      if (this.zone[i] !== Zone.Stockpile) continue;
      sx += i % MAP;
      sy += Math.floor(i / MAP);
      n++;
    }
    return n > 0 ? { x: sx / n, y: sy / n } : null;
  }

  // Обозначенный (помеченный игроком) объект можно трогать
  farmTiles(): number[] {
    const out: number[] = [];
    for (let i = 0; i < this.zone.length; i++) if (this.zone[i] === Zone.Farm) out.push(i);
    return out;
  }

  // Свет ночью от костров
  campfires(): { x: number; y: number }[] {
    return this.buildings.filter((b) => !b.blueprint && b.type === BType.Campfire).map((b) => ({ x: b.x, y: b.y }));
  }

  // Все источники света для затемнения ночью (костры и факелы)
  litBuildings(): { x: number; y: number; type: BType }[] {
    return this.buildings
      .filter((b) => !b.blueprint && (b.type === BType.Campfire || b.type === BType.Torch))
      .map((b) => ({ x: b.x, y: b.y, type: b.type }));
  }

  // --- Туман войны ---
  updateVisibility(pawns: { x: number; y: number }[]) {
    this.visible.fill(0);
    for (const p of pawns) {
      const cx = Math.round(p.x);
      const cy = Math.round(p.y);
      const r = 7.5;
      for (let dy = -8; dy <= 8; dy++) {
        for (let dx = -8; dx <= 8; dx++) {
          const x = cx + dx;
          const y = cy + dy;
          if (!this.inBounds(x, y)) continue;
          if (dx * dx + dy * dy <= r * r) {
            const i = this.idx(x, y);
            this.visible[i] = 1;
            this.explored[i] = 1;
          }
        }
      }
    }
  }

  // Стоимость поверхности для пути (позднее: дороги/болото)
  moveCost(i: number): number {
    const t = this.terrain[i] as Terrain;
    if (t === Terrain.Forest) return 1.25;
    if (t === Terrain.Stone) return 1.1;
    return 1;
  }

  // Сплошная скала (копается в туннель) или валун/жила на клетке
  isMineable(x: number, y: number): boolean {
    const i = this.idx(x, y);
    if (!this.inBounds(x, y)) return false;
    const o = this.obj[i];
    if (o === Obj.Rock || o === Obj.Ore || o === Obj.SilverOre) return true;
    return this.terrain[i] === Terrain.Rock;
  }

  // Название клетки для инспектора
  tileName(x: number, y: number): string {
    const i = this.idx(x, y);
    const t = this.terrain[i] as Terrain;
    const names: Record<Terrain, string> = {
      [Terrain.Grass]: 'Трава',
      [Terrain.Dirt]: 'Земля',
      [Terrain.Water]: 'Вода',
      [Terrain.Stone]: 'Каменистая осыпь (край скал)',
      [Terrain.Forest]: 'Лесная чаща',
      [Terrain.Rock]: 'Сплошная скала — можно копать',
    };
    let name = names[t];
    const o = this.obj[i] as Obj;
    if (o === Obj.Tree) name = 'Дерево';
    else if (o === Obj.Rock) name = 'Валун';
    else if (o === Obj.BerryBush) name = 'Куст ягод';
    else if (o === Obj.RuinWall) name = 'Старая кладка';
    else if (o === Obj.Ore) name = 'Железная руда';
    else if (o === Obj.SilverOre) name = 'Серебряная жила';
    return name;
  }

  farmStageAt(x: number, y: number): FarmStage {
    return this.farmStage[this.idx(x, y)] as FarmStage;
  }
}

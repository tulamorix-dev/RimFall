// A* поиск пути на сетке, 8 направлений, без срезания углов.
// Поддерживает два режима: путь к цели и путь к любой клетке рядом с целью.

import { MAP } from '../data/defs';
import type { World } from './world';

export interface PathNode {
  x: number;
  y: number;
}

type PassFn = (x: number, y: number) => boolean;

// Бинарная куча по f-оценке
class Heap {
  private ids: number[] = [];
  private fs: number[] = [];
  get size(): number {
    return this.ids.length;
  }
  clear() {
    this.ids.length = 0;
    this.fs.length = 0;
  }
  push(id: number, f: number) {
    this.ids.push(id);
    this.fs.push(f);
    let i = this.ids.length - 1;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (this.fs[p] <= this.fs[i]) break;
      this.swap(i, p);
      i = p;
    }
  }
  pop(): number {
    const top = this.ids[0];
    const lastId = this.ids.pop()!;
    const lastF = this.fs.pop()!;
    if (this.ids.length > 0) {
      this.ids[0] = lastId;
      this.fs[0] = lastF;
      let i = 0;
      for (;;) {
        const l = i * 2 + 1;
        const r = l + 1;
        let m = i;
        if (l < this.ids.length && this.fs[l] < this.fs[m]) m = l;
        if (r < this.ids.length && this.fs[r] < this.fs[m]) m = r;
        if (m === i) break;
        this.swap(i, m);
        i = m;
      }
    }
    return top;
  }
  private swap(a: number, b: number) {
    const ti = this.ids[a];
    this.ids[a] = this.ids[b];
    this.ids[b] = ti;
    const tf = this.fs[a];
    this.fs[a] = this.fs[b];
    this.fs[b] = tf;
  }
}

const DIRS = [
  [1, 0],
  [-1, 0],
  [0, 1],
  [0, -1],
  [1, 1],
  [1, -1],
  [-1, 1],
  [-1, -1],
] as const;

// Переиспользуемые буферы (производительность)
const gScore = new Float32Array(MAP * MAP);
const cameFrom = new Int32Array(MAP * MAP);
const stamp = new Int32Array(MAP * MAP);
let curStamp = 0;
const heap = new Heap();

function heuristic(x: number, y: number, tx: number, ty: number): number {
  const dx = Math.abs(x - tx);
  const dy = Math.abs(y - ty);
  return (dx + dy) + (1.4142 - 2) * Math.min(dx, dy);
}

/**
 * Ищет путь. Если adjacent=true, цель — любая проходимая клетка,
 * соседняя с одной из targetIdx (Чебышёв 1). Возвращает путь БЕЗ стартовой клетки.
 * null — пути нет.
 */
export function findPath(
  world: World,
  sx: number,
  sy: number,
  pass: PassFn,
  targets: number[],
  adjacent: boolean,
  maxNodes = 6000,
): PathNode[] | null {
  const start = sy * MAP + sx;
  const targetSet = new Set(targets);
  if (targets.length === 0) return null;
  if (!adjacent && targetSet.has(start)) return [];

  curStamp++;
  heap.clear();
  gScore[start] = 0;
  stamp[start] = curStamp;
  cameFrom[start] = -1;

  // эвристика: минимум по целям
  const hMin = (x: number, y: number): number => {
    let best = Infinity;
    for (const t of targets) {
      const tx = t % MAP;
      const ty = (t / MAP) | 0;
      const h = heuristic(x, y, tx, ty);
      if (h < best) best = h;
    }
    return best;
  };

  heap.push(start, hMin(sx, sy));
  let expanded = 0;

  while (heap.size > 0 && expanded < maxNodes) {
    const cur = heap.pop();
    const cx = cur % MAP;
    const cy = (cur / MAP) | 0;

    // проверка цели
    if (adjacent) {
      let hit = false;
      for (const [dx, dy] of DIRS) {
        if (dx === 0 && dy === 0) continue;
        const nx = cx + dx;
        const ny = cy + dy;
        if (world.inBounds(nx, ny) && targetSet.has(ny * MAP + nx)) {
          hit = true;
          break;
        }
      }
      if (hit) return reconstruct(cameFrom, cur);
    } else if (targetSet.has(cur)) {
      return reconstruct(cameFrom, cur);
    }

    expanded++;
    const cg = gScore[cur];

    for (const [dx, dy] of DIRS) {
      const nx = cx + dx;
      const ny = cy + dy;
      if (!world.inBounds(nx, ny)) continue;
      const ni = ny * MAP + nx;
      if (!pass(nx, ny)) continue;
      // запрет срезания углов по диагонали
      if (dx !== 0 && dy !== 0) {
        if (!pass(cx + dx, cy) || !pass(cx, cy + dy)) continue;
      }
      const step = (dx !== 0 && dy !== 0 ? 1.4142 : 1) * world.moveCost(ni);
      const ng = cg + step;
      if (stamp[ni] === curStamp && gScore[ni] <= ng) continue;
      stamp[ni] = curStamp;
      gScore[ni] = ng;
      cameFrom[ni] = cur;
      heap.push(ni, ng + hMin(nx, ny));
    }
  }
  return null;
}

function reconstruct(cameFrom: Int32Array, endIdx: number): PathNode[] {
  const path: PathNode[] = [];
  let cur = endIdx;
  while (cur !== -1) {
    path.push({ x: cur % MAP, y: (cur / MAP) | 0 });
    cur = cameFrom[cur];
  }
  path.reverse();
  path.shift(); // убрать стартовую клетку
  return path;
}

// Удобные обёртки
export function pathToTile(world: World, sx: number, sy: number, tx: number, ty: number, animal: boolean): PathNode[] | null {
  if (!world.inBounds(tx, ty)) return null;
  const pass: PassFn = animal ? (x, y) => world.passAnimal(x, y) : (x, y) => world.passPawn(x, y);
  const start = sy * MAP + sx;
  const goal = ty * MAP + tx;
  // Если старт уже непроходим (застрял) — разрешить выход.
  // Режим цели сохраняется: к заблокированной клетке (стена/дерево) идём впритык.
  if (!pass(sx, sy)) {
    return findPathStuck(world, sx, sy, pass, [goal], !pass(tx, ty));
  }
  if (start === goal) return [];
  // Цель может быть непроходима (дерево/скала) — идти впритык
  if (!pass(tx, ty)) return findPath(world, sx, sy, pass, [goal], true);
  return findPath(world, sx, sy, pass, [goal], false);
}

export function pathToAdjacent(world: World, sx: number, sy: number, tileIdx: number, animal: boolean): PathNode[] | null {
  const tx = tileIdx % MAP;
  const ty = (tileIdx / MAP) | 0;
  const pass: PassFn = animal ? (x, y) => world.passAnimal(x, y) : (x, y) => world.passPawn(x, y);
  if (!pass(sx, sy)) return findPathStuck(world, sx, sy, pass, [tileIdx], true);
  if (chebDist(sx, sy, tx, ty) <= 1 && pass(sx, sy)) return [];
  return findPath(world, sx, sy, pass, [tileIdx], true);
}

function chebDist(ax: number, ay: number, bx: number, by: number): number {
  return Math.max(Math.abs(ax - bx), Math.abs(ay - by));
}

// Выход из "застрявшего" состояния: разрешаем проходить через занятые клетки старта
function findPathStuck(world: World, sx: number, sy: number, pass: PassFn, targets: number[], adjacent: boolean): PathNode[] | null {
  // временно разрешаем стартовую клетку, если пешка стоит в непроходимом месте
  return findPath(world, sx, sy, (x, y) => (x === sx && y === sy) || pass(x, y), targets, adjacent);
}

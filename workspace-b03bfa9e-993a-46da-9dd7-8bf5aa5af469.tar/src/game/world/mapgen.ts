// Процедурная генерация мира по seed: рельеф, вода, лес, камни, ягоды, руины, стартовая зона

import { MAP, Obj, Res, Terrain, Zone, BType, SILVER_START } from '../data/defs';
import { RNG, fbm } from '../core/rng';
import { World } from './world';
import { createBlueprint } from '../buildings/buildings';

export interface GenResult {
  spawnX: number;
  spawnY: number;
}

export function generateWorld(world: World, seed: number): GenResult {
  const rng = new RNG(seed);
  world.terrain.fill(Terrain.Grass);
  world.obj.fill(Obj.None);
  world.zone.fill(Zone.None);
  world.resetZones();
  world.farmStage.fill(0);
  world.items.length = 0;
  world.itemMap.clear();
  world.buildings.length = 0;
  world.buildingMap.clear();

  // --- Рельеф и вода ---
  for (let y = 0; y < MAP; y++) {
    for (let x = 0; x < MAP; x++) {
      const i = y * MAP + x;
      const elev = fbm(seed, x, y);
      const moist = fbm(seed + 777, x, y);
      if (elev < 0.36) {
        world.terrain[i] = Terrain.Water;
      } else if (elev > 0.72) {
        world.terrain[i] = Terrain.Stone;
      } else if (moist < 0.32 && elev < 0.5) {
        world.terrain[i] = Terrain.Dirt;
      } else if (moist > 0.62) {
        world.terrain[i] = Terrain.Forest;
      } else {
        world.terrain[i] = Terrain.Grass;
      }
    }
  }

  // Гарантия сухопутной связности: убрать одиночные озёра в центре карты
  const cx0 = MAP / 2;
  for (let y = cx0 - 14; y < cx0 + 14; y++) {
    for (let x = cx0 - 14; x < cx0 + 14; x++) {
      const i = y * MAP + x;
      if (world.terrain[i] === Terrain.Water) {
        // маленькие пруды оставляем, большие нет: упрощённо — в центральной зоне вода только если окружена водой
        let landN = 0;
        for (let dy = -1; dy <= 1; dy++)
          for (let dx = -1; dx <= 1; dx++) {
            const j = (y + dy) * MAP + (x + dx);
            if (world.inBounds(x + dx, y + dy) && world.terrain[j] !== Terrain.Water) landN++;
          }
        if (landN >= 6) world.terrain[i] = Terrain.Grass;
      }
    }
  }

  // --- Стартовая зона: ищем чистую площадку от центра наружу ---
  const spawn = findSpawnArea(world, rng);
  const sx = spawn.x;
  const sy = spawn.y;

  // --- Горные хребты: скала с валунами и богатыми железными жилами ---
  const mountainCenters = carveMountains(world, rng, sx, sy);

  // --- Плоский некопаемый камень -> копаемые скалы (RimWorld-стиль).
  // Большие серые равнины превращаются в горные массивы с жилами железа/серебра,
  // обрамлённые проходимой осыпью с валунами. ---
  const flatGoals = convertFlatStone(world, rng, sx, sy);

  // --- Лес ---
  for (let y = 0; y < MAP; y++) {
    for (let x = 0; x < MAP; x++) {
      const i = y * MAP + x;
      const t = world.terrain[i];
      if (t !== Terrain.Grass && t !== Terrain.Forest) continue;
      if (Math.abs(x - sx) < 5 && Math.abs(y - sy) < 5) continue; // расчистка старта
      const moist = fbm(seed + 777, x, y);
      const p = t === Terrain.Forest ? 0.55 : moist > 0.55 ? 0.35 : 0.08;
      if (rng.chance(p)) world.obj[i] = Obj.Tree;
    }
  }

  // --- Камни ---
  for (let c = 0; c < 16; c++) {
    const rx = rng.int(3, MAP - 4);
    const ry = rng.int(3, MAP - 4);
    if (Math.abs(rx - sx) < 7 && Math.abs(ry - sy) < 7) continue;
    const n = rng.int(1, 4);
    for (let k = 0; k < n; k++) {
      const x = Math.min(MAP - 1, Math.max(0, rx + rng.int(-1, 1)));
      const y = Math.min(MAP - 1, Math.max(0, ry + rng.int(-1, 1)));
      const i = y * MAP + x;
      if (world.terrain[i] === Terrain.Water) continue;
      if (world.obj[i] === Obj.None) world.obj[i] = Obj.Rock;
    }
  }

  // --- Железные руды (жилы по 2–5 клеток) ---
  let placedOre = 0;
  for (let tries = 0; tries < 500 && placedOre < 8; tries++) {
    const rx = rng.int(3, MAP - 4);
    const ry = rng.int(3, MAP - 4);
    if (Math.abs(rx - sx) < 6 && Math.abs(ry - sy) < 6) continue;
    if (world.terrain[ry * MAP + rx] === Terrain.Water || world.obj[ry * MAP + rx] !== Obj.None) continue;
    const n = rng.int(2, 5);
    for (let k = 0; k < n; k++) {
      const x = Math.min(MAP - 1, Math.max(0, rx + rng.int(-1, 1)));
      const y = Math.min(MAP - 1, Math.max(0, ry + rng.int(-1, 1)));
      const i = y * MAP + x;
      if (world.terrain[i] === Terrain.Water || world.terrain[i] === Terrain.Rock) continue;
      if (world.obj[i] === Obj.None) world.obj[i] = Obj.Ore;
    }
    placedOre++;
  }
  // гарантированная жила у старта — железо нужно для мечей
  for (let tries = 0; tries < 120; tries++) {
    const x = sx + rng.int(-12, 12);
    const y = sy + rng.int(-12, 12);
    if (!world.inBounds(x, y) || (Math.abs(x - sx) < 4 && Math.abs(y - sy) < 4)) continue;
    const i = y * MAP + x;
    if (world.terrain[i] !== Terrain.Water && world.terrain[i] !== Terrain.Rock && world.obj[i] === Obj.None) {
      for (let k = 0; k < 3; k++) {
        const nx = Math.min(MAP - 1, Math.max(0, x + rng.int(-1, 1)));
        const ny = Math.min(MAP - 1, Math.max(0, y + rng.int(-1, 1)));
        const ni = ny * MAP + nx;
        if (world.terrain[ni] !== Terrain.Water && world.terrain[ni] !== Terrain.Rock && world.obj[ni] === Obj.None) world.obj[ni] = Obj.Ore;
      }
      break;
    }
  }

  // --- Ягодные кусты ---
  let placedBerries = 0;
  for (let tries = 0; tries < 400 && placedBerries < 26; tries++) {
    const x = rng.int(2, MAP - 3);
    const y = rng.int(2, MAP - 3);
    const i = y * MAP + x;
    const t = world.terrain[i];
    if ((t === Terrain.Grass || t === Terrain.Forest) && world.obj[i] === Obj.None) {
      world.obj[i] = Obj.BerryBush;
      placedBerries++;
    }
  }
  // 3 куста рядом со стартом гарантированно
  for (let k = 0; k < 3; k++) {
    for (let tries = 0; tries < 60; tries++) {
      const x = sx + rng.int(-9, 9);
      const y = sy + rng.int(-9, 9);
      if (!world.inBounds(x, y)) continue;
      const i = y * MAP + x;
      if (world.terrain[i] !== Terrain.Water && world.obj[i] === Obj.None && !(x === sx && y === sy)) {
        world.obj[i] = Obj.BerryBush;
        break;
      }
    }
  }

  // --- Руины (2 места вдали от старта) ---
  const ruinCenters: { x: number; y: number }[] = [];
  let ruinCount = 0;
  for (let tries = 0; tries < 200 && ruinCount < 2; tries++) {
    const rx = rng.int(6, MAP - 7);
    const ry = rng.int(6, MAP - 7);
    if (Math.hypot(rx - sx, ry - sy) < 20) continue;
    // площадка 5x5 без воды
    let ok = true;
    for (let dy = -2; dy <= 2 && ok; dy++)
      for (let dx = -2; dx <= 2; dx++)
        if (world.terrain[(ry + dy) * MAP + (rx + dx)] === Terrain.Water) {
          ok = false;
          break;
        }
    if (!ok) continue;
    for (let dy = -2; dy <= 2; dy++) {
      for (let dx = -2; dx <= 2; dx++) {
        const edge = Math.abs(dx) === 2 || Math.abs(dy) === 2;
        const i = (ry + dy) * MAP + (rx + dx);
        world.obj[i] = Obj.None;
        if (edge) {
          // проёмы
          if ((dx === 0 && dy === -2) || (dx === -2 && dy === 0) || rng.chance(0.25)) continue;
          world.obj[i] = Obj.RuinWall;
          world.objHp[i] = rng.range(30, 90);
        }
      }
    }
    const li = ry * MAP + rx;
    world.obj[li] = Obj.None;
    world.addItem(Res.Loot, 1, rx, ry);
    ruinCenters.push({ x: rx, y: ry });
    ruinCount++;
  }

  // --- Гарантия достижимости: река может отрезать старт от руды/гор/руин.
  // К каждой недостижимой цели прокладывается тропа (брод/расчистка). ---
  const goals: { x: number; y: number }[] = [...mountainCenters, ...ruinCenters, ...flatGoals];
  for (let i = 0; i < world.obj.length; i++) {
    if (world.obj[i] === Obj.Ore && world.terrain[i] !== Terrain.Stone) {
      goals.push({ x: i % MAP, y: (i / MAP) | 0 });
    }
  }
  ensureReachable(world, goals, sx, sy);

  // --- Стартовый склад с припасами ---
  const stock = placeStartStockpile(world, rng, sx, sy);
  world.addItem(Res.Food, 30, stock.x, stock.y);
  const woodTile = freeNear(world, stock.x, stock.y, 3, rng);
  if (woodTile) world.addItem(Res.Wood, 30, woodTile.x, woodTile.y);
  const silverTile = freeNear(world, stock.x, stock.y, 2, rng);
  if (silverTile) world.addItem(Res.Silver, SILVER_START, silverTile.x, silverTile.y);

  return { spawnX: sx, spawnY: sy };
}

// Плоский камень (Terrain.Stone), не примыкающий к горам, — бесполезная серая
// равнина: её нельзя копать, и игрок на неё жалуется. Правило: камень в 2 клетках
// от скалы — осыпь у подножия (остаётся проходимой), весь остальной камень —
// сплошная копаемая скала с жилами железа и серебра. Возвращает центры новых
// массивов (для проверки достижимости).
function convertFlatStone(world: World, rng: RNG, sx: number, sy: number): { x: number; y: number }[] {
  const goals: { x: number; y: number }[] = [];
  const converted: number[] = [];
  const hasRockNear = (x: number, y: number) => {
    for (let dy = -2; dy <= 2; dy++) {
      for (let dx = -2; dx <= 2; dx++) {
        const nx = x + dx;
        const ny = y + dy;
        if (world.inBounds(nx, ny) && world.terrain[world.idx(nx, ny)] === Terrain.Rock) return true;
      }
    }
    return false;
  };
  // 1) конвертация: всё, что не осыпь у гор и не площадка у старта
  for (let y = 0; y < MAP; y++) {
    for (let x = 0; x < MAP; x++) {
      const i = world.idx(x, y);
      if (world.terrain[i] !== Terrain.Stone) continue;
      if (Math.abs(x - sx) < 6 && Math.abs(y - sy) < 6) continue; // старт оставляем мягким
      if (hasRockNear(x, y)) continue; // это подножие горы — осыпь
      world.terrain[i] = Terrain.Rock;
      converted.push(i);
    }
  }
  if (converted.length === 0) return goals;
  // 2) жилы: компоненты новых скал (8-связность)
  const compSeen = new Uint8Array(MAP * MAP);
  const isNewRock = new Uint8Array(MAP * MAP);
  for (const i of converted) isNewRock[i] = 1;
  for (const startI of converted) {
    if (compSeen[startI]) continue;
    const comp: number[] = [];
    const q = [startI];
    compSeen[startI] = 1;
    while (q.length) {
      const i = q.pop()!;
      comp.push(i);
      const cx = i % MAP;
      const cy = (i / MAP) | 0;
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          const nx = cx + dx;
          const ny = cy + dy;
          if (!world.inBounds(nx, ny)) continue;
          const ni = world.idx(nx, ny);
          if (compSeen[ni] || world.terrain[ni] !== Terrain.Rock) continue;
          // в компонент тянут только новые скалы (старые горы — отдельные массивы)
          if (!isNewRock[ni]) continue;
          compSeen[ni] = 1;
          q.push(ni);
        }
      }
    }
    // богатство: жилы железа по толще, изредка серебро
    const veins = Math.max(1, Math.min(3, Math.round(comp.length / 5)));
    for (let v = 0; v < veins; v++) {
      let cur = comp[rng.int(0, comp.length - 1)];
      const n = rng.int(2, 5);
      for (let k = 0; k < n; k++) {
        if (world.obj[cur] === Obj.None) world.obj[cur] = Obj.Ore;
        const nx = Math.max(0, Math.min(MAP - 1, (cur % MAP) + rng.int(-1, 1)));
        const ny = Math.max(0, Math.min(MAP - 1, ((cur / MAP) | 0) + rng.int(-1, 1)));
        cur = world.idx(nx, ny);
      }
    }
    if (rng.chance(0.15)) {
      const i = comp[rng.int(0, comp.length - 1)];
      if (world.obj[i] === Obj.None) world.obj[i] = Obj.SilverOre;
    }
    let mx = 0;
    let my = 0;
    for (const i of comp) {
      mx += i % MAP;
      my += (i / MAP) | 0;
    }
    goals.push({ x: Math.round(mx / comp.length), y: Math.round(my / comp.length) });
  }
  return goals;
}

// Горные хребты: как в RimWorld — СПЛОШНАЯ скала, в которую вгрызаются копанием.
// Внутри массива — непроходимый Terrain.Rock (туннели появляются по мере добычи),
// по краю — проходимый горный гравий (Terrain.Stone). В толще — железные и
// серебряные жилы. Первый хребет гарантированно недалеко от старта.
// Возвращает центры хребтов (для проверки достижимости).
function carveMountains(world: World, rng: RNG, sx: number, sy: number): { x: number; y: number }[] {
  // центры: [ближний гарантированный, дальний, дальний]
  const centers: { x: number; y: number }[] = [];
  // 1) ближний хребет: 12–18 клеток от старта в случайном направлении
  let placedNear = false;
  for (let tries = 0; tries < 80 && !placedNear; tries++) {
    const a = rng.range(0, Math.PI * 2);
    const d = rng.range(12, 18);
    const x = Math.round(sx + Math.cos(a) * d);
    const y = Math.round(sy + Math.sin(a) * d);
    if (x < 9 || y < 9 || x > MAP - 10 || y > MAP - 10) continue;
    centers.push({ x, y });
    placedNear = true;
  }
  if (!placedNear) centers.push({ x: Math.max(9, Math.min(MAP - 10, sx + 14)), y: Math.max(9, Math.min(MAP - 10, sy - 12)) });
  // 2) ещё два хребта подальше
  for (let m = 0; m < 2; m++) {
    for (let tries = 0; tries < 60; tries++) {
      const x = rng.int(9, MAP - 10);
      const y = rng.int(9, MAP - 10);
      if (Math.hypot(x - sx, y - sy) < 14) continue;
      if (centers.some((c) => Math.hypot(c.x - x, c.y - y) < 12)) continue; // не сливаются
      centers.push({ x, y });
      break;
    }
  }

  const exits: { x: number; y: number }[] = [];
  for (const c of centers) {
    const R = rng.int(4, 7); // радиус массива
    // кэш клеток массива — для жил
    const cells: number[] = [];
    for (let dy = -R - 1; dy <= R + 1; dy++) {
      for (let dx = -R - 1; dx <= R + 1; dx++) {
        const x = c.x + dx;
        const y = c.y + dy;
        if (!world.inBounds(x, y)) continue;
        const d = Math.hypot(dx, dy) + fbm(rng.int(0, 999999), x, y) * 2.2;
        if (d > R) continue;
        if (Math.abs(x - sx) < 9 && Math.abs(y - sy) < 9) continue; // не накрываем старт
        const i = y * MAP + x;
        // край массива — проходимый гравий, толща — сплошная скала
        world.terrain[i] = d > R - 1.3 ? Terrain.Stone : Terrain.Rock;
        cells.push(i);
      }
    }
    if (cells.length < 8) continue;
    const rockCells = cells.filter((i) => world.terrain[i] === Terrain.Rock);
    // жилы: 2–3 на хребет, по 3–6 клеток — заметное богатство (в толще скалы)
    const veins = rng.int(2, 3);
    for (let v = 0; v < veins; v++) {
      const start = (rockCells.length > 0 ? rockCells : cells)[rng.int(0, (rockCells.length > 0 ? rockCells : cells).length - 1)];
      let x = start % MAP;
      let y = (start / MAP) | 0;
      const n = rng.int(3, 6);
      for (let k = 0; k < n; k++) {
        const i = y * MAP + x;
        if (world.terrain[i] === Terrain.Rock) world.obj[i] = Obj.Ore;
        x = Math.max(0, Math.min(MAP - 1, x + rng.int(-1, 1)));
        y = Math.max(0, Math.min(MAP - 1, y + rng.int(-1, 1)));
      }
    }
    // серебро: с шансом ~60% в хребте прячется серебряная ветвь 1–3 клетки — валюта караванов
    if (rng.chance(0.6) && rockCells.length > 0) {
      const start = rockCells[rng.int(0, rockCells.length - 1)];
      let x = start % MAP;
      let y = (start / MAP) | 0;
      const n = rng.int(1, 3);
      for (let k = 0; k < n; k++) {
        const i = y * MAP + x;
        if (world.terrain[i] === Terrain.Rock && world.obj[i] === Obj.None) world.obj[i] = Obj.SilverOre;
        x = Math.max(0, Math.min(MAP - 1, x + rng.int(-1, 1)));
        y = Math.max(0, Math.min(MAP - 1, y + rng.int(-1, 1)));
      }
    }
    // валуны только на проходимом крае (внутри — монолит)
    for (const i of cells) {
      if (world.terrain[i] === Terrain.Stone && world.obj[i] === Obj.None && rng.chance(0.35)) world.obj[i] = Obj.Rock;
    }
    // якорь достижимости: край массива, к которому можно подойти с обычной земли
    let anchor: { x: number; y: number } | null = null;
    for (const i of cells) {
      if (world.terrain[i] !== Terrain.Stone) continue;
      const ax = i % MAP;
      const ay = (i / MAP) | 0;
      let open = false;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = ax + dx;
        const ny = ay + dy;
        if (!world.inBounds(nx, ny)) continue;
        const nt = world.terrain[ny * MAP + nx];
        if (nt !== Terrain.Stone && nt !== Terrain.Rock && nt !== Terrain.Water) open = true;
      }
      if (open) {
        anchor = { x: ax, y: ay };
        break;
      }
    }
    exits.push(anchor ?? c);
  }
  return exits;
}

// --- Достижимость: flood-fill от старта без срезания углов.
// Жёсткий блокер — только вода (валуны и руда выкапываются, деревья рубятся).
function reachFlood(world: World, sx: number, sy: number): Uint8Array {
  const seen = new Uint8Array(MAP * MAP);
  const blocked = (x: number, y: number) => world.terrain[y * MAP + x] === Terrain.Water;
  if (blocked(sx, sy)) return seen;
  const start = sy * MAP + sx;
  seen[start] = 1;
  const q = [start];
  const DIRS = [
    [1, 0],
    [-1, 0],
    [0, 1],
    [0, -1],
    [1, 1],
    [1, -1],
    [-1, 1],
    [-1, -1],
  ];
  while (q.length) {
    const c = q.pop()!;
    const cx = c % MAP;
    const cy = (c / MAP) | 0;
    for (const [dx, dy] of DIRS) {
      const nx = cx + dx;
      const ny = cy + dy;
      if (!world.inBounds(nx, ny)) continue;
      const ni = ny * MAP + nx;
      if (seen[ni]) continue;
      if (blocked(nx, ny)) continue;
      if (dx !== 0 && dy !== 0 && (blocked(cx + dx, cy) || blocked(cx, cy + dy))) continue;
      seen[ni] = 1;
      q.push(ni);
    }
  }
  return seen;
}

// Цель достижима, если пешка сможет подойти вплотную (или уже стоит рядом)
function goalReachable(world: World, seen: Uint8Array, g: { x: number; y: number }): boolean {
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      const x = g.x + dx;
      const y = g.y + dy;
      if (!world.inBounds(x, y)) continue;
      if (seen[y * MAP + x]) return true;
    }
  }
  return false;
}

// Тропа от старта к цели: брод через воду, расчистка камней/деревьев.
// Вторая клетка линии (сдвиг на 1) даёт ширину 2 — угловой запрет A* не ломает путь.
function carveTrail(world: World, sx: number, sy: number, tx: number, ty: number) {
  let x0 = sx;
  let y0 = sy;
  const dx = Math.abs(tx - x0);
  const dy = Math.abs(ty - y0);
  const stepX = x0 < tx ? 1 : -1;
  const stepY = y0 < ty ? 1 : -1;
  let err = dx - dy;
  let guard = 0;
  for (;;) {
    if (guard++ > MAP * 3) break;
    clearTrailCell(world, x0, y0);
    if (guard > 2) clearTrailCell(world, x0 + 1, y0);
    if (x0 === tx && y0 === ty) break;
    const e2 = 2 * err;
    if (e2 > -dy) {
      err -= dy;
      x0 += stepX;
    }
    if (e2 < dx) {
      err += dx;
      y0 += stepY;
    }
  }
}

function clearTrailCell(world: World, x: number, y: number) {
  if (!world.inBounds(x, y)) return;
  const i = y * MAP + x;
  // брод: вода превращается в грязь. Валуны/деревья не трогаем — пешки сами
  // выкопают/срубят их по месту (это часть горного дела).
  if (world.terrain[i] === Terrain.Water) world.terrain[i] = Terrain.Dirt;
}

// Гарантия: к каждой цели (гора/руина/равнинная жила) есть путь от старта через сушу.
// Недостижимые соединяем бродами и обновляем область достижимости.
function ensureReachable(world: World, goals: { x: number; y: number }[], sx: number, sy: number) {
  let seen = reachFlood(world, sx, sy);
  for (const g of goals) {
    if (goalReachable(world, seen, g)) continue;
    carveTrail(world, sx, sy, g.x, g.y);
    seen = reachFlood(world, sx, sy);
  }
}

function findSpawnArea(world: World, rng: RNG): { x: number; y: number } {
  const c = MAP / 2;
  for (let r = 0; r < 24; r++) {
    for (let tries = 0; tries < 40; tries++) {
      const x = Math.round(c + rng.range(-r, r));
      const y = Math.round(c + rng.range(-r, r));
      if (x < 8 || y < 8 || x > MAP - 9 || y > MAP - 9) continue;
      let land = 0;
      let total = 0;
      let stoneN = 0;
      for (let dy = -4; dy <= 4; dy++) {
        for (let dx = -4; dx <= 4; dx++) {
          const i = (y + dy) * MAP + (x + dx);
          total++;
          const t = world.terrain[i];
          if (t !== Terrain.Water) land++;
          if (t === Terrain.Stone || t === Terrain.Rock) stoneN++;
        }
      }
      // стартуем на мягкой земле: скальные массивы не должны накрыть лагерь
      if (land / total > 0.92 && stoneN <= 2) return { x, y };
    }
  }
  return { x: Math.round(c), y: Math.round(c) };
}

function placeStartStockpile(world: World, rng: RNG, sx: number, sy: number): { x: number; y: number } {
  for (let tries = 0; tries < 80; tries++) {
    const ox = sx + rng.int(-4, 4);
    const oy = sy + rng.int(-4, 4);
    let ok = true;
    for (let dy = 0; dy < 2 && ok; dy++)
      for (let dx = 0; dx < 3; dx++) {
        const x = ox + dx;
        const y = oy + dy;
        if (!world.inBounds(x, y)) {
          ok = false;
          break;
        }
        const i = y * MAP + x;
        if (world.terrain[i] === Terrain.Water || world.obj[i] !== Obj.None) {
          ok = false;
          break;
        }
      }
    if (!ok) continue;
    const zd = world.createZone('stockpile');
    if (!zd) continue;
    for (let dy = 0; dy < 2; dy++)
      for (let dx = 0; dx < 3; dx++) {
        const i = (oy + dy) * MAP + (ox + dx);
        world.zone[i] = Zone.Stockpile;
        world.zoneId[i] = zd.id;
        world.obj[i] = Obj.None;
      }
    return { x: ox + 1, y: oy };
  }
  // fallback: вокруг старта
  const i = sy * MAP + sx;
  world.zone[i] = Zone.Stockpile;
  const zf = world.createZone('stockpile');
  if (zf) world.zoneId[i] = zf.id;
  return { x: sx, y: sy };
}

function freeNear(world: World, x: number, y: number, r: number, rng: RNG): { x: number; y: number } | null {
  for (let tries = 0; tries < 40; tries++) {
    const nx = x + rng.int(-r, r);
    const ny = y + rng.int(-r, r);
    if (!world.inBounds(nx, ny)) continue;
    const i = ny * MAP + nx;
    if (world.terrain[i] !== Terrain.Water && world.obj[i] === Obj.None && !world.buildingMap.has(i) && world.zone[i] === Zone.None)
      return { x: nx, y: ny };
  }
  return null;
}

// Стартовый костёр (сразу готов, не чертёж) — уют и свет первой ночи
export function placeStartCampfire(world: World, rng: RNG, sx: number, sy: number) {
  for (let tries = 0; tries < 60; tries++) {
    const x = sx + rng.int(-3, 3);
    const y = sy + rng.int(-3, 3);
    if (!world.inBounds(x, y) || (x === sx && y === sy)) continue;
    const i = y * MAP + x;
    if (world.terrain[i] !== Terrain.Water && world.obj[i] === Obj.None && !world.buildingMap.has(i) && world.zone[i] !== Zone.Stockpile) {
      const b = createBlueprint(BType.Campfire, x, y);
      b.blueprint = false;
      b.matHave = b.matNeed;
      b.workHave = b.workNeed;
      world.placeBuilding(b);
      return;
    }
  }
}

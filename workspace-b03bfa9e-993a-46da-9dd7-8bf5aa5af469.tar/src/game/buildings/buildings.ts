// Постройки: фабрика, типы

import { BType, BUILDINGS, Res } from '../data/defs';

export interface Building {
  id: number;
  type: BType;
  x: number;
  y: number;
  hp: number;
  maxHp: number;
  blueprint: boolean; // чертёж: ждёт материалов и работы
  matType: Res;
  matNeed: number;
  matHave: number;
  workNeed: number;
  workHave: number;
  ownerId: number | null; // для кровати
  graveName?: string; // кто похоронен в могиле (для рендера надгробия и осмотра)
  mineCd?: number; // шахта: совместимость со старыми сейвами (эпоха «вечной жилы»)
  bills?: Bill[]; // верстак: заказы производства «что и сколько» (RimWorld-стиль)
  mealTarget?: number; // костёр: до скольких порций похлёбки варить (0 — не варить)
  turretCd?: number; // башня: игровых минут до следующего болта
}

// Заказ на верстаке: рецепт (индекс в RECIPES), сколько сделать и сколько уже готово
export interface Bill {
  recipe: number;
  count: number;
  done: number;
}

// Дефолтные заказы нового верстака: колония сама вооружается, игрок может изменить
export function defaultBills(): Bill[] {
  return [
    { recipe: 0, count: 2, done: 0 }, // копьё ×2
    { recipe: 1, count: 1, done: 0 }, // лук ×1
  ];
}

let nextId = 1;
export function resetBuildingIds(id = 1) {
  nextId = id;
}
export function peekBuildingId(): number {
  return nextId;
}

export function createBlueprint(type: BType, x: number, y: number): Building {
  const def = BUILDINGS[type];
  const b: Building = {
    id: nextId++,
    type,
    x,
    y,
    hp: def.hp,
    maxHp: def.hp,
    blueprint: true,
    matType: def.mat,
    matNeed: def.matNeed,
    matHave: 0,
    workNeed: def.work,
    workHave: 0,
    ownerId: null,
  };
  if (type === BType.Workbench) b.bills = defaultBills();
  if (type === BType.Campfire) b.mealTarget = 8;
  return b;
}

export function completeBuilding(b: Building) {
  b.blueprint = false;
  b.workHave = b.workNeed;
}

export function buildingLabel(b: Building): string {
  const def = BUILDINGS[b.type];
  if (b.blueprint) return `${def.name} (чертёж)`;
  if (b.type === BType.Grave && b.graveName) return `Могила: ${b.graveName}`;
  if (b.type === BType.Workbench && b.bills) {
    const left = b.bills.reduce((s, bl) => s + Math.max(0, bl.count - bl.done), 0);
    return left > 0 ? `${def.name}: заказов ${left}` : def.name;
  }
  return def.name;
}

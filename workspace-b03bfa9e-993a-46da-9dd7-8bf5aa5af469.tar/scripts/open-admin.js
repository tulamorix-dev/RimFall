// Полный цикл: верстак через админку → заказы → крафт работающими пешками
(() => {
  const click = (pred) => {
    const b = [...document.querySelectorAll('button')].find(pred);
    if (b) b.click();
    return !!b;
  };
  const g = window.__game;
  const r = {};
  // открыть админку
  r.open = click((x) => x.getAttribute('aria-label') === 'Админ-панель');
  return JSON.stringify(r);
})();

// Task 13: горы, руда, шахта — полный цикл
// A) генерация: руда и горы на карте  B) запрет шахты вне скалы
// C) постройка шахты на скале  D) работа шахтёра -> дроп железа -> склад
// Результат в window.__t13 (асинхронный, опрос снаружи).
(function () {
  const g = window.__game;
  const res = { started: true };
  window.__t13 = res;
  const BType = { Wall: 0, Door: 1, Bed: 2, Campfire: 3, Workbench: 4, Table: 5, Chair: 6, Torch: 7, StoneWall: 8, Grave: 9, Mine: 10 };
  const Terrain = { Grass: 0, Dirt: 1, Water: 2, Stone: 3, Forest: 4 };
  const Obj = { None: 0, Tree: 1, Rock: 2, BerryBush: 3, RuinWall: 4, Ore: 5 };
  const Res = { Wood: 0, Stone: 1, Food: 2, Loot: 3, Corpse: 4, Meal: 5, Spear: 6, Bow: 7, Iron: 8 };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function run() {
    try {
      const w = g.world;
      g.setSpeed(8);

      // --- A) генерация ---
      let ore = 0, oreInStone = 0, stoneFree = 0, stoneTiles = 0;
      for (let i = 0; i < 64 * 64; i++) {
        if (w.terrain[i] === Terrain.Stone) stoneTiles++;
        if (w.obj[i] === Obj.Ore) {
          ore++;
          if (w.terrain[i] === Terrain.Stone) oreInStone++;
        }
      }
      // чистая клетка скалы (для шахты), подальше от старта чтобы не мешать
      let mineSpot = null;
      const sp = w.stockpileCenter() || { x: 32, y: 32 };
      outer: for (let y = 2; y < 62; y++) {
        for (let x = 2; x < 62; x++) {
          const i = y * 64 + x;
          if (w.terrain[i] !== Terrain.Stone) continue;
          if (w.obj[i] === Obj.Rock || w.obj[i] === Obj.None) {
            // свободная клетка рядом (дроп добычи и путь шахтёра)
            for (let dy = -1; dy <= 1; dy++)
              for (let dx = -1; dx <= 1; dx++) {
                const nx = x + dx, ny = y + dy;
                if (!w.inBounds(nx, ny)) continue;
                if (w.passPawn(nx, ny) && !w.buildingMap.has(ny * 64 + nx)) { mineSpot = { x, y, free: [nx, ny] }; break outer; }
              }
          }
        }
      }
      res.gen = { ore, oreInStone, stoneTiles, mineSpot };

      // --- B) запрет шахты на траве ---
      let grassSpot = null;
      for (let t = 0; t < 400 && !grassSpot; t++) {
        const x = 4 + ((t * 7) % 56), y = 4 + ((t * 13) % 56);
        const i = y * 64 + x;
        if (w.terrain[i] === Terrain.Grass && w.obj[i] === Obj.None && !w.buildingMap.has(i) && w.zone[i] === 0) grassSpot = { x, y };
      }
      g.placeBlueprintAt(BType.Mine, grassSpot.x, grassSpot.y);
      res.grassDenied = !w.buildingMap.has(grassSpot.y * 64 + grassSpot.x);

      // --- C) постройка шахты на скале ---
      g.placeBlueprintAt(BType.Mine, mineSpot.x, mineSpot.y);
      const bp = w.buildingMap.get(mineSpot.y * 64 + mineSpot.x);
      res.blueprintPlaced = !!bp && bp.blueprint;
      if (!bp) { res.error = 'no blueprint on stone'; return; }
      // материал: 4 дерева рядом с чертежом (под ногами дропнем)
      const [fx, fy] = mineSpot.free;
      w.addItem(Res.Wood, 6, fx, fy);
      // ждём достройку (до 60с реала на 8x)
      for (let t = 0; t < 120; t++) {
        await sleep(500);
        const b = w.buildingMap.get(mineSpot.y * 64 + mineSpot.x);
        if (b && !b.blueprint) break;
      }
      const b2 = w.buildingMap.get(mineSpot.y * 64 + mineSpot.x);
      res.mineBuilt = !!b2 && !b2.blueprint;
      if (!res.mineBuilt) { res.error = 'mine not built'; return; }

      // --- D) цикл выработки: ждём первую добычу ---
      const ironBefore = w.countRes(Res.Iron);
      let ironDrop = 0, haulDone = false;
      for (let t = 0; t < 240; t++) {
        await sleep(500);
        // железо на земле у шахты (в радиусе 2 от неё)
        ironDrop = 0;
        for (const it of w.items) {
          if (it.type !== Res.Iron) continue;
          if (Math.hypot(it.x - mineSpot.x, it.y - mineSpot.y) <= 2.5) ironDrop += it.qty;
        }
        if (w.countRes(Res.Iron) > ironBefore + ironDrop) haulDone = true; // часть ушла на склад
        if (ironDrop > 0 && (haulDone || t > 60)) break;
      }
      res.ironDrop = ironDrop;
      res.hauled = w.countRes(Res.Iron) > ironBefore;
      const b3 = w.buildingMap.get(mineSpot.y * 64 + mineSpot.x);
      res.mineCd = b3.mineCd;
      // кто-то работал в шахте?
      res.activities = g.pawns.filter((p) => !p.dead).map((p) => ({ n: p.name, a: p.job ? p.job.kind : p.state }));
      res.ok = res.mineBuilt && res.ironDrop > 0;
    } catch (e) {
      res.error = String(e && e.stack ? e.stack : e);
    }
  }
  run();
})();

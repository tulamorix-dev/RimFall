(function(){
  const findBtnByText = (t) => [...document.querySelectorAll('button')].find((b) => b.innerText.includes(t));
  const b = findBtnByText('Продолжить'); if (b) b.click();
  return b ? 'resumed' : 'no resume';
})()

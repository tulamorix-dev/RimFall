(function(){
  const findBtnByText = (t) => [...document.querySelectorAll('button')].find((b) => b.innerText.includes(t));
  const b = findBtnByText('Отказать'); if (b) b.click();
  return b ? 'declined' : 'no choice';
})()

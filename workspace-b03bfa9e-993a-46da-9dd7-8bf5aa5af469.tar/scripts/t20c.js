(function(){
  const findBtnByText = (t) => [...document.querySelectorAll('button')].find((b) => b.innerText.includes(t));
  const l = findBtnByText('Загрузить игру'); if (l) l.click();
  return l ? 'loading' : 'no load btn';
})()

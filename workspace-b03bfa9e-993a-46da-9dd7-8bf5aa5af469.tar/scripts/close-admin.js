// Сохранить игру через меню паузы
(() => {
  const btns = [...document.querySelectorAll('button')];
  // закрыть админку (✕ в шапке панели)
  const adminClose = btns.find((x) => x.getAttribute('aria-label') === 'Закрыть');
  if (adminClose) adminClose.click();
  return 'admin closed';
})();

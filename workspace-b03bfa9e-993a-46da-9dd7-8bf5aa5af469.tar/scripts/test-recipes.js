// Тест админ-панели: рецепты + переиндексация заказов
(() => {
  const g = window.__game;
  const r = {};
  // 1) верстака нет — даём через мир? Вкладку переключаем из UI. Здесь только состояние.
  const wb = g.world.buildings.find((b) => b.type === 4);
  r.hasWorkbench = !!wb;
  if (wb) {
    g.addBill(wb.id, 2, 3); // мечи ×3
    g.addBill(wb.id, 0, 1); // копьё ×1
    r.bills = wb.bills.map((b) => b.recipe);
  }
  r.recipes = window.RECIPES ? window.RECIPES.length : 'no-global';
  return JSON.stringify(r);
})();

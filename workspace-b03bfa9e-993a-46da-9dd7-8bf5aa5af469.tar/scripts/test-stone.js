// Task 12: каменная стена, могила + похороны в неё, ИИ-тепло (зимний ИИ)
// Результат кладётся в window.__t12 (опрос снаружи), т.к. тест асинхронный.
(function () {
  const g = window.__game;
  const res = { started: true };
  window.__t12 = res;
  const Res = { Wood: 0, Stone: 1, Food: 2, Loot: 3, Corpse: 4, Meal: 5, Spear: 6, Bow: 7, Iron: 8, Sword: 9 };
  const BType = { Wall: 0, Door: 1, Bed: 2, Campfire: 3, Workbench: 4, Table: 5, Chair: 6, Torch: 7, StoneWall: 8, Grave: 9 };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function freeTile(fromX, fromY, minD, maxD) {
    for (let rad = minD; rad <= (maxD || 20); rad++) {
      for (let t = 0; t < 60; t++) {
        const ang = (Math.PI * 2 * t) / 60;
        const tx = Math.round(fromX + Math.cos(ang) * rad);
        const ty = Math.round(fromY + Math.sin(ang) * rad);
        if (tx < 2 || ty < 2 || tx > 61 || ty > 61) continue;
        const i = ty * 64 + tx;
        if (g.world.passPawn(tx, ty) && g.world.terrain[i] !== 2 && g.world.obj[i] === 0 && g.world.zone[i] === 0 && !g.world.buildingMap.has(i)) {
          return [tx, ty];
        }
      }
    }
    return null;
  }

  function freeStrip2(x0, y0) {
    // две свободные клетки подряд (для камня рядом с чертежом)
    const cands = [[1, 0], [0, 1], [-1, 0], [0, -1], [1, 1]];
    for (const [dx, dy] of cands) {
      const tx = x0 + dx, ty = y0 + dy;
      if (tx < 2 || ty < 2 || tx > 61 || ty > 61) continue;
      const i = ty * 64 + tx;
      if (g.world.passPawn(tx, ty) && g.world.terrain[i] !== 2 && g.world.obj[i] === 0 && g.world.zone[i] === 0 && !g.world.buildingMap.has(i)) return [tx, ty];
    }
    return null;
  }

  function bAt(tx, ty) { return g.world.buildingMap.get(ty * 64 + tx); }

  async function run() {
    try {
      const base = g.campfires()[0] || { x: 30, y: 30 };
      g.setSpeed(8);

      // --- Тест A: каменная стена — чертёж -> доставка камня -> стройка ---
      const spotA = freeTile(base.x, base.y, 4, 12);
      g.placeBlueprintAt(BType.StoneWall, spotA[0], spotA[1]);
      const bpA = bAt(spotA[0], spotA[1]);
      res.A_blueprint = !!bpA && bpA.blueprint && bpA.type === BType.StoneWall && bpA.matNeed === 4;
      const dropA = freeStrip2(spotA[0], spotA[1]);
      g.world.addItem(Res.Stone, 8, dropA[0], dropA[1]);
      let okA = false;
      for (let k = 0; k < 90; k++) {
        await sleep(1000);
        const b = bAt(spotA[0], spotA[1]);
        if (b && !b.blueprint && b.type === BType.StoneWall) { okA = true; break; }
      }
      res.A_built = okA;
      res.A_hp = okA ? bAt(spotA[0], spotA[1]).hp : 0;

      // --- Тест B: могила — стройка -> похороны тела с именем ---
      const spotB = freeTile(spotA[0], spotA[1], 3, 14);
      g.placeBlueprintAt(BType.Grave, spotB[0], spotB[1]);
      const bpB = bAt(spotB[0], spotB[1]);
      res.B_blueprint = !!bpB && bpB.blueprint && bpB.type === BType.Grave && bpB.matNeed === 2;
      const dropB = freeStrip2(spotB[0], spotB[1]);
      g.world.addItem(Res.Stone, 6, dropB[0], dropB[1]);
      let builtB = false;
      for (let k = 0; k < 90; k++) {
        await sleep(1000);
        const b = bAt(spotB[0], spotB[1]);
        if (b && !b.blueprint && b.type === BType.Grave) { builtB = true; break; }
      }
      res.B_built = builtB;
      if (builtB) {
        const spotC = freeTile(spotB[0], spotB[1], 2, 10);
        const corpse = g.world.addItem(Res.Corpse, 1, spotC[0], spotC[1]);
        corpse.name = 'Фёдор';
        const orderOk = g.orderBurial(corpse.id);
        res.B_orderAccepted = orderOk;
        let buried = false;
        for (let k = 0; k < 120; k++) {
          await sleep(1000);
          const gone = !g.world.items.some((it) => it.id === corpse.id);
          const grave = bAt(spotB[0], spotB[1]);
          if (gone && grave.graveName === 'Фёдор') { buried = true; break; }
        }
        res.B_buriedWithGrave = buried;
        res.B_graveName = bAt(spotB[0], spotB[1]).graveName || null;
        res.B_story = g.events.entries.some((e) => e.text.includes('Фёдор') && e.text.includes('могиле'));
      }

      // --- Тест C: ИИ-тепло — зимняя ночь, пешка вдали от костра идёт греться ---
      const before = { totalMin: g.clock.totalMin };
      g.clock.totalMin = 14 * 1440 + 23 * 60; // день 15 (зима), 23:00 (ночь)
      res.C_winter = g.clock.isWinter && g.clock.isNight;
      // пешка дальше всех от костра
      let far = g.pawns[0];
      let fd = -1;
      for (const p of g.pawns) {
        if (p.dead) continue;
        const d = Math.hypot(p.x - base.x, p.y - base.y);
        if (d > fd) { fd = d; far = p; }
      }
      res.C_pawn = far.name;
      res.C_dist = Math.round(fd * 10) / 10;
      let warmStarted = false;
      for (let k = 0; k < 40; k++) {
        await sleep(1000);
        if (far.dead) break;
        if (far.hasMod('cold') && (far.job?.kind === 'warm' || far.state === 'move')) { warmStarted = true; break; }
        // updateCold сам добавит мод на зимней ночи; если пешка спит — ждём
      }
      res.C_warmStarted = warmStarted;
      res.C_mod = far.hasMod('cold');
      res.C_job = far.job ? far.job.kind : null;
      let warmed = false;
      for (let k = 0; k < 90; k++) {
        await sleep(1000);
        if (far.dead) break;
        if (!far.hasMod('cold')) { warmed = true; break; }
      }
      res.C_warmedUp = warmed;
      res.C_jobAfter = far.job ? far.job.kind : null;
      res.C_time = { from: before.totalMin, to: Math.floor(g.clock.totalMin), hhmm: g.clock.hhmm, day: g.clock.day };
      res.done = true;
    } catch (e) {
      res.error = String(e && e.stack || e);
      res.done = true;
    }
  }
  run();
})();
'test started';

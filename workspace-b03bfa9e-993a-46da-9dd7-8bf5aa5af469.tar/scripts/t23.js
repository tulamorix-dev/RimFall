(function(){
  const btns = [...document.querySelectorAll('button')].filter((b) => b.innerText.includes('Охота'));
  const catBtn = btns.find((b) => b.className.includes('h-[46px]'));
  if (catBtn) { catBtn.click(); return 'cat open'; }
  return 'not found: ' + btns.length;
})()

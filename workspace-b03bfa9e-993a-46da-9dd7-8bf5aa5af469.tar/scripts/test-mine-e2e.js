// E2E: полный цикл шахты (постройка -> выработка -> склад)
(function () {
  const g = window.__game;
  const res = { started: true };
  window.__t13 = res;
  const BType = { Mine: 10 };
  const Terrain = { Water: 2, Stone: 3 };
  const Obj = { Rock: 2 };
  const Res = { Wood: 0, Iron: 8 };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function run() {
    try {
      const w = g.world;
      g.setSpeed(8);

      // чистая клетка скалы с проходимым соседом
      let spot = null;
      outer: for (let y = 2; y < 62; y++) {
        for (let x = 2; x < 62; x++) {
          const i = y * 64 + x;
          if (w.terrain[i] !== Terrain.Stone) continue;
          if (w.obj[i] !== Obj.Rock && w.obj[i] !== 0) continue;
          if (w.buildingMap.has(i)) continue;
          for (let dy = -1; dy <= 1; dy++)
            for (let dx = -1; dx <= 1; dx++) {
              const nx = x + dx, ny = y + dy;
              if (!w.inBounds(nx, ny)) continue;
              if (w.passPawn(nx, ny) && !w.buildingMap.has(ny * 64 + nx)) {
                // достижима ли клетка из лагеря? грубая проверка не нужна: генерация гарантирует
                spot = { x, y, free: [nx, ny] };
                break outer;
              }
            }
        }
      }
      res.spot = spot;

      g.placeBlueprintAt(BType.Mine, spot.x, spot.y);
      const bp = w.buildingMap.get(spot.y * 64 + spot.x);
      res.blueprint = !!bp;
      if (!bp) { res.error = 'no blueprint'; return; }
      const [fx, fy] = spot.free;
      w.addItem(Res.Wood, 8, fx, fy);

      // ждём достройку до 90с
      for (let t = 0; t < 180; t++) {
        await sleep(500);
        const b = w.buildingMap.get(spot.y * 64 + spot.x);
        if (b && !b.blueprint) { res.builtAfter = t * 0.5; break; }
      }
      const b2 = w.buildingMap.get(spot.y * 64 + spot.x);
      res.built = !!b2 && !b2.blueprint;
      if (!res.built) { res.error = 'not built'; return; }

      // ждём выработку (кулдаун 150 игромин + работа 55 игромин)
      const iron0 = w.countRes(Res.Iron);
      for (let t = 0; t < 300; t++) {
        await sleep(500);
        if (w.countRes(Res.Iron) > iron0) { res.firstYieldAfter = t * 0.5; break; }
      }
      res.iron = w.countRes(Res.Iron) - iron0;
      const b3 = w.buildingMap.get(spot.y * 64 + spot.x);
      res.mineCd = b3 && b3.mineCd;
      res.ok = res.built && res.iron > 0;
    } catch (e) {
      res.error = String(e && e.stack ? e.stack : e);
    }
  }
  run();
})();

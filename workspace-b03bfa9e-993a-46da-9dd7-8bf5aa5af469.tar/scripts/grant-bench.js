// Даём верстак через вкладку «Мир» → заказы → проверка
(() => {
  const click = (pred) => {
    const b = [...document.querySelectorAll('button')].find(pred);
    if (!b) return false;
    b.click();
    return true;
  };
  const log = {};
  // вкладка Мир
  log.tab = click((x) => x.textContent.includes('Мир') && x.className.includes('flex-1'));
  // открыть сетку построек
  log.spawn = click((x) => x.textContent.includes('+ Построить здание'));
  // верстак
  log.bench = click((x) => x.textContent.includes('Верстак') && x.className.includes('flex-col'));
  const g = window.__game;
  const wb = g.world.buildings.find((b) => b.type === 4);
  log.hasBench = !!wb;
  if (wb) {
    // дефолтные заказы (копьё×2, лук×1) уже есть; добавим мечей
    g.addBill(wb.id, 2, 3);
    log.bills = wb.bills.map((b) => b.recipe);
  }
  return JSON.stringify(log);
})();

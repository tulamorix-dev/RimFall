// Что на тайле 1699 (cook) и где костёр
(() => {
  const g = window.__game;
  const r = {};
  const fires = g.world.buildings.filter((b) => b.type === 3);
  r.fires = fires.map((f) => ({ x: f.x, y: f.y, tile: g.world.idx(f.x, f.y), terrain: g.world.terrain[g.world.idx(f.x, f.y)], blueprint: f.blueprint }));
  r.tile1699 = { x: 1699 % 64, y: (1699 / 64) | 0, terrain: g.world.terrain[1699], obj: g.world.obj[1699], zone: g.world.zone[1699], inBuildingMap: g.world.buildingMap.has(1699) };
  // пешки рядом?
  r.pawnTiles = g.pawns.map((p) => g.world.terrain[g.world.idx(Math.floor(p.x), Math.floor(p.y))]);
  return JSON.stringify(r);
})();

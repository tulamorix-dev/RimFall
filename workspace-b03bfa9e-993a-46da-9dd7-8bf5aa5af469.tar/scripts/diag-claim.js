// Диагностика: почему пешки не берут задачи
(() => {
  const g = window.__game;
  const r = {};
  const pawn = g.pawns[0];
  r.aiT = pawn.aiT;
  r.priorities = pawn.priorities;
  r.jobsOnBoard = [...g.jobs.jobs.values()].map((j) => j.kind + ':' + (j.recipe ?? j.tile)).slice(0, 12);
  r.jobCount = g.jobs.jobs.size;
  // пробуем claim вручную
  const ext = {
    alive: 3,
    meals: g.world.countRes(5),
    food: g.world.countRes(2),
    spears: 0,
    bows: 0,
    swords: 0,
    coats: 0,
    leathers: 0,
    irons: 0,
    hunt: [],
  };
  const job = g.jobs.claim(g.world, pawn, performance.now(), ext);
  r.manualClaim = job ? job.kind + ':' + (job.recipe ?? '') : 'null';
  return JSON.stringify(r);
})();

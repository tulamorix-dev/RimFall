// buildingId cook job + все здания
(() => {
  const g = window.__game;
  const jobs = [...g.jobs.jobs.values()].map((j) => ({ id: j.id, kind: j.kind, tile: j.tile, bid: j.buildingId ?? null, item: j.itemId ?? null }));
  const blds = g.world.buildings.map((b) => ({ id: b.id, type: b.type, x: b.x, y: b.y, tile: g.world.idx(b.x, b.y) }));
  return JSON.stringify({ jobs, blds });
})();

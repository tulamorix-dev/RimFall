// Комплексная верификация: кусты, авто-уборка, кровать, погребение, 8x
(function () {
  const g = window.__game;
  const r = window.__renderer;
  const res = {};

  // ---------- 1. КУСТЫ: рубка через инструмент ----------
  // найти куст
  let bushIdx = -1;
  for (let i = 0; i < g.world.obj.length; i++) {
    if (g.world.obj[i] === 3) { bushIdx = i; break; }
  }
  res.bushFound = bushIdx >= 0;
  if (bushIdx >= 0) {
    const bx = bushIdx % 64, by = (bushIdx / 64) | 0;
    g.tool = 'chop';
    g.applyTap(bx + 0.5, by + 0.5);
    res.bushDesignated = !!g.desig.chop[bushIdx];
    // прямой вызов цепочки работы (пешка рядом не обязательно — проверяем API)
    const jobBefore = Array.from(g.jobs.jobs.values()).filter(j => j.kind === 'chop').length;
    g.jobs.refresh(g.world, g.desig, g.realNow, g.canHaul());
    const jobAfter = Array.from(g.jobs.jobs.values()).filter(j => j.kind === 'chop' && j.tile === bushIdx).length;
    res.bushJobCreated = jobAfter > 0;
    void jobBefore;
    // убрать desig, чтобы не мешал дальнейшим тестам
    g.desig.chop[bushIdx] = 0;
    g.jobs.removeByTile('chop', bushIdx);
  }

  // ---------- 2. АВТО-УБОРКА куста при постройке ----------
  let bush2 = -1;
  for (let i = 0; i < g.world.obj.length; i++) {
    if (g.world.obj[i] === 3) { bush2 = i; break; }
  }
  if (bush2 >= 0) {
    const x2 = bush2 % 64, y2 = (bush2 / 64) | 0;
    g.placeBlueprintAt(0 /* Wall */, x2, y2);
    res.autoClear = { bushGone: g.world.obj[bush2] === 0, blueprintPlaced: g.world.buildingMap.has(bush2) };
    // убрать чертёж
    const b = g.world.buildingMap.get(bush2);
    if (b) { g.world.removeBuilding(b); g.jobs.removeByTile('build', bush2); }
  } else {
    res.autoClear = 'no second bush found';
  }

  // ---------- 3. КРОВАТЬ: сон в кровати ----------
  // построить готовую кровать рядом с базой
  const p0 = g.pawns.find(pp => !pp.dead);
  const bedX = Math.floor(p0.x) + 1, bedY = Math.floor(p0.y);
  const { createBlueprint } = {};
  // создаём кровать напрямую (готовую)
  const bedTile = bedY * 64 + bedX;
  const free = g.world.obj[bedTile] === 0 && !g.world.buildingMap.has(bedTile) && g.world.zone[bedTile] === 0 && g.world.terrain[bedTile] !== 2;
  res.bedSpotFree = free;
  if (free) {
    const bp = g.placeBlueprintAt ? null : null;
    // через блюпринт + мгновенное завершение
    g.placeBlueprintAt(2 /* Bed */, bedX, bedY);
    const bb = g.world.buildingMap.get(bedTile);
    if (bb) {
      bb.blueprint = false;
      bb.matHave = bb.matNeed;
      g.dirtyTiles.add(bedTile);
      res.bedBuilt = true;
    }
    // ночь + усталость
    g.clock.totalMin = 3 * 1440 + 22 * 60 + 30; // день 3, 22:30
    p0.rest = 40;
    p0.x = bedX + 3; p0.y = bedY + 3; // рядом
    // вызвать решение AI
    decidePawnProxy(g, p0);
    res.sleepDecision = {
      state: p0.state,
      jobKind: p0.job ? p0.job.kind : null,
      goingToBed: !!(p0.job && p0.job.kind === 'sleep' && p0.job.buildingId !== undefined),
      groundSleep: !!(p0.job && p0.job.ground),
    };
    // довести: тикать до засыпания
    let guard = 0;
    while (p0.state !== 'sleep' && guard++ < 400) { g.tick(0.05); }
    res.sleepResult = {
      asleep: p0.state === 'sleep',
      atBedTile: Math.floor(p0.x) === bedX && Math.floor(p0.y) === bedY,
      inBed: !!(p0.job && !p0.job.ground),
      bedOwner: bb ? bb.ownerId : null,
      expectedOwner: p0.id,
    };
    // разбудить для дальнейших тестов
    p0.state = 'idle'; p0.job = null; p0.rest = 90;
    g.clock.totalMin = 3 * 1440 + 10 * 60;
  }

  // ---------- 4. ПОГРЕБЕНИЕ ----------
  // положить труп
  const cx = Math.floor(p0.x) + 2, cy = Math.floor(p0.y);
  const corpse = g.world.addItem(4 /* Corpse */, 1, cx, cy);
  corpse.name = 'Тестовый';
  corpse.decay = 2880;
  res.corpsePlaced = true;
  // тап осмотра по трупу
  g.tool = 'inspect';
  g.applyTap(cx + 0.5, cy + 0.5);
  res.corpseInfo = g.selectedInfo ? {
    hasBury: g.selectedInfo.buryItemId === corpse.id,
    line: g.selectedInfo.lines.find(l => l.startsWith('Тело')),
  } : 'no info';
  // приказ похоронить
  const ordered = g.orderBurial(corpse.id);
  res.burialOrdered = ordered;
  const buryJob = Array.from(g.jobs.jobs.values()).find(j => j.kind === 'bury' && j.itemId === corpse.id);
  res.buryJobOnBoard = !!buryJob;
  // симулируем: пешка заберёт работу
  p0.x = cx + 1; p0.y = cy;
  if (buryJob) {
    // забрать работу вручную пешкой
    buryJob.claimedBy = p0.id;
    // эмулируем старт через startBoardJob недоступен — вызовем через claim-путь: очистим другие jobs у пешки и пусть AI
  }
  let guard2 = 0;
  while (!corpseDeadOrGone() && guard2 < 2000) { g.tick(0.05); }
  function corpseDeadOrGone() { return !g.world.items.some(it => it.id === corpse.id); }
  res.burialDone = !g.world.items.some(it => it.id === corpse.id);
  res.burialMood = p0.mods.find(m => m.id === 'burial') ? p0.mods.find(m => m.id === 'burial').label : null;
  res.burialStory = g.events.entries.slice(-3).map(e => e.text);

  // ---------- 5. СКОРОСТЬ 8x ----------
  g.setSpeed(8);
  res.speed8 = g.clock.speed;
  g.setSpeed(1);

  // ---------- 6. Навык медицины ----------
  res.medicineSkill = !!g.pawns.find(pp => !pp.dead && pp.skills.medicine !== undefined);

  return JSON.stringify(res);
})()

function decidePawnProxy(g, p) {
  // decidePawn не экспортирован на window — вызовем через внутренний тик:
  // подменим aiT чтобы решатель сработал немедленно
  p.aiT = 0;
}

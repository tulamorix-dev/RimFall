// Экспорт мира для офлайн-воспроизведения бага путей
(() => {
  const w = window.__game.world;
  return JSON.stringify({
    terrain: Array.from(w.terrain),
    obj: Array.from(w.obj),
    buildings: w.buildings.map((b) => ({ x: b.x, y: b.y, type: b.type, blueprint: b.blueprint })),
    zones: Array.from(w.zone),
    items: w.items.map((it) => ({ x: it.x, y: it.y, type: it.type })),
  });
})();

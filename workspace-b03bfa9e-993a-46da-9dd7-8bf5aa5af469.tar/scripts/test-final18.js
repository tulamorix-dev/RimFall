// E2E Task 18 (финал): разрыв боя с недостижимой целью + чистая охота + resume охоты
(function () {
  const g = window.__game;
  const res = { started: true };
  window.__t18g = res;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const logHas = (t) => g.events.entries.some((e) => e.text.includes(t));
  // спавн дичи только в КОНТРОЛЬНО достижимую точку (BFS до лагеря, как у спавнеров игры)
  function spawnReachableDeer(nearX, nearY) {
    const w = g.world;
    const MAP = 64;
    for (let t = 0; t < 60; t++) {
      const ang = (Math.PI * 2 * t) / 17;
      const r = 5 + (t % 4);
      const x = Math.max(2, Math.min(61, Math.round(nearX + Math.cos(ang) * r)));
      const y = Math.max(2, Math.min(61, Math.round(nearY + Math.sin(ang) * r)));
      if (!w.passAnimal(x, y)) continue;
      // BFS 4-напр от кандидата до окрестности лагеря
      const seen = new Uint8Array(MAP * MAP);
      const q = [y * MAP + x];
      seen[q[0]] = 1;
      let head = 0, ok = false;
      while (head < q.length) {
        const cur = q[head++];
        const cx = cur % MAP, cy = (cur / MAP) | 0;
        if (Math.abs(cx - g.spawnX) <= 6 && Math.abs(cy - g.spawnY) <= 6) { ok = true; break; }
        for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
          const nx = cx + dx, ny = cy + dy;
          if (nx < 1 || ny < 1 || nx >= 63 || ny >= 63) continue;
          const ni = ny * MAP + nx;
          if (seen[ni] || !w.passAnimal(nx, ny)) continue;
          seen[ni] = 1; q.push(ni);
        }
      }
      if (ok) return g.spawnAnimal('deer', x + 0.5, y + 0.5);
    }
    return null;
  }

  async function run() {
    try {
      g.setSpeed(0);
      const w = g.world;
      const sc = w.stockpileCenter() ?? { x: g.spawnX, y: g.spawnY };
      const pawns = g.pawns.filter((p) => !p.dead);
      const p1 = pawns[1];
      // убрать хищников из игры (чистый эксперимент)
      g.animals.filter((a) => a.kind === 'wolf' || a.kind === 'bear' || a.kind === 'boar').forEach((a) => g.removeAnimal(a));

      // ===== 1. РАЗРЫВ БОЯ: зверь заперт кольцом деревьев =====
      p1.food = 90; p1.rest = 90; p1.hp = 100; p1.mods = []; p1.inv = null;
      p1.x = sc.x + 0.5; p1.y = sc.y + 0.5; p1.path = null; p1.job = null; p1.state = 'idle'; p1.resumeRef = undefined;
      const rabbit = g.spawnAnimal('rabbit', sc.x + 6.5, sc.y + 6.5);
      const rx = Math.floor(sc.x) + 6, ry = Math.floor(sc.y) + 6;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (Math.abs(dx) + Math.abs(dy) === 0) continue;
        w.obj[w.idx(rx + dx, ry + dy)] = 1; // Tree — стена
      }
      w.obj[w.idx(rx, ry)] = 0;
      p1.combatTargetId = rabbit.id;
      p1.state = 'fight';
      g.setSpeed(1);
      let waited = 0;
      while (p1.state === 'fight' && waited < 15000) { await sleep(250); waited += 250; }
      res.fightBrokeOff = p1.state !== 'fight';
      res.brokeOffTimeMs = waited;
      res.rabbitAlive = !rabbit.dead;
      // пешка вернулась к жизни: работа/движение, а не ступор
      await sleep(2500);
      res.backToLife = p1.state !== 'fight' && (p1.job !== null || p1.state === 'move' || p1.state === 'idle');
      // убираем экспериментальное деревяное кольцо — иначе оно запрёт дичь из шага 2
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (w.obj[w.idx(rx + dx, ry + dy)] === 1) w.obj[w.idx(rx + dx, ry + dy)] = 0;
      }
      g.renderDirtyTile(rx, ry);

      // ===== 2. ЧИСТАЯ ОХОТА: лук, олень, метка =====
      g.setSpeed(0);
      p1.weapon = 'bow'; // свежий мир: оружия нет, охотнику нужен лук
      p1.state = 'idle'; p1.job = null; p1.path = null; p1.food = 90; p1.rest = 90;
      p1.priorities = ['hunt', 'cook', 'build', 'farm', 'lumber', 'mine', 'haul'];
      const deer = spawnReachableDeer(sc.x + 5, sc.y + 5);
      res.deerSpawned = !!deer;
      if (!deer) throw new Error('не нашли достижимую точку для оленя');
      g.toggleHunt(deer.id);
      g.setSpeed(1);
      waited = 0;
      while (!(p1.job && p1.job.kind === 'hunt') && waited < 15000) { await sleep(250); waited += 250; }
      res.gotHunt = !!(p1.job && p1.job.kind === 'hunt');
      const hp0 = deer.hp;
      waited = 0;
      while (!deer.dead && waited < 60000) { await sleep(500); waited += 500; }
      res.deerKilled = deer.dead;
      res.deerShotAt = deer.hp < hp0;
      await sleep(2000);
      res.meatOrHide = w.countRes(2) + w.countRes(10);

      // ===== 3. RESUME ОХОТЫ ПОСЛЕ СНА =====
      const deer2 = spawnReachableDeer(sc.x + 8, sc.y + 8);
      res.deer2Spawned = !!deer2;
      g.toggleHunt(deer2.id);
      g.setSpeed(0);
      p1.state = 'idle'; p1.job = null; p1.path = null; p1.food = 90; p1.rest = 90;
      g.setSpeed(1);
      waited = 0;
      while (!(p1.job && p1.job.kind === 'hunt') && waited < 15000) { await sleep(250); waited += 250; }
      res.gotHunt2 = !!(p1.job && p1.job.kind === 'hunt');
      // сон посреди охоты
      p1.rest = 4;
      waited = 0;
      while (p1.state !== 'sleep' && waited < 8000) { await sleep(200); waited += 200; }
      res.fellAsleep = p1.state === 'sleep';
      const clock = g.clock;
      const intoDay = clock.totalMin % 1440;
      clock.totalMin += (7 * 60 + 30 - intoDay + 1440) % 1440;
      p1.rest = 90;
      waited = 0;
      while (p1.state === 'sleep' && waited < 8000) { await sleep(200); waited += 200; }
      waited = 0;
      while (!(p1.job && p1.job.kind === 'hunt') && waited < 12000) { await sleep(250); waited += 250; }
      res.resumedHunt = !!(p1.job && p1.job.kind === 'hunt') && p1.job.itemId === deer2.id;
      g.toggleHunt(deer2.id);
      g.setSpeed(1);
    } catch (e) {
      res.error = String(e && e.stack ? e.stack : e);
    }
    res.done = true;
  }
  run();
})();

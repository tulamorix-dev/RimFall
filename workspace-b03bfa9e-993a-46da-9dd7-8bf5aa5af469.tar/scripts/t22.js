(function(){
  const findBtnByText = (t) => [...document.querySelectorAll('button')].find((b) => b.innerText.includes(t));
  const b = findBtnByText('Приказы'); if (b) b.click();
  return b ? 'orders open' : 'no cat';
})()

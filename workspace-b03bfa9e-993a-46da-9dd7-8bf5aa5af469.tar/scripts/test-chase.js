// E2E Task 18 (фаза 3): трассировка погони охотника за дичью
(function () {
  const g = window.__game;
  const res = { started: true, trace: [] };
  window.__t18c = res;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function run() {
    try {
      g.setSpeed(0);
      const w = g.world;
      const sc = w.stockpileCenter() ?? { x: g.spawnX, y: g.spawnY };
      const p1 = g.pawns[1];
      p1.state = 'idle'; p1.job = null; p1.path = null; p1.resumeRef = undefined;
      p1.food = 90; p1.rest = 90; p1.hp = 100; p1.mods = [];
      p1.x = sc.x + 0.5; p1.y = sc.y + 0.5;
      p1.priorities = ['hunt', 'cook', 'build', 'farm', 'lumber', 'mine', 'haul'];
      p1.weapon = 'bow';
      const deer = g.spawnAnimal('deer', sc.x + 5.5, sc.y + 5.5);
      g.toggleHunt(deer.id);
      g.setSpeed(1);
      const t0 = Date.now();
      while (Date.now() - t0 < 40000) {
        res.trace.push({
          t: Math.round((Date.now() - t0) / 100) / 10,
          st: p1.state, jk: p1.job ? p1.job.kind : null,
          px: Math.round(p1.x * 10) / 10, py: Math.round(p1.y * 10) / 10,
          dx: Math.round(deer.x * 10) / 10, dy: Math.round(deer.y * 10) / 10,
          dd: Math.round(Math.hypot(deer.x - p1.x, deer.y - p1.y) * 10) / 10,
          dh: Math.round(Math.max(Math.abs(deer.x - p1.x), Math.abs(deer.y - p1.y)) * 10) / 10,
          dhp: deer.hp, dead: deer.dead
        });
        if (deer.dead) break;
        await sleep(700);
      }
      res.finalDead = deer.dead;
      // держим игру живой
      g.setSpeed(1);
    } catch (e) {
      res.error = String(e && e.stack ? e.stack : e);
    }
    res.done = true;
  }
  run();
})();

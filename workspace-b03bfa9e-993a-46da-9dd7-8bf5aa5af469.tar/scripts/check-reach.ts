// Проверка: на каждом сиде руда/горы/руины достижимы из старта
import { generateWorld } from '../src/game/world/mapgen.ts';
import { World, } from '../src/game/world/world.ts';
import { MAP, Obj, Terrain } from '../src/game/data/defs.ts';

const DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];

function reachFlood(w: World, sx: number, sy: number): Uint8Array {
  const seen = new Uint8Array(MAP * MAP);
  const blocked = (x: number, y: number) => w.terrain[y * MAP + x] === Terrain.Water;
  if (blocked(sx, sy)) return seen;
  seen[sy * MAP + sx] = 1;
  const q = [sy * MAP + sx];
  while (q.length) {
    const c = q.pop()!;
    const cx = c % MAP, cy = (c / MAP) | 0;
    for (const [dx, dy] of DIRS) {
      const nx = cx + dx, ny = cy + dy;
      if (!w.inBounds(nx, ny)) continue;
      const ni = ny * MAP + nx;
      if (seen[ni] || blocked(nx, ny)) continue;
      if (dx !== 0 && dy !== 0 && (blocked(cx + dx, cy) || blocked(cx, cy + dy))) continue;
      seen[ni] = 1;
      q.push(ni);
    }
  }
  return seen;
}

let bad = 0;
let worstOre = 99;
for (let seed = 1; seed <= 20; seed++) {
  const s = seed * 1337;
  const w = new World();
  const r = generateWorld(w, s);
  const seen = reachFlood(w, r.spawnX, r.spawnY);
  let ore = 0, oreOk = 0, ruins = 0, ruinsOk = 0, stone = 0, stoneOk = 0;
  for (let i = 0; i < MAP * MAP; i++) {
    const x = i % MAP, y = (i / MAP) | 0;
    let adj = false;
    for (const [dx, dy] of DIRS) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx > 63 || ny > 63) continue;
      if (seen[ny * MAP + nx]) { adj = true; break; }
    }
    if (w.obj[i] === Obj.Ore) { ore++; if (adj || seen[i]) oreOk++; }
    if (w.terrain[i] === Terrain.Stone) { stone++; if (adj || seen[i]) stoneOk++; }
    if (w.itemMap.has(i) && w.items.some((it) => it.x === x && it.y === y && it.type === 3)) { ruins++; if (adj) ruinsOk++; }
  }
  const ok = oreOk === ore && ruinsOk === ruins;
  if (oreOk / ore < worstOre) worstOre = oreOk / ore;
  if (!ok) bad++;
  console.log(`seed ${s}: ore ${oreOk}/${ore} ruins ${ruinsOk}/${ruins} stoneAdj ${stoneOk}/${stone} ${ok ? 'OK' : 'FAIL'}`);
}
console.log(bad === 0 ? 'ALL SEEDS OK' : `${bad} seeds FAIL`, 'worst ore ratio:', worstOre.toFixed(2));

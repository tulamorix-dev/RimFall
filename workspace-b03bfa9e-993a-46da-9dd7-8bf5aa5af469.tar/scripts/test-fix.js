// Комплексная проверка: рамка рубки, тап-рубка, рамка склада
(function () {
  const g = window.__game;
  const r = window.__renderer;
  const c = r.canvas;
  const res = {};

  function pev(type, x, y, id) {
    const rect = c.getBoundingClientRect();
    c.dispatchEvent(new PointerEvent(type, {
      pointerId: id, pointerType: 'touch', isPrimary: true,
      clientX: rect.left + x, clientY: rect.top + y,
      button: 0, buttons: type === 'pointerup' ? 0 : 1, bubbles: true,
    }));
  }
  function w2s(wx, wy) { // мировые тайлы -> экранные px
    return {
      x: (wx * 32 - r.cam.x) * r.cam.zoom + r.viewW / 2,
      y: (wy * 32 - r.cam.y) * r.cam.zoom + r.viewH / 2,
    };
  }

  // найти дерево рядом с базой
  let tx = -1, ty = -1, bestD = 1e9;
  for (let i = 0; i < g.world.obj.length; i++) {
    if (g.world.obj[i] === 1) {
      const x = i % 64, y = (i / 64) | 0;
      const d = (x - 24) * (x - 24) + (y - 27) * (y - 27);
      if (d < bestD) { bestD = d; tx = x; ty = y; }
    }
  }
  res.tree = { tx, ty };
  r.cam.x = tx * 32; r.cam.y = ty * 32; r.cam.zoom = 1.5; r.cam.followId = null;
  r.cam.clampToMap();
  r.viewW = c.clientWidth; r.viewH = c.clientHeight;

  // --- Тест 1: рамка рубки ---
  g.tool = 'chop';
  g.clearSelection();
  const a = w2s(tx - 1, ty - 1), b = w2s(tx + 1, ty + 1);
  pev('pointerdown', a.x, a.y, 21);
  pev('pointermove', (a.x + b.x) / 2, (a.y + b.y) / 2, 21);
  pev('pointerup', b.x, b.y, 21);
  res.t1_dragChop = { desig: Array.from(g.desig.chop).filter(v => v > 0).length };

  // --- Тест 2: тап-рубка (новое поведение) ---
  g.clearSelection();
  const t = w2s(tx + 0.5, ty + 0.5);
  pev('pointerdown', t.x, t.y, 22);
  pev('pointerup', t.x, t.y, 22);
  res.t2_tapChop = { desig: Array.from(g.desig.chop).filter(v => v > 0).length };

  // --- Тест 3: рамка склада ---
  g.tool = 'stockpile';
  g.clearSelection();
  // свободное место вокруг дерева (сами клетки дерева не подходят, берём область рядом)
  const sx0 = tx + 2, sy0 = ty, sx1 = tx + 5, sy1 = ty + 2;
  const c0 = w2s(sx0, sy0), c1 = w2s(sx1, sy1);
  const zoneBefore = Array.from(g.world.zone).filter(v => v === 1).length;
  pev('pointerdown', c0.x, c0.y, 23);
  pev('pointermove', (c0.x + c1.x) / 2, (c0.y + c1.y) / 2, 23);
  pev('pointerup', c1.x, c1.y, 23);
  const zoneAfter = Array.from(g.world.zone).filter(v => v === 1).length;
  res.t3_stockpile = { before: zoneBefore, after: zoneAfter, added: zoneAfter - zoneBefore };

  // --- Тест 4: инспект-тап по пешке ---
  g.tool = 'inspect';
  const p = g.pawns.find(pp => !pp.dead);
  r.cam.x = p.x * 32; r.cam.y = p.y * 32; r.cam.clampToMap();
  const ps = w2s(p.x, p.y);
  pev('pointerdown', ps.x, ps.y, 24);
  pev('pointerup', ps.x, ps.y, 24);
  res.t4_selectPawn = { selected: g.selectedPawnId };

  g.clearSelection();
  g.tool = 'inspect';
  return JSON.stringify(res);
})()

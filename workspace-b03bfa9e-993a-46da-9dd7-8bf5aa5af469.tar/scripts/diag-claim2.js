// Репликация claim() по шагам: кто и почему не берётся
(() => {
  const g = window.__game;
  const pawn = g.pawns[0];
  const out = [];
  for (const job of g.jobs.jobs.values()) {
    const rec = {
      id: job.id,
      kind: job.kind,
      cat: job.cat,
      claimedBy: job.claimedBy,
      tile: job.tile,
      recipe: job.recipe ?? null,
    };
    const prioIdx = pawn.priorities.indexOf(job.cat);
    rec.prioIdx = prioIdx;
    const tx = job.tile % 64;
    const ty = (job.tile / 64) | 0;
    rec.dist = Math.round(Math.hypot(tx - pawn.x, ty - pawn.y) * 10) / 10;
    rec.terrain = g.world.terrain[job.tile];
    out.push(rec);
  }
  return JSON.stringify(out);
})();

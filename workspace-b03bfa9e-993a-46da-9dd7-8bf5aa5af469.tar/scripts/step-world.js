// Шаг 1: открыть вкладку Мир и подождать, затем вернуть состояние
(() => {
  const b = [...document.querySelectorAll('button')].find((x) => x.textContent.includes('Мир') && x.className.includes('flex-1'));
  if (b) b.click();
  return 'world tab clicked';
})();

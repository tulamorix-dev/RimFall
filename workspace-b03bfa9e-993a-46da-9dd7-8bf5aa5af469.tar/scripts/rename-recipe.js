// Переименование рецепта через Field (React onBlur = focusout)
(() => {
  const inp = [...document.querySelectorAll('input')].find(
    (x) => x.closest('label') && x.closest('label').textContent.includes('Название'),
  );
  if (!inp) return 'no name input';
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  setter.call(inp, 'Топор охотника');
  inp.dispatchEvent(new Event('input', { bubbles: true }));
  inp.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
  return 'renamed';
})();

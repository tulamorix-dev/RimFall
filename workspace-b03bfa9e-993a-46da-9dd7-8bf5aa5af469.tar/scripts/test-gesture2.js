// Инструментировка applyRect + повтор жеста
(function () {
  const g = window.__game;
  const r = window.__renderer;
  const c = r.canvas;

  const log = [];
  const origApplyRect = g.applyRect.bind(g);
  g.applyRect = function (x0, y0, x1, y1) {
    log.push({ fn: 'applyRect', args: [x0, y0, x1, y1] });
    return origApplyRect(x0, y0, x1, y1);
  };
  window.__applyRectLog = log;

  g.tool = 'chop';
  g.clearSelection();

  // дерево (21,26), камера уже наведена (zoom 1.5)
  const tx = 21, ty = 26;
  r.cam.x = tx * 32; r.cam.y = ty * 32; r.cam.zoom = 1.5; r.cam.followId = null;
  r.cam.clampToMap();
  r.viewW = c.clientWidth; r.viewH = c.clientHeight;

  const s0 = { x: ((tx - 1) * 32 - r.cam.x) * r.cam.zoom + r.viewW / 2, y: ((ty - 1) * 32 - r.cam.y) * r.cam.zoom + r.viewH / 2 };
  const s1 = { x: ((tx + 1) * 32 - r.cam.x) * r.cam.zoom + r.viewW / 2, y: ((ty + 1) * 32 - r.cam.y) * r.cam.zoom + r.viewH / 2 };
  const rect = c.getBoundingClientRect();

  function pev(type, x, y, id) {
    c.dispatchEvent(new PointerEvent(type, {
      pointerId: id, pointerType: 'touch', isPrimary: true,
      clientX: rect.left + x, clientY: rect.top + y,
      button: 0, buttons: type === 'pointerup' ? 0 : 1, bubbles: true,
    }));
  }

  pev('pointerdown', s0.x, s0.y, 9);
  pev('pointermove', (s0.x + s1.x) / 2, (s0.y + s1.y) / 2, 9);
  pev('pointerup', s1.x, s1.y, 9);

  return JSON.stringify({
    log,
    gesture: r.gesture,
    rectStart: r.rectStart,
    desigAfter: Array.from(g.desig.chop).filter(v => v > 0).length,
    treeObj: g.world.obj[ty * 64 + tx],
  });
})()

// E2E: верхняя панель — выпадающий список скорости, пауза-меню (сохранить/загрузить/настройки)
(function () {
  const g = window.__game;
  const res = { started: true };
  window.__t14 = res;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const $aria = (l) => document.querySelector(`[aria-label="${l}"]`);
  const click = (el) => el && el.click();
  const bodyHas = (t) => document.body.innerText.includes(t);
  const findBtnByText = (t) => [...document.querySelectorAll('button')].find((b) => b.innerText.includes(t));

  async function run() {
    try {
      g.setSpeed(1);
      // детерминизм: сброс настройки (сессия могла загрузиться со старого сейва)
      g.gameSettings.autopauseAlarm = false;

      // 1) Выпадающий список скорости
      click($aria('Скорость игры'));
      await sleep(150);
      const dropItems = [...document.querySelectorAll('button')].filter((b) => /^\s*(▶|≫|⏸)/.test(b.innerText) && /×|Пауза/.test(b.innerText) && b.closest('.absolute'));
      res.dropdownItems = dropItems.length;
      click(findBtnByText('×4'));
      await sleep(150);
      res.speed4 = g.clock.speed === 4;
      if (!res.speed4) { res.error = 'speed4 fail, items=' + res.dropdownItems; return; }

      // 2) Кнопка паузы = пауза + меню
      click($aria('Пауза и меню игры'));
      await sleep(200);
      res.paused = g.clock.speed === 0;
      res.menuOpen = bodyHas('Загрузить игру') && bodyHas('Настройки игры');
      if (!res.paused || !res.menuOpen) { res.error = 'pause-menu fail'; return; }

      // 3) Настройки: включить автопаузу на тревогу
      click(findBtnByText('Настройки игры'));
      await sleep(150);
      res.settingsView = bodyHas('Автосохранение') && bodyHas('Автопауза на тревогу');
      const alarmRow = [...document.querySelectorAll('button')].find((b) => b.innerText.includes('Автопауза на тревогу'));
      click(alarmRow);
      await sleep(100);
      res.alarmOn = g.gameSettings.autopauseAlarm === true;
      click(findBtnByText('Назад'));
      await sleep(150);

      // 4) Сохранить
      const T0 = Math.round(g.clock.totalMin);
      click(findBtnByText('Сохранить игру'));
      await sleep(400);
      res.savedToast = bodyHas('Игра сохранена');

      // 5) Продолжить, промотать время
      click(findBtnByText('Продолжить'));
      await sleep(150);
      res.menuClosed = !bodyHas('Загрузить игру');
      g.setSpeed(4);
      await sleep(3000);
      res.timeAdvanced = g.clock.totalMin > T0 + 10;
      g.setSpeed(0);

      // 6) Загрузить — время откатывается к T0
      click($aria('Пауза и меню игры'));
      await sleep(200);
      click(findBtnByText('Загрузить игру'));
      await sleep(500);
      const T1 = Math.round(g.clock.totalMin);
      res.loadedPaused = g.clock.speed === 0;
      res.loadedToast = bodyHas('Игра загружена');
      res.timeRestored = Math.abs(T1 - T0) <= 1;
      res.menuClosedAfterLoad = !bodyHas('Загрузить игру');
      res.settingsAfterLoad = g.gameSettings.autopauseAlarm === true;

      res.ok = res.dropdownItems === 6 && res.speed4 && res.paused && res.menuOpen && res.settingsView && res.alarmOn &&
        res.savedToast && res.menuClosed && res.timeAdvanced && res.loadedToast && res.loadedPaused && res.timeRestored &&
        res.menuClosedAfterLoad && res.settingsAfterLoad;
    } catch (e) {
      res.error = String(e && e.stack ? e.stack : e);
    }
  }
  run();
})();

(function(){
  const findBtnByText = (t) => [...document.querySelectorAll('button')].find((b) => b.innerText.includes(t));
  const s = findBtnByText('Сохранить игру'); if (s) s.click();
  return s ? 'saving' : 'no save btn';
})()

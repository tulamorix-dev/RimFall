// BFS с запретом срезания углов (как в A*) — найти реальные разрывы
import { readFileSync } from 'fs';
import { MAP, BType } from '../src/game/data/defs.ts';
import { World } from '../src/game/world/world.ts';

const raw = JSON.parse(readFileSync(new URL('./world-dump.json', import.meta.url), 'utf8'));
const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
const w = new World();
w.terrain.set(data.terrain);
w.obj.set(data.obj);
for (const b of data.buildings) {
  w.placeBuilding({ id: 1, x: b.x, y: b.y, type: b.type as BType, blueprint: b.blueprint, hp: 1, maxHp: 1, matType: 0, matNeed: 1, matHave: 0, workNeed: 1, workHave: 0, ownerId: null } as never);
}

const DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
const pass = (x: number, y: number) => w.passPawn(x, y);

function strictFlood(sx: number, sy: number): Uint8Array {
  const seen = new Uint8Array(MAP * MAP);
  const start = sy * MAP + sx;
  if (!pass(sx, sy)) return seen;
  seen[start] = 1;
  const q = [start];
  while (q.length) {
    const c = q.shift()!;
    const cx = c % MAP, cy = (c / MAP) | 0;
    for (const [dx, dy] of DIRS) {
      const nx = cx + dx, ny = cy + dy;
      if (!w.inBounds(nx, ny)) continue;
      const ni = ny * MAP + nx;
      if (seen[ni]) continue;
      if (!pass(nx, ny)) continue;
      if (dx !== 0 && dy !== 0) {
        if (!pass(cx + dx, cy) || !pass(cx, cy + dy)) continue;
      }
      seen[ni] = 1;
      q.push(ni);
    }
  }
  return seen;
}

const seen = strictFlood(35, 33);
let reachableOre = 0, totalOre = 0, reachableStone = 0, totalStone = 0;
const unreachableOre: number[] = [];
for (let i = 0; i < MAP * MAP; i++) {
  if (data.obj[i] === 5) {
    totalOre++;
    if (seen[i]) reachableOre++;
    else unreachableOre.push(i);
  }
  if (data.terrain[i] === 3) {
    totalStone++;
    if (seen[i]) reachableStone++;
  }
}
console.log('ore reachable:', reachableOre + '/' + totalOre, 'stone reachable:', reachableStone + '/' + totalStone);
console.log('unreachable ore cells:', unreachableOre.slice(0, 20).map((i) => (i % MAP) + ',' + ((i / MAP) | 0)).join(' '));
// достижима ли клетка рядом с шахтой (56,5)?
let anyAdj = false;
for (const [dx, dy] of DIRS) {
  const nx = 56 + dx, ny = 5 + dy;
  if (w.inBounds(nx, ny) && seen[ny * MAP + nx]) anyAdj = true;
}
console.log('mine (56,5) adjacent reachable:', anyAdj);

// размер связной области от старта
let region = 0;
for (let i = 0; i < MAP * MAP; i++) if (seen[i]) region++;
console.log('reachable region size:', region, '/', MAP * MAP);
// что непроходимо вокруг старта (35,33): окружение 12x12
let blockMap = '';
for (let y = 27; y < 40; y++) {
  let s = '';
  for (let x = 29; x < 42; x++) {
    s += pass(x, y) ? (data.terrain[y * MAP + x] === 3 ? ':' : '.') : (data.terrain[y * MAP + x] === 2 ? '~' : data.obj[y * MAP + x] === 5 ? 'O' : data.obj[y * MAP + x] === 1 ? 'T' : data.obj[y * MAP + x] === 2 ? 'R' : '#');
  }
  blockMap += s + ' | ';
}
console.log('map around start:', blockMap);

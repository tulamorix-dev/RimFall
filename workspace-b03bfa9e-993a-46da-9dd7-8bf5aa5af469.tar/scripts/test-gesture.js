// Тест жеста «прямоугольник выделения» на канвасе (эмуляция пальца)
(function () {
  const g = window.__game;
  const r = window.__renderer;
  const c = r.canvas;
  const out = { steps: [] };

  // 1) выбрать инструмент рубки
  g.tool = 'chop';
  g.clearSelection();

  // 2) найти дерево поблизости от базы и навести камеру
  let tx = -1, ty = -1;
  const bx = 24, by = 27;
  let bestD = 1e9;
  for (let i = 0; i < g.world.obj.length; i++) {
    if (g.world.obj[i] === 1) {
      const x = i % 64, y = (i / 64) | 0;
      const d = (x - bx) * (x - bx) + (y - by) * (y - by);
      if (d < bestD) { bestD = d; tx = x; ty = y; }
    }
  }
  if (tx < 0) { out.error = 'no trees'; return JSON.stringify(out); }
  out.tree = { tx, ty };
  r.cam.x = tx * 32; r.cam.y = ty * 32; r.cam.zoom = 1.5; r.cam.followId = null;
  r.cam.clampToMap();
  r.viewW = c.clientWidth; r.viewH = c.clientHeight;

  // мировые координаты углов прямоугольника вокруг дерева 3x3
  const w0 = { x: tx - 1, y: ty - 1 }, w1 = { x: tx + 1, y: ty + 1 };
  const s0 = {
    x: (w0.x * 32 - r.cam.x) * r.cam.zoom + r.viewW / 2,
    y: (w0.y * 32 - r.cam.y) * r.cam.zoom + r.viewH / 2,
  };
  const s1 = {
    x: (w1.x * 32 - r.cam.x) * r.cam.zoom + r.viewW / 2,
    y: (w1.y * 32 - r.cam.y) * r.cam.zoom + r.viewH / 2,
  };
  out.screen = { s0, s1 };
  const rect = c.getBoundingClientRect();
  out.rect = { left: rect.left, top: rect.top };

  function pev(type, x, y, id) {
    c.dispatchEvent(new PointerEvent(type, {
      pointerId: id, pointerType: 'touch', isPrimary: true,
      clientX: rect.left + x, clientY: rect.top + y,
      button: 0, buttons: type === 'pointerup' ? 0 : 1, bubbles: true,
    }));
  }

  const before = Array.from(g.desig.chop).filter(v => v > 0).length;

  // 3) жест: вниз → движения → вверх
  pev('pointerdown', s0.x, s0.y, 7);
  const midX = (s0.x + s1.x) / 2, midY = (s0.y + s1.y) / 2;
  pev('pointermove', midX, midY, 7);
  out.rectDuringDrag = !!(r.rectStart && r.rectCur);
  pev('pointermove', s1.x, s1.y, 7);
  out.rectDuringDrag2 = !!(r.rectStart && r.rectCur);
  pev('pointerup', s1.x, s1.y, 7);

  const after = Array.from(g.desig.chop).filter(v => v > 0).length;
  out.desigBefore = before;
  out.desigAfter = after;
  out.rectAfter = !!(r.rectStart && r.rectCur);
  out.gestureAfter = r.gesture;
  return JSON.stringify(out);
})()

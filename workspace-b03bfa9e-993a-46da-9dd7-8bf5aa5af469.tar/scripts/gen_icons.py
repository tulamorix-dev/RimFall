# Генерация PWA-иконок «ОСКОЛОК»: оранжевый осколок на тёмном фоне
from PIL import Image, ImageDraw
import os

OUT = "/home/z/my-project/public/icons"
os.makedirs(OUT, exist_ok=True)

BG = (18, 23, 15, 255)        # #12170f
SHARD = (232, 118, 58, 255)   # #e8763a
SHARD_LIGHT = (245, 160, 90, 255)
SHARD_DARK = (180, 80, 35, 255)
GRASS = (77, 124, 66, 255)


def draw_icon(size: int, maskable: bool) -> Image.Image:
    img = Image.new("RGBA", (size, size), BG)
    d = ImageDraw.Draw(img)
    s = size
    if maskable:
        # безопасная зона: контент в центральных 66%
        pad = int(s * 0.17)
    else:
        pad = int(s * 0.10)

    # трава снизу
    ground_h = int(s * 0.10)
    d.rectangle([0, s - ground_h, s, s], fill=GRASS)

    # осколок (треугольный камень) в центре
    cx, cy = s / 2, s / 2 - s * 0.03
    w = s - pad * 2
    pts_main = [
        (cx, cy - w * 0.52),          # вершина
        (cx + w * 0.42, cy + w * 0.10),
        (cx + w * 0.22, cy + w * 0.46),
        (cx - w * 0.26, cy + w * 0.46),
        (cx - w * 0.44, cy + w * 0.08),
    ]
    d.polygon(pts_main, fill=SHARD)

    # грань-блик слева
    pts_light = [
        (cx, cy - w * 0.52),
        (cx - w * 0.44, cy + w * 0.08),
        (cx - w * 0.12, cy - w * 0.02),
    ]
    d.polygon(pts_light, fill=SHARD_LIGHT)

    # тёмная грань справа
    pts_dark = [
        (cx, cy - w * 0.52),
        (cx + w * 0.42, cy + w * 0.10),
        (cx + w * 0.10, cy + w * 0.06),
    ]
    d.polygon(pts_dark, fill=SHARD_DARK)

    # трещина
    d.line(
        [(cx + w * 0.05, cy - w * 0.40), (cx - w * 0.04, cy - w * 0.12), (cx + w * 0.08, cy + w * 0.05), (cx - w * 0.02, cy + w * 0.32)],
        fill=BG,
        width=max(2, int(s * 0.012)),
    )
    return img


for size, name in [(192, "icon-192.png"), (512, "icon-512.png"), (512, "icon-maskable-512.png")]:
    maskable = "maskable" in name
    draw_icon(size, maskable).save(os.path.join(OUT, name))
    print("saved", name)

print("done")

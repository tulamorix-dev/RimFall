// E2E Task 17: охота (🎯), приоритеты работ, конвертация плоского камня в скалы
(function () {
  const g = window.__game;
  const res = { started: true };
  window.__t17 = res;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const bodyHas = (t) => document.body.innerText.includes(t);
  const findBtnByText = (t) => [...document.querySelectorAll('button')].find((b) => b.innerText.includes(t));

  async function run() {
    try {
      // ---------- 1. ГЕНЕРАЦИЯ: плоский камень -> скалы ----------
      g.setSpeed(0);
      const w = g.world;
      const spawnX = g.spawnX, spawnY = g.spawnY;
      let stone = 0, rock = 0, orphanStone = 0, oreOnRock = 0, silverOnRock = 0;
      for (let y = 0; y < 64; y++) {
        for (let x = 0; x < 64; x++) {
          const i = y * 64 + x;
          const t = w.terrain[i];
          if (t === 3) stone++;
          if (t === 5) rock++;
          if (t === 3) {
            // осыпь = камень в 2 клетках от скалы; иначе — «плоский камень» (плохо)
            let near = false;
            for (let dy = -2; dy <= 2 && !near; dy++)
              for (let dx = -2; dx <= 2; dx++) {
                const nx = x + dx, ny = y + dy;
                if (nx >= 0 && ny >= 0 && nx < 64 && ny < 64 && w.terrain[ny * 64 + nx] === 5) { near = true; break; }
              }
            if (!near && (Math.abs(x - spawnX) >= 6 || Math.abs(y - spawnY) >= 6)) orphanStone++;
          }
          if (t === 5 && w.obj[i] === 5) oreOnRock++;
          if (t === 5 && w.obj[i] === 6) silverOnRock++;
        }
      }
      res.terrain = { stone, rock, orphanStone, oreOnRock, silverOnRock };
      res.noOrphanStone = orphanStone === 0;
      res.rockVeinsPlaced = oreOnRock > 0;

      // ---------- 2. ПРИОРИТЕТЫ: готовка в топе, охота в списке ----------
      const pawns = g.pawns.filter((p) => !p.dead);
      res.priorities = pawns.map((p) => [...p.priorities]);
      res.allHaveHunt = pawns.every((p) => p.priorities.includes('hunt'));
      res.cookNearTop = pawns.filter((p) => p.priorities.indexOf('cook') <= 1).length >= pawns.length - 1;

      // ---------- 3. ОХОТА: лук охотнику, олень рядом, пометка 🎯 ----------
      const foodBefore = w.countRes(2) + w.countRes(5);
      const hideBefore = w.countRes(10);
      const p0 = pawns[0];
      p0.weapon = 'bow';
      p0.hp = 100; p0.food = 90; p0.rest = 90;
      const sc = w.stockpileCenter() ?? { x: spawnX, y: spawnY };
      p0.x = sc.x + 1.5; p0.y = sc.y + 1.5; p0.path = null; p0.state = 'idle'; p0.job = null;
      const deer = g.spawnAnimal('deer', sc.x + 6.5, sc.y + 6.5);
      g.setSpeed(1);
      g.tool = 'hunt';
      g.applyTap(deer.x, deer.y);
      await sleep(120);
      res.marked = g.huntList.has(deer.id);
      if (!res.marked) { res.error = 'deer not marked'; return; }

      let huntJob = null;
      for (let t = 0; t < 20 && !huntJob; t++) { await sleep(100); huntJob = [...g.jobs.jobs.values()].find((j) => j.kind === 'hunt' && j.itemId === deer.id); }
      res.huntJobOnBoard = !!huntJob;

      let hunter = null;
      for (let t = 0; t < 40 && !hunter; t++) {
        await sleep(150);
        hunter = g.pawns.find((p) => !p.dead && p.job && p.job.kind === 'hunt' && p.job.itemId === deer.id);
      }
      res.hunterTookJob = !!hunter;
      res.hunterName = hunter ? hunter.name : null;
      if (!hunter) { res.error = 'no hunter claimed; board=' + JSON.stringify([...g.jobs.jobs.values()].map(j => j.kind)); return; }

      // ждём смерть дичи (мясо+шкура) — максимум 15с
      const hp0 = deer.hp;
      let died = !!deer.dead;
      for (let t = 0; t < 75 && !died; t++) {
        await sleep(200);
        died = !!deer.dead;
      }
      res.deerHpDropping = deer.dead || deer.hp < hp0;
      res.deerKilled = died;
      res.foodGained = w.countRes(2) + w.countRes(5) - foodBefore;
      res.hideGained = w.countRes(10) - hideBefore;
      res.huntCleared = !g.huntList.has(deer.id);
      if (!died) {
        const h2 = g.pawns.find((p) => !p.dead && p.job && p.job.kind === 'hunt');
        res.diag = h2 ? { hs: h2.state, hx: h2.x, hy: h2.y, d: Math.hypot(h2.x - deer.x, h2.y - deer.y), deerState: deer.state, dx: deer.x, dy: deer.y } : 'no hunter';
        res.error = 'deer not killed in time';
        return;
      }

      // ---------- 4. UI: окно зверя -> кнопка охоты ----------
      g.setSpeed(0);
      const deer2 = g.spawnAnimal('deer', sc.x + 7.5, sc.y + 7.5);
      g.tool = 'inspect';
      g.selectAt(deer2.x, deer2.y);
      await sleep(150);
      res.popupHasHuntBtn = !!findBtnByText('🎯 Охота');
      if (findBtnByText('🎯 Охота')) { findBtnByText('🎯 Охота').click(); await sleep(120); }
      res.uiToggleWorks = g.huntList.has(deer2.id);
      g.selectAt(deer2.x, deer2.y);
      await sleep(120);
      const off = findBtnByText('Снять с охоты');
      if (off) { off.click(); await sleep(120); }
      res.uiUntoggleWorks = !g.huntList.has(deer2.id);
      g.clearSelection();

      // ---------- 5. Рамка: стадо ----------
      const dA = g.spawnAnimal('deer', sc.x - 9.5, sc.y - 9.5);
      const dB = g.spawnAnimal('deer', sc.x - 7.5, sc.y - 7.5);
      g.tool = 'hunt';
      g.applyRect(sc.x - 11, sc.y - 11, sc.x - 6, sc.y - 6);
      res.rectMarksHerd = g.huntList.has(dA.id) && g.huntList.has(dB.id);
      g.huntList.delete(dA.id); g.huntList.delete(dB.id);
      g.removeAnimal(dA); g.removeAnimal(dB);

      // ---------- 6. Сейв/лоад: huntList + миграция приоритетов ----------
      g.huntList.add(deer2.id);
      const sv = g.serialize();
      res.savedHunt = Array.isArray(sv.hunt) && sv.hunt.includes(deer2.id);
      g.applySave(JSON.parse(JSON.stringify(sv)));
      res.applySaveKeepsHunt = g.huntList.has(deer2.id);

      const sv2 = JSON.parse(JSON.stringify(sv));
      for (const ps of sv2.pawns) ps.priorities = ['lumber', 'build', 'farm', 'mine', 'haul', 'cook'];
      g.applySave(sv2);
      const pm = g.pawns.find((p) => !p.dead);
      res.migratedPriorities = pm.priorities[0] === 'cook' && pm.priorities.includes('hunt');

      // ---------- 7. Опасная дичь: безоружных не посылают на кабана ----------
      for (const p of g.pawns.filter((q) => !q.dead)) { p.weapon = null; p.state = 'idle'; p.job = null; p.path = null; }
      const boar = g.spawnAnimal('boar', sc.x - 5.5, sc.y - 5.5);
      g.tool = 'hunt';
      g.applyTap(boar.x, boar.y);
      g.jobs.refresh(g.world, g.desig, g.realNow, g.canHaul(), g.jobExt());
      await sleep(600);
      res.noSuicideClaim = ![...g.jobs.jobs.values()].some((j) => j.kind === 'hunt' && j.itemId === boar.id && j.claimedBy !== null) &&
        !g.pawns.some((p) => p.job && p.job.kind === 'hunt' && p.job.itemId === boar.id);
      g.huntList.delete(boar.id); g.removeAnimal(boar);

      res.ok = res.noOrphanStone && res.rockVeinsPlaced && res.allHaveHunt && res.cookNearTop && res.marked &&
        res.huntJobOnBoard && res.hunterTookJob && res.deerKilled && res.huntCleared &&
        res.popupHasHuntBtn && res.uiToggleWorks && res.uiUntoggleWorks && res.rectMarksHerd &&
        res.savedHunt && res.applySaveKeepsHunt && res.migratedPriorities && res.noSuicideClaim;
    } catch (e) {
      res.error = String(e && e.stack ? e.stack : e);
      res.ok = false;
    }
  }
  run();
})();

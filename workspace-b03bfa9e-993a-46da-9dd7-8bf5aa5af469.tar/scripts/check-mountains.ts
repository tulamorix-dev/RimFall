// Оффлайн-проверка генерации гор и руды на 20 сидах
import { generateWorld } from '../src/game/world/mapgen.ts';
import { World } from '../src/game/world/world.ts';

let worst = 99;
let total = 0;
for (let seed = 1; seed <= 20; seed++) {
  const s = seed * 1337;
  const w = new World();
  const r = generateWorld(w, s);
  let ore = 0;
  let oreInStone = 0;
  let stoneTiles = 0;
  let mountains = 0;
  const seen = new Uint8Array(64 * 64);
  for (let i = 0; i < 64 * 64; i++) {
    if (w.terrain[i] === 3) stoneTiles++;
    if (w.obj[i] === 5) {
      ore++;
      if (w.terrain[i] === 3) oreInStone++;
    }
  }
  for (let i = 0; i < 64 * 64; i++) {
    if (w.terrain[i] !== 3 || seen[i]) continue;
    mountains++;
    const q = [i];
    seen[i] = 1;
    while (q.length) {
      const c = q.pop()!;
      const cx = c % 64;
      const cy = (c / 64) | 0;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = cx + dx;
        const ny = cy + dy;
        if (nx < 0 || ny < 0 || nx > 63 || ny > 63) continue;
        const ni = ny * 64 + nx;
        if (w.terrain[ni] === 3 && !seen[ni]) {
          seen[ni] = 1;
          q.push(ni);
        }
      }
    }
  }
  let dMin = 99;
  for (let y = 0; y < 64; y++)
    for (let x = 0; x < 64; x++)
      if (w.obj[y * 64 + x] === 5) dMin = Math.min(dMin, Math.hypot(x - r.spawnX, y - r.spawnY));
  total += ore;
  if (dMin < worst) worst = dMin;
  console.log(`seed ${s}: ore=${ore} inStone=${oreInStone} mountainClusters=${mountains} nearestVein=${dMin.toFixed(1)}`);
}
console.log('avg ore/seed:', (total / 20).toFixed(1), 'worst nearest:', worst.toFixed(1));

(function(){
  const g = window.__game;
  return JSON.stringify({huntAfterLoad: g.huntList.has(window.__t20.deer2), animalAlive: g.animals.some(a=>a.id===window.__t20.deer2 && !a.dead), paused: g.clock.speed===0});
})()

// E2E Task 18 (фаза 2): контролируемая охота + предупреждение при метке без лука
(function () {
  const g = window.__game;
  const res = { started: true };
  window.__t18b = res;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const logHas = (t) => g.events.entries.some((e) => e.text.includes(t));

  async function run() {
    try {
      g.setSpeed(0);
      const w = g.world;
      const sc = w.stockpileCenter() ?? { x: g.spawnX, y: g.spawnY };
      const p1 = g.pawns[1];
      p1.state = 'idle'; p1.job = null; p1.path = null; p1.resumeRef = undefined;
      p1.food = 90; p1.rest = 90; p1.hp = 100; p1.mods = [];
      p1.x = sc.x + 0.5; p1.y = sc.y + 0.5;
      p1.priorities = ['hunt', 'cook', 'build', 'farm', 'lumber', 'mine', 'haul'];

      // ---- 1. ПРЕДУПРЕЖДЕНИЕ: метка оленя, когда лука ни у кого нет ----
      p1.weapon = 'spear'; // ни у кого нет лука
      const deer = g.spawnAnimal('deer', sc.x + 5.5, sc.y + 5.5);
      g.toggleHunt(deer.id);
      res.warnNoBow = logHas('Стрелка с луком нет');

      // ---- 2. ЛУК РЯДОМ -> подбор -> охота ----
      w.addItem(7 /* Bow */, 1, Math.floor(sc.x) + 2, Math.floor(sc.y) + 2);
      g.setSpeed(1);
      let waited = 0;
      while (p1.weapon !== 'bow' && waited < 15000) { await sleep(250); waited += 250; }
      res.spearToBow = p1.weapon === 'bow';
      waited = 0;
      while (!(p1.job && p1.job.kind === 'hunt') && waited < 15000) { await sleep(250); waited += 250; }
      res.gotHunt = !!(p1.job && p1.job.kind === 'hunt');
      if (res.gotHunt) {
        // охотник должен двигаться к дичи (state move/work)
        await sleep(1500);
        res.huntingActive = p1.state === 'move' || p1.state === 'work';
      }
      const meatBefore = w.countRes(2) + w.countRes(10) /* Hide */;
      waited = 0;
      while (!deer.dead && waited < 45000) { await sleep(500); waited += 500; }
      res.deerKilled = deer.dead;
      await sleep(2500);
      const meatAfter = w.countRes(2) + w.countRes(10);
      res.dropsAppeared = meatAfter >= meatBefore;
      res.huntCleared = !g.huntList.has(deer.id);

      // ---- 3. РЕЗЮМ ОХОТНИКА: сон посреди охоты -> возврат к дичи ----
      const deer2 = g.spawnAnimal('deer', sc.x + 6.5, sc.y + 6.5);
      g.toggleHunt(deer2.id);
      p1.state = 'idle'; p1.job = null; p1.path = null; p1.food = 90; p1.rest = 90;
      waited = 0;
      while (!(p1.job && p1.job.kind === 'hunt') && waited < 15000) { await sleep(250); waited += 250; }
      res.gotHunt2 = !!(p1.job && p1.job.kind === 'hunt');
      // усыпить посреди охоты
      p1.rest = 4;
      waited = 0;
      while (p1.state !== 'sleep' && waited < 6000) { await sleep(200); waited += 200; }
      res.fellAsleepMidHunt = p1.state === 'sleep';
      const clock = g.clock;
      const dayMin = 1440;
      const intoDay = clock.totalMin % dayMin;
      clock.totalMin += (7 * 60 + 30 - intoDay + dayMin) % dayMin;
      p1.rest = 90;
      waited = 0;
      while (p1.state === 'sleep' && waited < 8000) { await sleep(200); waited += 200; }
      waited = 0;
      while (!(p1.job && p1.job.kind === 'hunt') && waited < 12000) { await sleep(250); waited += 250; }
      res.resumedHuntAfterSleep = !!(p1.job && p1.job.kind === 'hunt') && p1.job.itemId === deer2.id;
      g.toggleHunt(deer2.id); // снять метку, не убивать
      g.setSpeed(1);
    } catch (e) {
      res.error = String(e && e.stack ? e.stack : e);
    }
    res.done = true;
  }
  run();
})();

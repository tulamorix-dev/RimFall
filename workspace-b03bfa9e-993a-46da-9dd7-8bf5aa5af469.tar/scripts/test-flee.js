// Task 16 E2E: пешки убегают от медведя, спящие просыпаются, раненые дают отпор
(async function () {
  const g = window.__game;
  const R = { log: [] };
  window.__t16 = R;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const d2 = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);

  try {
    // 0) подготовка: без автопауз, скорость 4
    g.gameSettings.autopauseAlarm = false;
    g.gameSettings.autopauseEvents = false;
    g.setSpeed(4);
    const w = g.world;
    const base = g.centerBase();

    // 1) дерево в 10..18 клетках от базы
    let tree = null;
    outer: for (let y = 2; y < 62; y++) {
      for (let x = 2; x < 62; x++) {
        const i = y * 64 + x;
        if (w.obj[i] !== 1) continue; // Obj.Tree
        const db = d2(x, y, base.x, base.y);
        if (db < 10 || db > 18) continue;
        for (let dy = -1; dy <= 1; dy++)
          for (let dx = -1; dx <= 1; dx++) {
            if (w.passPawn(x + dx, y + dy)) { tree = { x, y, px: x + dx, py: y + dy }; break outer; }
          }
      }
    }
    R.tree = tree;
    if (!tree) { R.error = 'no tree'; return; }

    // 2) безоружная пешка у дерева
    const pawn = g.pawns.find((p) => !p.dead && !p.underground && p.state !== 'sleep');
    R.pawn = pawn.name;
    pawn.state = 'idle'; pawn.path = null; pawn.job = null;
    pawn.x = tree.px + 0.5; pawn.y = tree.py + 0.5;
    pawn.hp = Math.max(pawn.hp, 85); pawn.food = Math.max(pawn.food, 60); pawn.rest = Math.max(pawn.rest, 60);
    pawn.weapon = null; pawn.armor = null;

    // 3) назначаем рубку и ждём работы
    g.tool = 'chop';
    g.applyTap(tree.x, tree.y);
    g.tool = null;
    for (let t = 0; t < 30; t++) {
      await sleep(500);
      if (pawn.state === 'work') break;
    }
    R.workState = pawn.state;
    if (pawn.state !== 'work') { R.error = 'pawn not working: ' + pawn.state; return; }

    // 4) медведь в ~2.2 клетках, дальше 14 от базы (без тревоги)
    let bx = null, by = null;
    for (let a = 0; a < 12; a++) {
      const ang = (a * Math.PI) / 6;
      const cx = Math.round(pawn.x + Math.cos(ang) * 2.2);
      const cy = Math.round(pawn.y + Math.sin(ang) * 2.2);
      if (w.passAnimal(cx, cy) && d2(cx, cy, base.x, base.y) > 14) { bx = cx + 0.5; by = cy + 0.5; break; }
    }
    if (bx === null) { R.error = 'no bear spot'; return; }
    const bear = g.spawnAnimal('bear', bx, by);
    R.bearBaseDist = +d2(bx, by, base.x, base.y).toFixed(1);
    R.bearHunt = bear.state;

    // 5) сэмплим до 25с
    const samples = [];
    let sawFlee = false, gaveUp = false;
    const d0 = d2(pawn.x, pawn.y, bear.x, bear.y);
    for (let t = 0; t < 62; t++) {
      await sleep(400);
      samples.push({ t: +((t + 1) * 0.4).toFixed(1), ps: pawn.state, hp: Math.round(pawn.hp), pd: +d2(pawn.x, pawn.y, bear.x, bear.y).toFixed(1) });
      if (pawn.state === 'flee') sawFlee = true;
      if (pawn.hp <= 0 || bear.dead) break;
      if (bear.targetPawnId === null && t > 8) gaveUp = true;
      if (gaveUp && pawn.state !== 'flee') break;
    }
    R.nSamples = samples.length;
    R.samples = samples.slice(-6);
    R.d0 = +d0.toFixed(1);
    R.pdEnd = samples[samples.length - 1].pd;
    R.pdMax = Math.max(...samples.map((s) => s.pd));
    R.sawFlee = sawFlee;
    R.minHp = Math.min(...samples.map((s) => s.hp));
    R.bearDead = bear.dead;
    R.gaveUp = gaveUp;
    R.fightObserved = samples.some((s) => s.ps === 'fight');
    R.alive = !pawn.dead;
    R.serializeOk = (() => { try { g.serialize(); return true; } catch (e) { return String(e); } })();
    // A: убегает от зверя (дистанция растёт), выживает, серелизация не падает
    R.passA = sawFlee && R.alive && R.pdEnd > R.d0 && R.serializeOk === true;

    // ===== C: спящая просыпается от волка =====
    const p2 = g.pawns.find((p) => !p.dead && p !== pawn);
    if (p2) {
      p2.state = 'sleep'; p2.job = { kind: 'sleep', ground: true }; p2.path = null; p2.rest = 50;
      p2.x = pawn.x; p2.y = pawn.y; // рядом с медведем? нет — отнесём в сторону от него
      // точка в 8 клетках от медведя, проходимая
      for (let a = 0; a < 16 && p2.state === 'sleep'; a++) {
        const ang = (a * Math.PI) / 8;
        const cx = Math.round(bear.x + Math.cos(ang) * 8);
        const cy = Math.round(bear.y + Math.sin(ang) * 8);
        if (!w.passPawn(cx, cy)) continue;
        p2.x = cx + 0.5; p2.y = cy + 0.5;
        // волк вплотную к спящей
        let wx = null, wy = null;
        for (let b = 0; b < 8; b++) {
          const b2 = (b * Math.PI) / 4;
          const nx = Math.round(p2.x + Math.cos(b2) * 1.2);
          const ny = Math.round(p2.y + Math.sin(b2) * 1.2);
          if (w.passAnimal(nx, ny)) { wx = nx + 0.5; wy = ny + 0.5; break; }
        }
        if (wx === null) continue;
        const wolf = g.spawnAnimal('wolf', wx, wy);
        for (let t = 0; t < 8; t++) { await sleep(300); if (p2.state !== 'sleep') break; }
        R.woke = p2.state !== 'sleep';
        R.wokeState = p2.state;
        wolf.hp = 0; g.removeAnimal(wolf); // уборка волка
        break;
      }
      if (R.woke === undefined) { R.woke = false; R.wokeErr = 'no spot'; }
    }

    // ===== D1: раненый вооружённый даёт отпор =====
    const p3 = g.pawns.find((p) => !p.dead && p !== pawn && p !== p2);
    if (p3) {
      p3.weapon = 'sword'; p3.hp = 90; p3.state = 'idle'; p3.job = null; p3.path = null; p3.underground = false;
      // волк рядом, но не на пешке D1
      let placed = false;
      for (let a = 0; a < 16 && !placed; a++) {
        const ang = (a * Math.PI) / 8;
        const cx = Math.round(p3.x + Math.cos(ang) * 9);
        const cy = Math.round(p3.y + Math.sin(ang) * 9);
        if (!w.passPawn(cx, cy)) continue;
        p3.x = cx + 0.5; p3.y = cy + 0.5;
        let wx = null, wy = null;
        for (let b = 0; b < 8; b++) {
          const b2 = (b * Math.PI) / 4;
          const nx = Math.round(p3.x + Math.cos(b2) * 1.1);
          const ny = Math.round(p3.y + Math.sin(b2) * 1.1);
          if (w.passAnimal(nx, ny)) { wx = nx + 0.5; wy = ny + 0.5; break; }
        }
        if (wx === null) continue;
        const wolf = g.spawnAnimal('wolf', wx, wy);
        g.damagePawn(p3, 5, wolf);
        R.riposte = p3.state === 'fight';
        R.riposteState = p3.state;
        // волк получает урон от меча за 3с
        const whp0 = wolf.hp;
        for (let t = 0; t < 10; t++) { await sleep(300); if (wolf.dead) break; }
        R.wolfHurt = wolf.dead || wolf.hp < whp0;
        g.removeAnimal(wolf);
        placed = true;
      }
      if (!placed) { R.riposte = false; R.riposteErr = 'no spot'; }
    }

    // ===== D2: безоружные кулаки (принудительный бой) =====
    const p4 = g.pawns.find((p) => !p.dead && p !== pawn && p !== p2 && p !== p3);
    if (p4) {
      p4.weapon = null; p4.hp = 90; p4.state = 'fight'; p4.job = null; p4.path = null;
      p4.combatTargetId = bear.id;
      // ставим вплотную к медведю
      const cx = Math.round(bear.x), cy = Math.round(bear.y);
      let fx = null, fy = null;
      for (let b = 0; b < 8; b++) {
        const b2 = (b * Math.PI) / 4;
        const nx = cx + Math.round(Math.cos(b2));
        const ny = cy + Math.round(Math.sin(b2));
        if (w.passPawn(nx, ny)) { fx = nx + 0.5; fy = ny + 0.5; break; }
      }
      if (fx) {
        p4.x = fx; p4.y = fy;
        const bhp0 = bear.hp;
        for (let t = 0; t < 10; t++) { await sleep(300); if (bear.dead) break; }
        R.fists = bear.dead || bear.hp < bhp0;
      } else R.fists = false;
    }

    // итог
    R.pass = R.passA && (R.woke !== false) && (R.riposte === true) && (R.fists !== false);
    g.setSpeed(1);
  } catch (e) {
    R.error = String(e && e.stack ? e.stack : e);
  }
})();
'ok-t16';

// Офлайн-воспроизведение: pathToAdjacent(36,33 -> 56,5) на реальном мире
import { readFileSync } from 'fs';
import { MAP, BType } from '../src/game/data/defs.ts';
import { World } from '../src/game/world/world.ts';
import { pathToAdjacent, pathToTile } from '../src/game/world/pathfinding.ts';

const raw = JSON.parse(readFileSync(new URL('./world-dump.json', import.meta.url), 'utf8'));
const data = typeof raw === 'string' ? JSON.parse(raw) : raw;

const w = new World();
w.terrain.set(data.terrain);
w.obj.set(data.obj);
for (const b of data.buildings) {
  w.placeBuilding({ id: 1, x: b.x, y: b.y, type: b.type as BType, blueprint: b.blueprint, hp: 1, maxHp: 1, matType: 0, matNeed: 1, matHave: 0, workNeed: 1, workHave: 0, ownerId: null } as never);
}

// из какой точки ищем путь
const starts: [number, number][] = [[36, 33], [34, 33], [35, 33], [37, 36]];
for (const [sx, sy] of starts) {
  const p = pathToAdjacent(w, sx, sy, 5 * MAP + 56, false);
  console.log(`pathToAdjacent(${sx},${sy} -> 56,5):`, p ? p.length + ' nodes' : 'NULL');
}
const p2 = pathToTile(w, 36, 33, 55, 4, false);
console.log('pathToTile(36,33 -> 55,4):', p2 ? p2.length : 'NULL');

// Проходимость вокруг старта и в середине пути
const probe = [[36, 33], [40, 30], [45, 20], [50, 12], [55, 6], [56, 5]];
for (const [x, y] of probe) {
  console.log(`passPawn(${x},${y}) =`, w.passPawn(x, y), 'terrain', w.terrain[y * MAP + x], 'obj', w.obj[y * MAP + x]);
}

// BFS достижимости шахты из лагеря (выполняется в консоли браузера)
(() => {
  const w = window.__game.world;
  const S = 33 * 64 + 35;
  const MX = 56, MY = 5;
  const seen = new Uint8Array(4096);
  seen[S] = 1;
  const queue = [S];
  while (queue.length) {
    const c = queue.shift();
    const cx = c % 64, cy = (c / 64) | 0;
    for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]) {
      const nx = cx + d[0], ny = cy + d[1];
      if (nx < 0 || ny < 0 || nx > 63 || ny > 63) continue;
      const ni = ny * 64 + nx;
      if (seen[ni]) continue;
      seen[ni] = 1;
      if (w.passPawn(nx, ny)) queue.push(ni);
    }
  }
  let reachAdj = 0;
  const adj = [];
  for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]) {
    const nx = MX + d[0], ny = MY + d[1];
    if (nx < 0 || ny < 0 || nx > 63 || ny > 63) continue;
    const ok = seen[ny * 64 + nx] === 1;
    if (ok) reachAdj++;
    adj.push(nx + ',' + ny + ':' + (ok ? 'r' : 'un') + ':' + (w.passPawn(nx, ny) ? 'pass' : 'blocked'));
  }
  return JSON.stringify({ spawnReach: seen[S], reachAdj, adj });
})();

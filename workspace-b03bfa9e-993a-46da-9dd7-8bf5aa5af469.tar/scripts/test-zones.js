// Проверка RimWorld-стиля зон: отдельные склады/фермы, примыкание, фильтры, настройки
(function () {
  const g = window.__game;
  const r = window.__renderer;
  const c = r.canvas;
  const res = {};
  const Res = { Wood: 0, Stone: 1, Food: 2, Loot: 3, Corpse: 4, Meal: 5, Spear: 6, Bow: 7 };

  function pev(type, x, y, id) {
    const rect = c.getBoundingClientRect();
    c.dispatchEvent(new PointerEvent(type, {
      pointerId: id, pointerType: 'touch', isPrimary: true,
      clientX: rect.left + x, clientY: rect.top + y,
      button: 0, buttons: type === 'pointerup' ? 0 : 1, bubbles: true,
    }));
  }
  function w2s(wx, wy) {
    return {
      x: (wx * 32 - r.cam.x) * r.cam.zoom + r.viewW / 2,
      y: (wy * 32 - r.cam.y) * r.cam.zoom + r.viewH / 2,
    };
  }
  function tapTile(tx, ty, id) {
    const s = w2s(tx + 0.5, ty + 0.5);
    pev('pointerdown', s.x, s.y, id);
    pev('pointerup', s.x, s.y, id);
  }
  function freeFar(fromX, fromY, minD) {
    for (let rad = minD; rad < 30; rad++) {
      for (let t = 0; t < 60; t++) {
        const ang = (Math.PI * 2 * t) / 60;
        const tx = Math.round(fromX + Math.cos(ang) * rad);
        const ty = Math.round(fromY + Math.sin(ang) * rad);
        if (tx < 2 || ty < 2 || tx > 61 || ty > 61) continue;
        const i = ty * 64 + tx;
        if (g.world.passPawn(tx, ty) && g.world.terrain[i] !== 2 && g.world.obj[i] === 0 && g.world.zone[i] === 0 && !g.world.buildingMap.has(i)) {
          if (tx + 1 <= 61 && g.world.passPawn(tx + 1, ty) && g.world.terrain[i + 1] !== 2 && g.world.obj[i + 1] === 0 && g.world.zone[i + 1] === 0 && !g.world.buildingMap.has(i + 1)) {
            return [tx, ty];
          }
        }
      }
    }
    return null;
  }
  function focusCam(tx, ty) {
    r.cam.x = tx * 32;
    r.cam.y = ty * 32;
    r.cam.zoom = 1.5;
    r.cam.followId = null;
    r.cam.clampToMap();
    r.viewW = c.clientWidth;
    r.viewH = c.clientHeight;
  }

  const zoneDefsBefore = g.world.zoneDefs.size;
  res.before = { zoneDefs: zoneDefsBefore, list: g.zonesList() };

  // --- Тест A: тап складом в стороне -> НОВАЯ зона «Склад 2» ---
  const spotA = freeFar(30, 34, 14);
  focusCam(spotA[0], spotA[1]);
  g.tool = 'stockpile';
  g.clearSelection();
  tapTile(spotA[0], spotA[1], 31);
  const zdA = g.world.zoneDefOf(g.world.idx(spotA[0], spotA[1]));
  res.A_newFarZone = {
    spot: spotA,
    zoneId: zdA ? zdA.id : 0,
    name: zdA ? zdA.name : null,
    defsCount: g.world.zoneDefs.size,
    foodAllowed: zdA ? zdA.filters[Res.Food] : null,
  };

  // --- Тест B: тап вплотную -> расширение той же зоны ---
  g.tool = 'stockpile';
  tapTile(spotA[0] + 1, spotA[1], 32);
  const zdA2 = g.world.zoneDefOf(g.world.idx(spotA[0] + 1, spotA[1]));
  res.B_adjacentJoin = { sameZone: zdA2 && zdA && zdA2.id === zdA.id, tiles: g.zonesList().find((z) => z.id === (zdA && zdA.id)).tiles };

  // --- Тест C: ферма в стороне -> отдельная зона «Ферма» ---
  const spotC = freeFar(spotA[0], spotA[1], 8);
  focusCam(spotC[0], spotC[1]);
  g.tool = 'farm';
  g.clearSelection();
  tapTile(spotC[0], spotC[1], 33);
  const zdC = g.world.zoneDefOf(g.world.idx(spotC[0], spotC[1]));
  res.C_farmZone = { spot: spotC, name: zdC ? zdC.name : null, kind: zdC ? zdC.kind : null };

  // --- Тест D: переименование ---
  g.renameZone(zdA.id, 'Дровяной');
  res.D_rename = { name: g.world.zoneDefs.get(zdA.id).name };

  // --- Тест E: фильтр — склад «Дровяной» не принимает еду ---
  g.setZoneFilter(zdA.id, Res.Food, false);
  res.E_filter = {
    foodOnA: g.world.zoneDefs.get(zdA.id).filters[Res.Food],
    spaceForFoodSomewhere: g.world.stockpileHasSpaceFor(Res.Food),
    spaceForWoodSomewhere: g.world.stockpileHasSpaceFor(Res.Wood),
  };

  // --- Тест F: положили еду на запрещённый склад -> носильщики унесут ---
  g.world.addItem(Res.Food, 6, spotA[0], spotA[1]);
  g.renderDirtyTile(spotA[0], spotA[1]);
  res.F_dropped = { at: spotA };

  // --- Тест G: осмотр клетки зоны даёт zoneId для кнопки настроек ---
  g.tool = 'inspect';
  g.clearSelection();
  tapTile(spotA[0], spotA[1], 34);
  res.G_inspect = { info: g.selectedInfo ? { lines: g.selectedInfo.lines, zoneId: g.selectedInfo.zoneId } : null };

  // --- Тест H: сериализация новых полей ---
  const sv = g.serialize();
  res.H_save = {
    zoneIdLen: sv.zoneId ? sv.zoneId.length : 0,
    zoneDefs: sv.zoneDefs ? sv.zoneDefs.map((z) => z.name) : [],
  };

  res.spots = { A: spotA, C: spotC, zoneAId: zdA.id, zoneCId: zdC.id };
  g.tool = 'inspect';
  return JSON.stringify(res);
})();

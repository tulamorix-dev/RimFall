// E2E Task 18: resume задачи после сна, апгрейд снаряжения (копьё->меч, копьё->лук),
// охота после подбора лука, предупреждение при метке без лука
(function () {
  const g = window.__game;
  const res = { started: true };
  window.__t18 = res;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const bodyHas = (t) => document.body.innerText.includes(t);

  async function run() {
    try {
      g.setSpeed(0);
      const w = g.world;
      const sc = w.stockpileCenter() ?? { x: g.spawnX, y: g.spawnY };
      const pawns = g.pawns.filter((p) => !p.dead);
      const p0 = pawns[0];
      // приводим пешку в порядок
      p0.food = 90; p0.rest = 90; p0.hp = 100; p0.mods = [];
      p0.x = sc.x + 1.5; p0.y = sc.y + 1.5; p0.path = null; p0.state = 'idle'; p0.job = null;
      p0.priorities = ['hunt', 'cook', 'build', 'farm', 'lumber', 'mine', 'haul'];

      // ============ 1. АПГРЕЙД: копьё -> меч ============
      p0.weapon = 'spear';
      const swordTile = { x: Math.floor(sc.x) + 3, y: Math.floor(sc.y) + 3 };
      w.addItem(9 /* Sword */, 1, swordTile.x, swordTile.y);
      g.setSpeed(1);
      let waited = 0;
      while (p0.weapon !== 'sword' && waited < 15000) { await sleep(250); waited += 250; }
      res.spearToSword = p0.weapon === 'sword';
      res.spearDropped = w.items.some((it) => it.type === 6 /* Spear */);
      g.setSpeed(0);
      res.logSwap = g.events.lines ? undefined : undefined; // лог не парсим, смотрим состояние

      // ============ 2. RESUME: задача прерывается сном -> возвращается ============
      // помечаем дерево для рубки подальше
      let treeTile = -1;
      for (let i = 0; i < w.obj.length; i++) {
        if (w.obj[i] === 1 /* Tree */) {
          const x = i % 64, y = (i / 64) | 0;
          if (Math.hypot(x - p0.x, y - p0.y) > 8 && Math.hypot(x - p0.x, y - p0.y) < 20) { treeTile = i; break; }
        }
      }
      res.treeFound = treeTile >= 0;
      if (treeTile >= 0) {
        g.desig.chop[treeTile] = 1;
        g.jobs.refresh(w, g.desig, g.realNow, g.canHaul(), g.jobExt());
        p0.food = 95; p0.rest = 95; p0.state = 'idle'; p0.job = null; p0.resumeRef = undefined;
        g.setSpeed(1);
        // ждём, пока возьмёт рубку
        waited = 0;
        while (!(p0.job && p0.job.kind === 'chop') && waited < 10000) { await sleep(200); waited += 200; }
        res.gotChop = p0.job && p0.job.kind === 'chop';
        const chopRef = p0.job ? p0.job.jobRef : undefined;
        res.chopRef = chopRef;
        // укладываем спать (обморочная усталость) — как это делает решатель
        if (chopRef !== undefined) {
          // вызывает startSleep через модуль нельзя — эмулируем: решатель сам уложит при rest<10
          p0.rest = 5;
          waited = 0;
          while (p0.state !== 'sleep' && waited < 6000) { await sleep(200); waited += 200; }
          res.fellAsleep = p0.state === 'sleep';
          // будим: rest почти полный + утро
          const clock = g.clock;
          // ставим время 7:00 (утро) — если totalMin доступен
          if (clock.totalMin !== undefined) {
            const dayMin = 24 * 60;
            const intoDay = clock.totalMin % dayMin;
            clock.totalMin += (7 * 60 + 30 - intoDay + dayMin) % dayMin;
          }
          p0.rest = 90;
          waited = 0;
          while (p0.state === 'sleep' && waited < 8000) { await sleep(200); waited += 200; }
          res.wokeUp = p0.state !== 'sleep';
          // ждём, пока возьмёт задачу — ДОЛЖНА быть та же рубка (resume)
          waited = 0;
          while (!(p0.job && (p0.job.kind === 'chop' || p0.job.kind === 'haul' || p0.job.kind === 'eat')) && waited < 10000) { await sleep(200); waited += 200; }
          res.resumedKind = p0.job ? p0.job.kind : null;
          res.resumedChop = p0.job && p0.job.kind === 'chop' && p0.job.jobRef === chopRef;
          res.resumeRefConsumed = p0.resumeRef === undefined;
        }
        g.desig.chop[treeTile] = 0;
      }

      // ============ 3. ЛУК: копьё -> лук при апгрейде, охота на оленя ============
      // убираем меч из рук? нет: лук tier 2 < меч 3 — мечник не возьмёт. Берём вторую пешку.
      const p1 = pawns[1];
      if (p1 && !p1.dead) {
        p1.food = 90; p1.rest = 90; p1.hp = 100; p1.mods = [];
        p1.x = sc.x + 0.5; p1.y = sc.y + 0.5; p1.path = null; p1.state = 'idle'; p1.job = null; p1.resumeRef = undefined;
        p1.priorities = ['hunt', 'cook', 'build', 'farm', 'lumber', 'mine', 'haul'];
        p1.weapon = 'spear';
        // метка оленя БЕЗ лука -> предупреждение в логе
        const deer = g.spawnAnimal('deer', sc.x + 8.5, sc.y + 8.5);
        const logBefore = document.body.innerText;
        g.toggleHunt(deer.id);
        res.warnNoBow = document.body.innerText.includes('Стрелка с луком нет') || document.body.innerText.includes('верстаке');
        // кладём лук рядом с пешкой
        const bowTile = { x: Math.floor(sc.x) + 2, y: Math.floor(sc.y) + 2 };
        w.addItem(7 /* Bow */, 1, bowTile.x, bowTile.y);
        g.setSpeed(1);
        waited = 0;
        while (p1.weapon !== 'bow' && waited < 15000) { await sleep(250); waited += 250; }
        res.spearToBow = p1.weapon === 'bow';
        // охота: пешка с луком идёт на помеченного оленя
        waited = 0;
        while (!(p1.job && p1.job.kind === 'hunt') && waited < 12000) { await sleep(250); waited += 250; }
        res.gotHunt = p1.job && p1.job.kind === 'hunt';
        // дожидаемся добычи
        const foodBefore = w.countRes(2 /* Food */);
        waited = 0;
        while (!deer.dead && waited < 40000) { await sleep(500); waited += 500; }
        res.deerKilled = deer.dead;
        await sleep(3000);
        res.meatDropped = w.countRes(2) >= foodBefore;
        res.huntCleared = !g.huntList.has(deer.id);
        // копьё не потеряно: старое копьё p1 на земле
        res.spearStillAround = w.items.some((it) => it.type === 6);
      }

      g.setSpeed(1);
    } catch (e) {
      res.error = String(e && e.stack ? e.stack : e);
    }
    res.done = true;
  }
  run();
})();

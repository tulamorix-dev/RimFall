(function(){
  const click = (el) => el && el.click();
  const findBtnByText = (t) => [...document.querySelectorAll('button')].find((b) => b.innerText.includes(t));
  const $aria = (l) => document.querySelector('[aria-label="' + l + '"]');
  click($aria('Пауза и меню игры'));
  return 'menu opening';
})()

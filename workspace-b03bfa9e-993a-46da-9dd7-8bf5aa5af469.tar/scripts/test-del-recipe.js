// КРИТИЧЕСКИЙ ТЕСТ: удаление рецепта + переиндексация заказов
(() => {
  const g = window.__game;
  const r = {};
  const wb = g.world.buildings.find((b) => b.type === 4);
  // заказы: копьё(0)×2, лук(1)×1, + мечи(2)×3
  g.addBill(wb.id, 2, 3);
  r.billsBefore = wb.bills.map((b) => `${b.recipe}x${b.count}`);
  // задача крафта на доске?
  g.jobs.refresh(g.world, g.desig, performance.now(), true, {
    alive: 3, meals: 0, food: 0, spears: 0, bows: 0, swords: 0, coats: 0, leathers: 0, irons: 0, hunt: [],
  });
  r.craftJobsBefore = [...g.jobs.jobs.values()].filter((j) => j.kind === 'craft').map((j) => j.recipe);
  // УДАЛЯЕМ рецепт 0 (копьё) напрямую через RECIPES-логику AdminAPI
  // (эмулируем вызов из UI — ищем конструктор через game)
  return JSON.stringify(r);
})();
